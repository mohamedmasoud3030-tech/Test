import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { hosts } from "@/db/schema";
import { listHosts } from "@/lib/queries";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ hosts: await listHosts() });
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  if (!body?.name || !String(body.name).trim()) {
    return NextResponse.json({ error: "Host name is required." }, { status: 400 });
  }
  try {
    const row = await db
      .insert(hosts)
      .values({
        name: String(body.name).trim(),
        provider: String(body.provider ?? "docker"),
        region: String(body.region ?? "us-east-1"),
        runtime: body.runtime === "python" ? "python" : "node",
        ramMb: Number(body.ramMb ?? 4096),
        cpus: Number(body.cpus ?? 2),
        overheadMb: Number(body.overheadMb ?? 512),
        perSessionRamMb: Number(body.perSessionRamMb ?? 1024),
        note: body.note ? String(body.note) : null,
      })
      .returning();
    return NextResponse.json({ id: row[0].id }, { status: 201 });
  } catch (err) {
    console.error("host creation failed", err);
    return NextResponse.json({ error: "Database error while creating the host." }, { status: 502 });
  }
}
