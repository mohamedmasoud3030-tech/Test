"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { classNames } from "@/lib/util";

const NAV = [
  {
    section: "Operate",
    items: [
      { href: "/", label: "Overview", icon: "▦" },
      { href: "/sessions", label: "Sessions", icon: "❯" },
      { href: "/launch", label: "Launch agent", icon: "＋" },
      { href: "/fleet", label: "Fleet & capacity", icon: "⬡" },
      { href: "/tenants", label: "Tenants", icon: "◉" },
    ],
  },
  {
    section: "Hosting runbooks",
    items: [
      { href: "/patterns", label: "Session patterns", icon: "⟳" },
      { href: "/storage", label: "Session storage", icon: "⛁" },
      { href: "/observability", label: "Observability", icon: "📈" },
      { href: "/security", label: "Security & isolation", icon: "🛡" },
      { href: "/troubleshooting", label: "Troubleshooting", icon: "✺" },
    ],
  },
];

export function Sidebar() {
  const path = usePathname();
  return (
    <aside className="w-[248px] shrink-0 border-r border-[#1b2029] bg-[#0d1015] flex flex-col h-screen sticky top-0">
      <Link href="/" className="flex items-center gap-3 px-5 h-16 border-b border-[#1b2029]">
        <span className="w-8 h-8 rounded-lg bg-[#d97757] text-[#1b100b] grid place-items-center font-bold text-sm mono">❯</span>
        <span>
          <span className="block text-[13.5px] font-semibold text-zinc-100 leading-tight">Agent Ops</span>
          <span className="block text-[10.5px] text-zinc-500 leading-tight mono">claude-agent-sdk host</span>
        </span>
      </Link>

      <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-6">
        {NAV.map((group) => (
          <div key={group.section}>
            <div className="px-2 text-[10.5px] uppercase tracking-[0.12em] text-zinc-600 font-semibold mb-1.5">{group.section}</div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = item.href === "/" ? path === "/" : path.startsWith(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={classNames(
                      "flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-[13px] transition-colors",
                      active ? "bg-[#1d2430] text-zinc-100 font-medium" : "text-zinc-400 hover:text-zinc-200 hover:bg-[#141820]"
                    )}
                  >
                    <span className={classNames("w-4 text-center text-[12px]", active ? "text-[#e8a089]" : "text-zinc-600")}>{item.icon}</span>
                    {item.label}
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-3 border-t border-[#1b2029]">
        <a
          href="https://code.claude.com/docs/en/agent-sdk/hosting"
          target="_blank"
          rel="noreferrer"
          className="block px-2.5 py-2 rounded-lg text-[11.5px] text-zinc-500 hover:text-zinc-300"
        >
          Hosting the Agent SDK ↗
          <span className="block text-zinc-700">code.claude.com/docs</span>
        </a>
      </div>
    </aside>
  );
}
