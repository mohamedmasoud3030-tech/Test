"use client";

import { useState } from "react";
import { Card, CodeBlock, Tabs, Badge, SectionTitle, PatternBadge } from "@/components/ui";
import { PATTERNS, STATE_ON_DISK } from "@/lib/content";
import { ephemeralEntrypoint, longRunningSnippet, hybridSnippet } from "@/lib/generators";

type Q = { q: string; options: { label: string; vote: string }[] };
const QUIZ: Q[] = [
  {
    q: "What is the task lifecycle?",
    options: [
      { label: "One-off task with a clear finish line", vote: "ephemeral" },
      { label: "Continuous work / high-volume message stream", vote: "long-running" },
      { label: "Many interactions with long idle gaps", vote: "hybrid" },
      { label: "Several agents must collaborate tightly", vote: "multi-agent" },
    ],
  },
  {
    q: "Can the container disappear between interactions?",
    options: [
      { label: "It exits as soon as the task completes", vote: "ephemeral" },
      { label: "No — the subprocess must stay warm", vote: "long-running" },
      { label: "Yes, spin it down and hydrate later", vote: "hybrid" },
      { label: "Agents share one container for the whole simulation", vote: "multi-agent" },
    ],
  },
  {
    q: "Do sessions resume on a different host / replica?",
    options: [
      { label: "Never — each run is independent", vote: "ephemeral" },
      { label: "No, pin to one warm container", vote: "long-running" },
      { label: "Yes, serverless workers / CI runners / autoscale", vote: "hybrid" },
      { label: "Agents share local state inside one container", vote: "multi-agent" },
    ],
  },
  {
    q: "Cold-start budget and pricing?",
    options: [
      { label: "Sub-second, per-second billing", vote: "ephemeral" },
      { label: "Slower start is fine, hourly billing", vote: "long-running" },
      { label: "Fast hydration, per-second + durable storage", vote: "hybrid" },
      { label: "Hourly, but N× agents per container", vote: "multi-agent" },
    ],
  },
];

export default function PatternsPage() {
  const [answers, setAnswers] = useState<Record<number, string>>({});
  const votes = Object.values(answers);
  const tally: Record<string, number> = {};
  votes.forEach((v) => (tally[v] = (tally[v] ?? 0) + 1));
  const winner = Object.entries(tally).sort((a, b) => b[1] - a[1])[0]?.[0];

  const snippetFor = (id: string, sdk: "typescript" | "python") => {
    if (id === "ephemeral") return ephemeralEntrypoint(sdk);
    if (id === "long-running") return longRunningSnippet(sdk);
    if (id === "hybrid") return hybridSnippet(sdk, "postgres");
    return longRunningSnippet(sdk).replace("streamInput", "query  // one query() per agent, distinct cwd per agent");
  };

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <header className="mb-7">
        <h1 className="text-xl font-semibold text-zinc-100">Choose a session pattern</h1>
        <p className="text-[13px] text-zinc-500 mt-1 max-w-3xl">
          Patterns describe how long a container lives relative to the sessions it serves. The deployment target (Docker, Modal, Kubernetes) is orthogonal — see the
          hosting cookbook for manifests.
        </p>
      </header>

      <Card className="mb-7">
        <SectionTitle title="Pattern recommender" subtitle="Answer four questions about the workload." />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {QUIZ.map((q, qi) => (
            <div key={qi}>
              <div className="text-[12.5px] font-medium text-zinc-300 mb-2">
                {qi + 1}. {q.q}
              </div>
              <div className="space-y-1.5">
                {q.options.map((o) => (
                  <button
                    key={o.label}
                    onClick={() => setAnswers({ ...answers, [qi]: o.vote })}
                    className={`w-full text-left text-[12px] rounded-lg border px-3 py-2 transition-colors ${
                      answers[qi] === o.vote ? "border-[#d97757]/60 bg-[#d97757]/[0.08] text-zinc-100" : "border-[#232a35] bg-[#11151c] text-zinc-400 hover:border-[#3a4455]"
                    }`}
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            </div>
          ))}
        </div>
        {winner && (
          <div className="mt-5 rounded-xl border border-[#d97757]/40 bg-[#d97757]/[0.07] px-4 py-3 flex items-center gap-3 flex-wrap fade-up">
            <span className="text-[12.5px] text-zinc-400">Recommended pattern:</span>
            <PatternBadge pattern={winner} />
            <span className="text-[12px] text-zinc-500">{PATTERNS.find((p) => p.id === winner)?.bestFor}</span>
          </div>
        )}
      </Card>

      <div className="space-y-5">
        {PATTERNS.map((p) => (
          <Card key={p.id}>
            <div className="flex items-start gap-4 flex-wrap">
              <div className="text-3xl">{p.icon}</div>
              <div className="flex-1 min-w-[300px]">
                <div className="flex items-center gap-2.5 flex-wrap">
                  <h2 className="text-[15px] font-semibold text-zinc-100">{p.name}</h2>
                  <PatternBadge pattern={p.id} />
                  {p.storeRequired && <Badge tone="violet">SessionStore required</Badge>}
                </div>
                <p className="text-[12.5px] text-zinc-500 mt-1">{p.lifetime}</p>
                <p className="text-[12.5px] text-zinc-400 mt-2">
                  <b className="text-zinc-300">Best for:</b> {p.bestFor}
                </p>
                <div className="flex flex-wrap gap-1.5 mt-2">
                  {p.workloads.map((w) => (
                    <span key={w} className="badge bg-[#141a23] border-[#262d39] text-zinc-400">
                      {w}
                    </span>
                  ))}
                </div>
                <ul className="mt-3 space-y-1.5">
                  {p.points.map((pt, i) => (
                    <li key={i} className="text-[12px] text-zinc-400 flex gap-2">
                      <span className="text-[#d97757]">→</span>
                      <span className="leading-snug" dangerouslySetInnerHTML={{ __html: pt.replace(/`([^`]+)`/g, '<span class="mono text-zinc-300">$1</span>') }} />
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            <div className="mt-4">
              <Tabs
                tabs={[
                  { key: "ts", label: "TypeScript", content: <CodeBlock lang="typescript" compact code={snippetFor(p.id, "typescript")} /> },
                  { key: "py", label: "Python", content: <CodeBlock lang="python" compact code={snippetFor(p.id, "python")} /> },
                ]}
              />
            </div>
          </Card>
        ))}
      </div>

      <Card className="mt-7">
        <SectionTitle title="State that lives on local disk by default" subtitle="None of it survives a container restart, scale-down, or a move to another node." />
        <div className="space-y-2">
          {STATE_ON_DISK.map((s) => (
            <div key={s.state} className="grid grid-cols-12 gap-3 items-start rounded-lg border border-[#232a35] bg-[#11151c] px-3.5 py-3 text-[12px]">
              <div className="col-span-3 font-medium text-zinc-200">{s.state}</div>
              <div className="col-span-5 mono text-[11px] text-zinc-500">{s.location}</div>
              <div className="col-span-4 text-zinc-400">{s.persistence}</div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
