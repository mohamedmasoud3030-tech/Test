"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { classNames } from "@/lib/util";

const NAV = [
  {
    section: "Operate",
    items: [
      { href: "/", label: "Overview", icon: "▦" },
      { href: "/sessions", label: "Sessions", icon: "❯" },
      { href: "/launch", label: "Launch agent", icon: "＋" },
      { href: "/fleet", label: "Fleet & capacity", icon: "⬡" },
      { href: "/tenants", label: "Tenants", icon: "◉" },
    ],
  },
  {
    section: "Hosting runbooks",
    items: [
      { href: "/patterns", label: "Session patterns", icon: "⟳" },
      { href: "/storage", label: "Session storage", icon: "⛁" },
      { href: "/observability", label: "Observability", icon: "📈" },
      { href: "/security", label: "Security & isolation", icon: "🛡" },
      { href: "/troubleshooting", label: "Troubleshooting", icon: "✺" },
    ],
  },
];

function Brand({ compact }: { compact?: boolean }) {
  return (
    <span className="flex items-center gap-3">
      <span className="w-8 h-8 rounded-lg bg-[#d97757] text-[#1b100b] grid place-items-center font-bold text-sm mono shrink-0">❯</span>
      <span className={compact ? "min-w-0" : ""}>
        <span className="block text-[13.5px] font-semibold text-zinc-100 leading-tight">Agent Ops</span>
        <span className="block text-[10.5px] text-zinc-500 leading-tight mono">claude-agent-sdk host</span>
      </span>
    </span>
  );
}

export function Sidebar() {
  const path = usePathname();
  const [open, setOpen] = useState(false);

  const panel = (
    <aside
      className={classNames(
        "w-[260px] max-w-[85vw] shrink-0 border-r border-[#1b2029] bg-[#0d1015] flex flex-col h-screen",
        // Mobile: fixed off-canvas; desktop (lg): sticky static column
        "fixed lg:sticky top-0 left-0 z-50 transition-transform duration-200",
        open ? "translate-x-0 shadow-2xl" : "-translate-x-full lg:translate-x-0"
      )}
    >
      <Link href="/" className="flex items-center gap-3 px-5 h-16 border-b border-[#1b2029] min-w-0" onClick={() => setOpen(false)}>
        <Brand />
      </Link>

      <nav className="flex-1 overflow-y-auto overflow-x-hidden px-3 py-4 space-y-6">
        {NAV.map((group) => (
          <div key={group.section}>
            <div className="px-2 text-[10.5px] uppercase tracking-[0.12em] text-zinc-600 font-semibold mb-1.5">{group.section}</div>
            <div className="space-y-0.5">
              {group.items.map((item) => {
                const active = item.href === "/" ? path === "/" : path.startsWith(item.href);
                return (
                  <Link
                    key={item.href}
                    href={item.href}
                    onClick={() => setOpen(false)}
                    className={classNames(
                      "flex min-w-0 items-center gap-2.5 px-2.5 py-2 rounded-lg text-[13px] transition-colors",
                      active ? "bg-[#1d2430] text-zinc-100 font-medium" : "text-zinc-400 hover:text-zinc-200 hover:bg-[#141820]"
                    )}
                  >
                    <span className={classNames("w-4 text-center text-[12px] shrink-0", active ? "text-[#e8a089]" : "text-zinc-600")}>{item.icon}</span>
                    <span className="truncate">{item.label}</span>
                  </Link>
                );
              })}
            </div>
          </div>
        ))}
      </nav>

      <div className="p-3 border-t border-[#1b2029]">
        <a
          href="https://code.claude.com/docs/en/agent-sdk/hosting"
          target="_blank"
          rel="noreferrer"
          className="block px-2.5 py-2 rounded-lg text-[11.5px] text-zinc-500 hover:text-zinc-300"
        >
          Hosting the Agent SDK ↗
          <span className="block text-zinc-700 break-all">code.claude.com/docs</span>
        </a>
      </div>
    </aside>
  );

  return (
    <>
      {/* Mobile top bar (hidden on desktop, where the static sidebar shows) */}
      <div className="lg:hidden fixed top-0 inset-x-0 z-40 h-14 bg-[#0d1015]/95 backdrop-blur border-b border-[#1b2029] flex items-center gap-3 px-4">
        <button
          type="button"
          aria-label="Open navigation"
          onClick={() => setOpen(true)}
          className="w-9 h-9 -ml-1 grid place-items-center rounded-lg text-zinc-300 hover:bg-[#1a2029]"
        >
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round">
            <path d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <Link href="/" onClick={() => setOpen(false)} className="min-w-0">
          <Brand compact />
        </Link>
      </div>

      {panel}

      {/* Mobile backdrop */}
      {open && (
        <div
          className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-[1px]"
          onClick={() => setOpen(false)}
          aria-hidden
        />
      )}
    </>
  );
}
