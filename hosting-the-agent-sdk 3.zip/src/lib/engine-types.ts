// Types shared by the Drizzle schema and the simulated agent-loop engine.

export type TokenUsage = {
  inputTokens: number;
  outputTokens: number;
  cacheReadTokens: number;
  cacheCreationTokens: number;
};

export type SubagentEntry = {
  role: "assistant" | "user";
  kind: "text" | "tool_use" | "tool_result";
  text?: string;
  toolName?: string;
  input?: unknown;
  output?: string;
  isError?: boolean;
  durationMs?: number;
};

export type PlannedEvent =
  | { kind: "init" }
  | {
      kind: "assistant";
      phase: "open" | "close";
      text: string;
      usage: TokenUsage;
      turn: number;
    }
  | {
      kind: "tool_use";
      tool: string;
      input: unknown;
      subagentId?: string;
    }
  | {
      kind: "tool_result";
      tool: string;
      output: string;
      isError?: boolean;
      durationMs: number;
      subagentId?: string;
      subEntries?: SubagentEntry[];
    }
  | { kind: "compact" }
  | {
      kind: "result";
      subtype:
        | "success"
        | "error_max_turns"
        | "error_max_budget_usd"
        | "error_during_execution";
      text?: string;
    };

export type PendingTool = { spanId: string; start: number; subagentId?: string };

export type EngineRuntime = {
  openInteractionSpanId?: string | null;
  interactionStart?: number | null;
  currentTurn?: number;
  mirrorFailures?: number;
  mirrorAttempts?: number;
  initEmitted?: boolean;
  pid?: number | null;
  fast?: boolean;
  pendingTools?: Record<string, PendingTool>;
};
