import { db } from "@/db";
import { tenants, hosts, sessions, transcriptEntries, spanEvents } from "@/db/schema";
import { sql } from "drizzle-orm";
import {
  createSession,
  tickSession,
  crashSession,
  suspendSession,
  resumeSession,
  forkSession,
  getSessionDetail,
} from "./runner";

async function fastForward(id: string, opts: { until?: "idle" | "terminal"; maxTicks?: number } = {}) {
  let guard = 0;
  // First tick (init) is already emitted by createSession.
  while (guard < 60) {
    const detail = await getSessionDetail(id);
    if (!detail) break;
    const st = detail.session.status;
    if (st === "awaiting_input" && opts.until !== "terminal") break;
    if (["completed", "failed", "evicted", "suspended"].includes(st)) break;
    const r = await tickSession(id, { force: true });
    if (!r.advanced && st !== "starting") break;
    guard++;
    if (opts.maxTicks && guard >= opts.maxTicks) break;
  }
}

// Spread timestamps so the fleet looks like it has been running for hours.
async function backdate(sessionId: string, startOffsetMin: number, stepSec = 5) {
  const [session] = await db.select().from(sessions).where(sql`${sessions.id} = ${sessionId}`);
  if (!session) return;
  const base = new Date(Date.now() - startOffsetMin * 60_000);

  const entries = await db
    .select({ id: transcriptEntries.id, seq: transcriptEntries.seq })
    .from(transcriptEntries)
    .where(sql`${transcriptEntries.sessionId} = ${sessionId}`)
    .orderBy(transcriptEntries.seq);
  for (const e of entries) {
    await db
      .update(transcriptEntries)
      .set({ createdAt: new Date(base.getTime() + e.seq * stepSec * 1000) })
      .where(sql`${transcriptEntries.id} = ${e.id}`);
  }
  const spans = await db
    .select({ id: spanEvents.id })
    .from(spanEvents)
    .where(sql`${spanEvents.sessionId} = ${sessionId}`)
    .orderBy(spanEvents.startedAt, spanEvents.durationMs);
  await Promise.all(
    spans.map((s, i) =>
      db
        .update(spanEvents)
        .set({ startedAt: new Date(base.getTime() + i * stepSec * 700) })
        .where(sql`${spanEvents.id} = ${s.id}`)
    )
  );

  const terminal = ["completed", "failed"].includes(session.status);
  const endDate = new Date(base.getTime() + entries.length * stepSec * 1000);
  await db
    .update(sessions)
    .set({
      startedAt: base,
      lastActiveAt: terminal ? endDate : new Date(Date.now() - startOffsetMin * 45_000),
      ...(terminal ? { endedAt: endDate } : {}),
    })
    .where(sql`${sessions.id} = ${sessionId}`);
}

export async function seedDatabase(wipe = true) {
  if (wipe) {
    await db.delete(spanEvents);
    await db.delete(transcriptEntries);
    await db.delete(sessions);
    await db.delete(hosts);
    await db.delete(tenants);
  }

  const tenantRows = [
    {
      id: "acme-corp",
      name: "Acme Corp",
      tier: "enterprise",
      endUserLabel: "employee",
      workdirRoot: "/srv/work",
      configRoot: "/srv/config",
      isolateSettings: true,
      disableAutoMemory: true,
      distinctEgress: true,
      egressPolicy: "per-tenant outbound IP + domain allowlist",
    },
    {
      id: "globex",
      name: "Globex Industries",
      tier: "enterprise",
      endUserLabel: "customer",
      workdirRoot: "/srv/work",
      configRoot: "/srv/config",
      isolateSettings: true,
      disableAutoMemory: true,
      distinctEgress: true,
      egressPolicy: "shared egress, per-tenant credentials",
    },
    {
      id: "umbrellaco",
      name: "Umbrella Health",
      tier: "enterprise",
      endUserLabel: "clinician",
      workdirRoot: "/srv/hipaa-work",
      configRoot: "/srv/hipaa-config",
      isolateSettings: true,
      disableAutoMemory: true,
      distinctEgress: true,
      egressPolicy: "VPC-peered, TLS-terminating proxy",
    },
    {
      id: "initech",
      name: "Initech LLC",
      tier: "team",
      endUserLabel: "member",
      workdirRoot: "/srv/shared-work",
      configRoot: "/srv/shared-config",
      isolateSettings: false,
      disableAutoMemory: false,
      distinctEgress: false,
      egressPolicy: "shared container, shared settings (legacy)",
    },
  ];
  await db.insert(tenants).values(tenantRows);

  const hostRows = [
    { name: "k8s-node-a", provider: "kubernetes", region: "us-east-1", runtime: "node", ramMb: 8192, cpus: 4, overheadMb: 1024, perSessionRamMb: 1024, note: "EKS pool · pinned by consistent hash" },
    { name: "k8s-node-b", provider: "kubernetes", region: "eu-west-1", runtime: "python", ramMb: 8192, cpus: 4, overheadMb: 1024, perSessionRamMb: 1024, note: "EKS pool · EU residency" },
    { name: "docker-runner-01", provider: "docker", region: "us-east-1", runtime: "node", ramMb: 4096, cpus: 2, overheadMb: 512, perSessionRamMb: 1024, note: "Hardened: cap-drop, seccomp, network none + proxy sock" },
    { name: "modal-worker-07", provider: "modal", region: "us-east-2", runtime: "python", ramMb: 4096, cpus: 2, overheadMb: 384, perSessionRamMb: 900, note: "Per-second sandbox · sub-second cold start" },
    { name: "gvisor-host-02", provider: "gvisor", region: "eu-central-1", runtime: "node", ramMb: 8192, cpus: 4, overheadMb: 768, perSessionRamMb: 1200, note: "runsc runtime · untrusted content" },
    { name: "firecracker-cell-3", provider: "firecracker", region: "ap-southeast-1", runtime: "python", ramMb: 2048, cpus: 2, overheadMb: 256, perSessionRamMb: 900, note: "microVM · vsock-only egress" },
  ];
  const insertedHosts = await db.insert(hosts).values(hostRows).returning();
  const host = Object.fromEntries(insertedHosts.map((h) => [h.name, h.id]));

  // ── Completed ephemeral: bug fix ──
  const bugfix = await createSession({
    tenantId: "acme-corp",
    hostId: host["docker-runner-01"],
    prompt: "Fix the flaky auth rate limit test — the limiter seems to reset between attempts.",
    sdk: "typescript",
    pattern: "ephemeral",
    model: "claude-sonnet-4-5",
    storeBackend: "postgres",
    endUserId: "employee-412",
  });
  await fastForward(bugfix.id);
  await backdate(bugfix.id, 320);

  // ── Completed ephemeral: receipt extraction (Python, S3, Modal) ──
  const extract = await createSession({
    tenantId: "globex",
    hostId: host["modal-worker-07"],
    prompt: "Extract invoices and receipt totals from the receipts folder into JSON.",
    sdk: "python",
    pattern: "ephemeral",
    model: "claude-sonnet-4-5-vertex",
    storeBackend: "s3",
    endUserId: "customer-9034",
  });
  await fastForward(extract.id);
  await backdate(extract.id, 240);

  // ── Long-running warm: email triage agent (Redis store) ──
  const triage = await createSession({
    tenantId: "acme-corp",
    hostId: host["k8s-node-a"],
    prompt: "Triage the support inbox and draft replies; do not send without approval.",
    sdk: "typescript",
    pattern: "long-running",
    model: "claude-opus-4-1",
    storeBackend: "redis",
    endUserId: "employee-077",
  });
  await fastForward(triage.id);
  await backdate(triage.id, 95);

  // ── Hybrid deep research, then suspended (durable in Postgres) ──
  const research = await createSession({
    tenantId: "umbrellaco",
    hostId: host["gvisor-host-02"],
    prompt: "Compile a Q4 competitor pricing and feature scan for the security review.",
    sdk: "typescript",
    pattern: "hybrid",
    model: "claude-sonnet-4-5",
    storeBackend: "postgres",
    endUserId: "clinician-12",
  });
  await fastForward(research.id);
  await backdate(research.id, 180);
  await suspendSession(research.id);

  // Resumed on a different host after spin-down (hydrate-from-store demo).
  const resumed = await resumeSession(research.id, host["k8s-node-b"]);
  await fastForward(resumed.id);
  await backdate(resumed.id, 35);

  // ── Legacy tenant: long-running with NO store, suspended = transcript lost ──
  const site = await createSession({
    tenantId: "initech",
    hostId: host["docker-runner-01"],
    prompt: "Publish Vera's bakery website from the hosted template.",
    sdk: "typescript",
    pattern: "long-running",
    model: "claude-haiku-4-5",
    storeBackend: "none",
    endUserId: "member-5",
  });
  await fastForward(site.id);
  await backdate(site.id, 60);
  await suspendSession(site.id);

  // ── Ephemeral translation (Haiku, cheap, fast) ──
  const translate = await createSession({
    tenantId: "globex",
    hostId: host["modal-worker-07"],
    prompt: "Translate the marketing overview pages into Spanish and German.",
    sdk: "python",
    pattern: "ephemeral",
    model: "claude-haiku-4-5",
    storeBackend: "s3",
    endUserId: "customer-2201",
  });
  await fastForward(translate.id);
  await backdate(translate.id, 150);

  // ── Multi-agent container: parallel audit ──
  const multi = await createSession({
    tenantId: "acme-corp",
    hostId: host["gvisor-host-02"],
    prompt: "Audit the payments retry change with two agents working in separate directories.",
    sdk: "typescript",
    pattern: "multi-agent",
    model: "claude-sonnet-4-5",
    storeBackend: "s3",
    endUserId: "employee-412",
  });
  await fastForward(multi.id);
  await backdate(multi.id, 75);

  // ── Failed: maxTurns too low ──
  const limited = await createSession({
    tenantId: "umbrellaco",
    hostId: host["firecracker-cell-3"],
    prompt: "Investigate why invoice OCR drops line items on scanned receipts.",
    sdk: "python",
    pattern: "ephemeral",
    model: "claude-sonnet-4-5",
    maxTurns: 1,
    storeBackend: "postgres",
    endUserId: "clinician-30",
  });
  await fastForward(limited.id);
  await backdate(limited.id, 210);

  // ── Failed: CLI crashed (exit 137 OOM) ──
  const crashed = await createSession({
    tenantId: "globex",
    hostId: host["modal-worker-07"],
    prompt: "Reindex all customer documents and rebuild embeddings.",
    sdk: "python",
    pattern: "ephemeral",
    model: "claude-opus-4-1",
    storeBackend: "s3",
    endUserId: "customer-7710",
  });
  await fastForward(crashed.id, { maxTicks: 4 });
  await crashSession(crashed.id);
  await backdate(crashed.id, 45);

  // ── Media transform on flaky S3 store — mirror errors present ──
  const media = await createSession({
    tenantId: "acme-corp",
    hostId: host["firecracker-cell-3"],
    prompt: "Transcode the keynote video to 1080p and 720p H.264 ladders with thumbnails.",
    sdk: "python",
    pattern: "ephemeral",
    model: "claude-haiku-4-5",
    storeBackend: "s3",
    storeFlaky: true,
    endUserId: "employee-233",
  });
  await fastForward(media.id);
  await backdate(media.id, 25);

  // ── Fork of the completed bugfix exploring an alternative ──
  const fork = await forkSession(bugfix.id);
  await fastForward(fork.id);
  await backdate(fork.id, 280);

  // ── Live right now: billing inbox triage mid-run on the K8s pool ──
  const live = await createSession({
    tenantId: "globex",
    hostId: host["k8s-node-a"],
    prompt: "Triage the billing inbox, apply labels and draft answers for overdue invoices.",
    sdk: "typescript",
    pattern: "long-running",
    model: "claude-opus-4-1",
    storeBackend: "redis",
    storeFlaky: true,
    endUserId: "customer-1188",
  });
  await fastForward(live.id, { maxTicks: 3 });

  const counts = {
    tenants: tenantRows.length,
    hosts: hostRows.length,
    sessions: await db.select({ c: sql<string>`count(*)` }).from(sessions),
    entries: await db.select({ c: sql<string>`count(*)` }).from(transcriptEntries),
    spans: await db.select({ c: sql<string>`count(*)` }).from(spanEvents),
  };
  return {
    tenants: tenantRows.length,
    hosts: hostRows.length,
    sessions: Number(counts.sessions[0].c),
    entries: Number(counts.entries[0].c),
    spans: Number(counts.spans[0].c),
  };
}
