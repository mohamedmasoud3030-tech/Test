const base = "http://127.0.0.1:3000";
async function post(path, body) {
  const r = await fetch(`${base}${path}`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(()=>null) };
}
// duplicate -> 409 now
console.log("dup acme:", JSON.stringify(await post("/api/tenants", { name: "Acme Corp" })));
// empty -> 400
console.log("empty:", JSON.stringify(await post("/api/tenants", { name: "  " })));

// stop flow on a parked long-running session
const launch = await post("/api/sessions", { tenantId:"acme-corp", prompt:"Triage the support inbox and draft replies", pattern:"long-running", storeBackend:"redis" });
const id = launch.body.id;
async function status(){ return (await (await fetch(`${base}/api/sessions/${id}?drive=1`)).json()).session; }
let s;
for (let i=0;i<80;i++){ s = await status(); if (!["starting","running"].includes(s.status)) break; await new Promise(r=>setTimeout(r,180)); }
console.log("parked:", s.status);
await post(`/api/sessions/${id}/actions`, { action:"turn", prompt:"Deploy and ship it now" });
for (let i=0;i<80;i++){ s = await status(); if (!["starting","running"].includes(s.status)) break; await new Promise(r=>setTimeout(r,180)); }
console.log("after turn:", s.status, s.resultSubtype);
await post(`/api/sessions/${id}/actions`, { action:"stop" });
for (let i=0;i<80;i++){ s = await status(); if (!["starting","running"].includes(s.status)) break; await new Promise(r=>setTimeout(r,180)); }
console.log("after stop:", s.status, s.resultSubtype);

// pages render
for (const p of ["/","/tenants","/sessions","/launch","/fleet","/patterns","/storage","/observability","/security","/troubleshooting"]) {
  const r = await fetch(`${base}${p}`);
  console.log("page", p, r.status);
}
