// Static, documentation-grounded reference content for the hosting runbooks.
// Sources: code.claude.com/docs/en/agent-sdk/{hosting,session-storage,
// observability,secure-deployment,troubleshooting,sessions,cost-tracking}.

export const STATE_ON_DISK = [
  {
    state: "Session transcripts",
    location: "~/.claude/projects/  (or projects/ under CLAUDE_CONFIG_DIR)",
    survives: false,
    persistence: "Attach a SessionStore adapter (S3 / Redis / Postgres / custom).",
  },
  {
    state: "CLAUDE.md memory files",
    location: "~/.claude/CLAUDE.md (user tier) and the session's cwd (project tier)",
    survives: false,
    persistence: "Mount a shared volume or sync with your own object-store pipeline.",
  },
  {
    state: "Working-directory artifacts",
    location: "The session's working directory",
    survives: false,
    persistence: "Per-tenant mounted volumes, tmpfs for ephemeral work, or artifact upload.",
  },
];

export const PATTERNS = [
  {
    id: "ephemeral",
    name: "Ephemeral sessions",
    icon: "⚡",
    lifetime: "One container per task — destroyed on completion",
    bestFor: "One-off tasks with a clear finish line",
    workloads: ["Bug investigation & fix", "Invoice / receipt extraction", "Document translation", "Media transformation"],
    storeRequired: false,
    coldStart: "Sub-second required",
    billing: "Per-second",
    points: [
      "One-shot entrypoint reads the task from TASK_PROMPT, calls query(), exits.",
      "A result message with subtype 'success' marks clean completion.",
      "Hitting maxTurns yields subtype 'error_max_turns' and the query throws after yielding it — wrap the loop in try/catch.",
    ],
  },
  {
    id: "long-running",
    name: "Long-running sessions",
    icon: "🛰️",
    lifetime: "Persistent containers holding many live subprocesses",
    bestFor: "Autonomous agents, served content, high-volume streams",
    workloads: ["Email triage agent", "Per-user site builder over container ports", "Slack / platform chat bots"],
    storeRequired: false,
    coldStart: "Tolerates slower starts (pre-warm with startup())",
    billing: "Hourly",
    points: [
      "Expose HTTP/WebSocket; map each active session to a long-lived query + subprocess.",
      "TypeScript: streamInput() adds turns, startup() pre-warms subprocesses.",
      "Python: ClaudeSDKClient holds a session open across turns.",
      "Pin each session to one container (consistent hashing on sessionId) behind a load balancer.",
    ],
  },
  {
    id: "hybrid",
    name: "Hybrid sessions",
    icon: "🌗",
    lifetime: "Ephemeral containers that hydrate from a store, spin down when idle",
    bestFor: "Sessions spanning many interactions with idle gaps",
    workloads: ["Personal project manager", "Deep research paused/resumed over hours", "Support agent loading ticket history"],
    storeRequired: true,
    coldStart: "Fast hydration from the shared store",
    billing: "Per-second + storage",
    points: [
      "Resume by ID with a shared SessionStore attached: options { resume: sessionId, sessionStore }.",
      "Shutting down without a SessionStore loses the transcript — the store is required, not optional.",
      "A resumed run restores the transcript into a temp CLAUDE_CONFIG_DIR and deletes it at run end.",
      "Tune the provider idle timeout to expected user return frequency.",
    ],
  },
  {
    id: "multi-agent",
    name: "Multi-agent container",
    icon: "🤝",
    lifetime: "Multiple SDK subprocesses collaborating in one container",
    bestFor: "Tightly-coupled multi-agent simulations and shared environments",
    workloads: ["Multi-agent simulations", "Parallel audit + implementation", "Adversarial review pairs"],
    storeRequired: false,
    coldStart: "Long-running style",
    billing: "Hourly, N× agents",
    points: [
      "Give every agent its own working directory so they never overwrite each other's files.",
      "Isolate settings loading so per-agent CLAUDE.md files do not leak across agents.",
      "Subagent transcripts mirror under subpath subagents/agent-<id>.",
      "Wide parallel subagent fan-outs can hit rate limits — batch the dispatch.",
    ],
  },
] as const;

export const STORE_METHODS = [
  { method: "append(key, entries)", required: true, when: "After each batch is written to local JSONL — mirror it to your backend." },
  { method: "load(key)", required: true, when: "Before the subprocess spawns on resume/continue; return null when unknown." },
  { method: "listSessions(projectKey)", required: false, when: "listSessions() and continue: true lookups." },
  { method: "listSessionSummaries(projectKey)", required: false, when: "One-call metadata listing; maintain summaries inside append via foldSessionSummary." },
  { method: "delete(key)", required: false, when: "deleteSession(); must cascade to subkeys and the summary." },
  { method: "listSubkeys(key)", required: false, when: "Resume-time discovery of subagent transcripts." },
];

export const ADAPTERS = [
  { name: "Postgres", tag: "This console", durability: "Durable", notes: "Relational table keyed by (projectKey, sessionId, subpath); transactions serialize the summary fold.", recommended: true },
  { name: "S3", tag: "Object store", durability: "Durable", notes: "Append via multipart/object rewrite; lifecycle policies give you retention. Great cross-host default.", recommended: false },
  { name: "Redis", tag: "Key/value", durability: "Configurable", notes: "Fast append/list; enable AOF/RDB persistence or accept ephemerality.", recommended: false },
  { name: "InMemory", tag: "Shipped with SDK", durability: "Ephemeral", notes: "InMemorySessionStore for development and tests only.", recommended: false },
  { name: "Custom", tag: "SessionStore interface", durability: "Up to you", notes: "Two required methods (append, load), four optional; run the conformance suite.", recommended: false },
];

export const STORE_BEHAVIORS = [
  {
    title: "Transcripts only",
    body: "SessionStore mirrors JSONL transcripts — not CLAUDE.md memory files or working-directory artifacts. Sync those separately.",
  },
  {
    title: "Mirror, not replacement",
    body: "The subprocess writes local disk first; the SDK then forwards a copy. Fresh runs leave a local transcript; a run resumed from the store deletes its local temp copy at the end.",
  },
  {
    title: "Best-effort writes",
    body: "A failed append retries twice with backoff (3 attempts). Timeouts are not retried. After that, the SDK emits a system/mirror_error message, drops the batch, and continues. Deduplicate redeliveries by entry.uuid.",
  },
  {
    title: "Retention is yours",
    body: "The SDK never deletes from your store. Enforce TTLs, S3 lifecycle policies, or scheduled cleanup. Local transcripts follow cleanupPeriodDays independently.",
  },
];

export const LIMITATIONS = [
  { limitation: "No top-level session timeout", fix: "Set maxTurns / max_turns to bound tool-use round trips." },
  { limitation: "Memory growth over long sessions", fix: "Cap session length or recycle subprocesses periodically; size hosts from measured peak RSS." },
  { limitation: "Wide parallel-subagent fanouts hit rate limits", fix: "Break work into smaller batches instead of one wide dispatch." },
  { limitation: "No per-subagent wall-clock deadline", fix: "Cap each subagent with maxTurns in its AgentDefinition; CLAUDE_ASYNC_AGENT_STALL_TIMEOUT_MS is a stall watchdog, not a runtime deadline." },
];

export const ISOLATION_TECH = [
  { tech: "Sandbox runtime", strength: "Good (secure defaults)", overhead: "Very low", complexity: "Low", note: "bubblewrap / sandbox-exec at the OS level; built-in proxy; no TLS inspection." },
  { tech: "Containers (Docker)", strength: "Setup dependent", overhead: "Low", complexity: "Medium", note: "Linux namespaces; harden with cap-drop, seccomp, read-only root, no network." },
  { tech: "gVisor (runsc)", strength: "Excellent (with correct setup)", overhead: "Medium / High", complexity: "Medium", note: "Userspace syscall interception; heavy open/close I/O can be 10–200× slower." },
  { tech: "VMs (Firecracker, QEMU)", strength: "Excellent (with correct setup)", overhead: "High", complexity: "Medium / High", note: "Own kernel per guest; Firecracker boots <125ms with <5 MiB overhead; vsock-only egress." },
];

export const DOCKER_FLAGS = [
  { flag: "--cap-drop ALL", purpose: "Removes Linux capabilities (NET_ADMIN, SYS_ADMIN) usable for privilege escalation." },
  { flag: "--security-opt no-new-privileges", purpose: "Blocks privilege gain through setuid binaries." },
  { flag: "--security-opt seccomp=profile.json", purpose: "Restricts available syscalls beyond Docker's ~44 defaults." },
  { flag: "--read-only", purpose: "Immutable root filesystem." },
  { flag: "--tmpfs /tmp:rw,noexec,nosuid,size=100m", purpose: "Writable, non-executable scratch that vanishes on stop." },
  { flag: "--network none", purpose: "No interfaces; egress only via a mounted Unix-socket proxy." },
  { flag: "--memory 2g --cpus 2", purpose: "Resource ceilings against exhaustion." },
  { flag: "--pids-limit 100", purpose: "Caps process count to stop fork bombs." },
  { flag: "--user 1000:1000", purpose: "Runs the agent as a non-root user." },
  { flag: "-v code:/workspace:ro", purpose: "Read-only code mount; never mount ~/.ssh, ~/.aws or ~/.config." },
  { flag: "-v proxy.sock:/var/run/proxy.sock:ro", purpose: "Host-side egress proxy enforcing allowlists and injecting credentials." },
  { flag: "--userns-remap / --ipc private", purpose: "Extra hardening: remap root, isolate IPC." },
];

export const SECRET_FILES = [
  ".env, .env.local",
  "~/.git-credentials",
  "~/.aws/credentials",
  "application_default_credentials.json",
  "~/.azure/",
  "~/.docker/config.json",
  "~/.kube/config",
  ".npmrc, .pypirc",
  "*-service-account.json",
  "*.pem, *.key",
];

export const AUTH_METHODS = [
  { env: "ANTHROPIC_API_KEY", note: "Subprocess reads it from its environment; supply from your secret manager.", provider: "Anthropic API" },
  { env: "ANTHROPIC_BASE_URL", note: "Route sampling calls through a proxy that injects the key outside the container.", provider: "API proxy" },
  { env: "CLAUDE_CODE_USE_BEDROCK=1", note: "Amazon Bedrock; configure AWS credentials via the proxy pattern.", provider: "Amazon Bedrock" },
  { env: "CLAUDE_CODE_USE_VERTEX=1", note: "Google Cloud Agent Platform; configure Google credentials.", provider: "Vertex" },
  { env: "CLAUDE_CODE_USE_FOUNDRY=1", note: "Microsoft Foundry; configure Azure credentials.", provider: "Microsoft Foundry" },
];

export const OTEL_SIGNALS = [
  { signal: "Metrics", contains: "Counters for tokens, cost, sessions, lines of code, tool decisions", enable: "OTEL_METRICS_EXPORTER=otlp", interval: "60s default" },
  { signal: "Log events", contains: "Structured records for prompts, API requests, errors, tool results", enable: "OTEL_LOGS_EXPORTER=otlp", interval: "5s default" },
  { signal: "Traces (beta)", contains: "Spans per interaction, model request, tool call, hook", enable: "OTEL_TRACES_EXPORTER=otlp + CLAUDE_CODE_ENHANCED_TELEMETRY_BETA=1", interval: "5s default" },
];

export const OTEL_SPANS = [
  { span: "claude_code.interaction", describes: "One full agent turn, prompt → response" },
  { span: "claude_code.llm_request", describes: "One Claude API call — model, latency, token counts" },
  { span: "claude_code.tool", describes: "A tool invocation, with blocked_on_user and execution children" },
  { span: "claude_code.hook", describes: "A hook execution (detailed beta tracing required)" },
];

export const OTEL_SENSITIVE = [
  { variable: "OTEL_LOG_USER_PROMPTS=1", adds: "Prompt text on user_prompt events and the interaction span" },
  { variable: "OTEL_LOG_TOOL_DETAILS=1", adds: "Tool input arguments — paths, shell commands, search patterns" },
  { variable: "OTEL_LOG_TOOL_CONTENT=1", adds: "Full tool input/output bodies as span events (60 KB truncation; needs traces)" },
  { variable: "OTEL_LOG_RAW_API_BODIES", adds: "Full Messages API request/response JSON (1, or file:<dir>); implies all of the above" },
];

export const TROUBLESHOOTING = [
  {
    id: "cli-not-found",
    title: "CLINotFoundError — Claude Code not found",
    category: "CLI startup",
    sdk: "Both",
    symptom: "Claude Code not found at: /your/configured/path · 'Native CLI binary for <platform>-<arch> not found'",
    cause: "Python: the service manager runs with a different PATH than your shell. TypeScript: the image build skipped npm optional dependencies, or pathToClaudeCodeExecutable points at a missing file.",
    fixes: [
      "Confirm `claude --version` works in the same environment the service runs in.",
      "Reinstall @anthropic-ai/claude-agent-sdk WITHOUT --omit=optional so the platform binary is present.",
      "Remove cli_path / pathToClaudeCodeExecutable to let the SDK prefer its bundled copy.",
      "Python source-dist installs (e.g. ARM64 Windows) need a separate native Claude Code install.",
    ],
  },
  {
    id: "batch-script",
    title: "CLIConnectionError — Refusing to execute batch script",
    category: "CLI startup",
    sdk: "Python · Windows",
    symptom: "Refusing to execute batch script 'C:\\Users\\you\\AppData\\Roaming\\npm\\claude.cmd'",
    cause: "cmd.exe re-parses the whole command line, so .bat/.cmd argument values can execute injected commands. The refusal is deliberate hardening.",
    fixes: [
      "Point cli_path at a native claude.exe (or remove it so discovery finds one).",
      "Install natively in PowerShell: irm https://claude.ai/install.ps1 | iex.",
      "On Windows x64, install the claude-agent-sdk wheel, which bundles claude.exe.",
    ],
  },
  {
    id: "failed-to-start",
    title: "CLIConnectionError — Failed to start Claude Code",
    category: "CLI startup",
    sdk: "Both",
    symptom: "Claude Code native binary at <path> exists but failed to launch (libc suggestion appended)",
    cause: "The resolved path points at a text file/directory, lost its execute bit, or the bundled binary doesn't match the image architecture or libc.",
    fixes: [
      "Rebuild the image for its target architecture and reinstall the SDK during the build so the binary matches.",
      "Restore execute permission on the binary.",
      "Prefer the bundled binary by removing custom path overrides.",
    ],
  },
  {
    id: "not-connected",
    title: "CLIConnectionError — Not connected",
    category: "CLI startup",
    sdk: "Python",
    symptom: "Not connected. Call connect() first.",
    cause: "A ClaudeSDKClient method was called before connect() or after disconnect.",
    fixes: ["Call await client.connect() first, or use `async with ClaudeSDKClient() as client:`."],
  },
  {
    id: "exit-code",
    title: "ProcessError — Command failed with exit code",
    category: "CLI process exit",
    sdk: "Python",
    symptom: "Command failed with exit code 1 (exit code: 1) · Error output: Check stderr output for details",
    cause: "The CLI exited nonzero without reporting an error result. The 'Error output' line is fixed text; real stderr needs a stderr callback.",
    fixes: [
      "Pass a stderr callback in ClaudeAgentOptions and log what it receives.",
      "Catch ResultError before ProcessError (ResultError subclasses it) to distinguish error results.",
    ],
  },
  {
    id: "ts-exit",
    title: "Claude Code process exited with code N / terminated by signal",
    category: "CLI process exit",
    sdk: "TypeScript",
    symptom: "Claude Code process exited with code 1. stderr: <tail of CLI stderr>",
    cause: "Nonzero CLI exit rejects the for-await loop; there is no SDK error class to catch.",
    fixes: ["Wrap the loop in try/catch and match on the message.", "Pass a stderr callback to capture the full stream."],
  },
  {
    id: "error-result",
    title: "Claude Code returned an error result",
    category: "CLI process exit",
    sdk: "Both",
    symptom: "Claude Code returned an error result: <the CLI's own error report>",
    cause: "The CLI reported a structured error result before exiting (Python: ResultError with .data; TypeScript: plain Error).",
    fixes: ["Start from the CLI's report text after the colon — it carries the actual failure.", "All result subtypes still carry total_cost_usd, usage, num_turns and session_id for accounting/resume."],
  },
  {
    id: "max-turns",
    title: "Result subtype error_max_turns",
    category: "Agent loop",
    sdk: "Both",
    symptom: "ResultMessage.subtype === 'error_max_turns'; query() throws after yielding it",
    cause: "The agent used its full turn budget before finishing — common in one-shot containers.",
    fixes: ["Raise maxTurns / max_turns.", "Resume the session by ID with a higher ceiling; the transcript is preserved.", "Wrap single-shot loops in try/catch so the container exits cleanly."],
  },
  {
    id: "mirror-error",
    title: "system/mirror_error — store batch dropped",
    category: "Session storage",
    sdk: "Both",
    symptom: "{ type: 'system', subtype: 'mirror_error' } appears in the message stream",
    cause: "SessionStore.append() rejected after 3 attempts, or timed out (timeouts are not retried). The batch is dropped; the agent keeps running from local disk.",
    fixes: [
      "Alert on mirror_error when store durability matters.",
      "On a run resumed from the store, a dropped batch has no surviving copy after run end.",
      "Deduplicate redelivered batches by entry.uuid in append().",
    ],
  },
  {
    id: "structured-none",
    title: "structured_output is None on a success result",
    category: "Structured outputs",
    sdk: "Both",
    symptom: "subtype 'success' but structured_output is null / undefined",
    cause: "A schema no output can satisfy (e.g. conflicting length constraints) ends the run without a validation error.",
    fixes: ["Treat this as a failure in application code.", "Loosen or reconcile the schema constraints."],
  },
] as const;

export const PROVIDER_QUESTIONS = [
  { q: "Who runs the sandbox?", a: "Sandbox-as-a-service operates it for you; self-hosted (Docker, gVisor, Firecracker) gives you software to run." },
  { q: "Cold-start latency?", a: "Ephemeral patterns need sub-second starts; long-running patterns tolerate far more." },
  { q: "Persistent storage?", a: "Hybrid needs durable volumes or a shared store; ephemeral can run on tmpfs only." },
  { q: "Pricing model?", a: "Per-second suits bursty ephemeral work; hourly suits long-running sessions." },
  { q: "Networking controls?", a: "Look for egress rules, outbound proxies, and private VPC peering for regulated environments." },
];

export const RUNTIME_DEPS = [
  "Python 3.10+ for the Python SDK, or Node.js 18+ for the TypeScript SDK",
  "Both SDKs bundle a native Claude Code binary for most installs — the spawned CLI needs no separate Node install",
  "The binary is pinned to the SDK package version: update the SDK to update the CLI (semver; take patches continuously)",
  "Starting footprint: 1 GiB RAM, 5 GiB disk, 1 CPU per agent — a floor, not a ceiling",
];

export const NETWORK_NOTES = [
  "Outbound HTTPS to api.anthropic.com — or your Bedrock / Vertex regional endpoint.",
  "MCP servers and external tools need outbound access to their own endpoints.",
  "Route egress through a proxy: domain allowlists, credential injection, request logging.",
  "Inbound: expose HTTP/WebSocket yourself; the subprocess never listens on the network.",
];

export const SUBPROCESS_FLOW = [
  { step: 1, title: "Client request", body: "Your app receives an authenticated task at its HTTP/WS endpoint." },
  { step: 2, title: "Spawn", body: "query() spawns a separate claude CLI process; one session = one subprocess with its own process tree." },
  { step: 3, title: "stdio", body: "SDK and CLI exchange the message stream over stdin/stdout: init → assistant/tool messages → result." },
  { step: 4, title: "Local state", body: "The subprocess owns the shell, cwd, and JSONL transcripts under CLAUDE_CONFIG_DIR." },
  { step: 5, title: "Dual-write", body: "Each transcript batch is written locally first, then mirrored to the SessionStore." },
  { step: 6, title: "Model calls", body: "The CLI calls api.anthropic.com (or a regional endpoint) over HTTPS via the egress proxy." },
  { step: 7, title: "Shutdown", body: "Ephemeral containers exit and are destroyed; long-running park the subprocess; resumed runs delete their temp config dir." },
];
