"use client";

import { useEffect, useState } from "react";
import { Card, Button, Badge, Tabs, CodeBlock, Field, Toggle, SectionTitle, Toast } from "@/components/ui";
import { isolationSnippet } from "@/lib/generators";
import { usd } from "@/lib/util";

type Tenant = {
  id: string;
  name: string;
  tier: string;
  endUserLabel: string;
  workdirRoot: string;
  configRoot: string;
  isolateSettings: boolean;
  disableAutoMemory: boolean;
  distinctEgress: boolean;
  egressPolicy: string;
  sessions: string;
  live: string | null;
  cost: string;
};

export default function TenantsPage() {
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [selected, setSelected] = useState<string>("");
  const [form, setForm] = useState({ name: "", tier: "enterprise", endUserLabel: "enduser", regulatory: false, distinctEgress: true, isolate: true, memory: true });
  const [toast, setToast] = useState<string | null>(null);

  const load = async () => {
    const d = await (await fetch("/api/tenants", { cache: "no-store" })).json();
    setTenants(d.tenants);
    setSelected((cur) => cur || d.tenants[0]?.id || "");
  };
  useEffect(() => {
    load();
  }, []);

  const current = tenants.find((t) => t.id === selected);

  async function create() {
    if (!form.name) return;
    const r = await fetch("/api/tenants", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: form.name,
        tier: form.tier,
        endUserLabel: form.endUserLabel,
        regulatory: form.regulatory,
        distinctEgress: form.distinctEgress,
        isolateSettings: form.isolate,
        disableAutoMemory: form.memory,
      }),
    });
    const body = await r.json();
    if (!r.ok) return setToast(body.error ?? "Failed");
    setForm({ ...form, name: "" });
    await load();
    setSelected(body.id);
  }

  return (
    <div className="p-8 max-w-[1280px] mx-auto">
      <header className="mb-6">
        <h1 className="text-xl font-semibold text-zinc-100">Tenants &amp; isolation</h1>
        <p className="text-[13px] text-zinc-500 mt-1">
          On a shared container, default settings loading and <span className="mono text-zinc-300">CLAUDE.md</span> auto-memory can leak one tenant&apos;s context into
          another&apos;s session. Each tenant below gets its own <span className="mono text-zinc-300">cwd</span>, <span className="mono text-zinc-300">CLAUDE_CONFIG_DIR</span>,
          and egress identity.
        </p>
      </header>

      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-12 lg:col-span-7 space-y-3">
          {tenants.map((t) => {
            const score = [t.isolateSettings, t.disableAutoMemory, true, true, t.distinctEgress].filter(Boolean).length;
            const insecure = !t.isolateSettings || !t.disableAutoMemory || !t.distinctEgress;
            return (
              <Card key={t.id} hover className={selected === t.id ? "!border-[#d97757]/50" : ""}>
                <button className="w-full text-left" onClick={() => setSelected(t.id)}>
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="text-[14px] font-semibold text-zinc-100">{t.name}</span>
                    <Badge tone={t.tier === "enterprise" ? "violet" : "zinc"}>{t.tier}</Badge>
                    <span className="mono text-[11px] text-zinc-600">{t.id}</span>
                    <span className="ml-auto flex items-center gap-2">
                      {insecure ? <Badge tone="amber">shared config — leak risk</Badge> : <Badge tone="green">isolated · {score}/5 controls</Badge>}
                    </span>
                  </div>
                  <div className="grid grid-cols-3 gap-2 mt-3 text-[12px]">
                    <Stat label="sessions" value={String(t.sessions)} />
                    <Stat label="live" value={String(Number(t.live ?? 0))} />
                    <Stat label="spend" value={usd(Number(t.cost))} />
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-3">
                    <Control ok={t.isolateSettings} label="settingSources: []" />
                    <Control ok={t.disableAutoMemory} label="auto memory off" />
                    <Control ok label="per-tenant config dir" />
                    <Control ok label="per-tenant cwd" />
                    <Control ok={t.distinctEgress} label="distinct egress" />
                  </div>
                </button>
              </Card>
            );
          })}
        </div>

        <div className="col-span-12 lg:col-span-5 space-y-4">
          <Card>
            <SectionTitle title="Onboard tenant" />
            <div className="space-y-2.5">
              <input className="input-dark" placeholder="Tenant name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <div className="grid grid-cols-2 gap-2">
                <select className="input-dark" value={form.tier} onChange={(e) => setForm({ ...form, tier: e.target.value })}>
                  <option value="enterprise">enterprise</option>
                  <option value="team">team</option>
                </select>
                <input className="input-dark" placeholder="end-user label" value={form.endUserLabel} onChange={(e) => setForm({ ...form, endUserLabel: e.target.value })} />
              </div>
              <Toggle checked={form.isolate} onChange={(v) => setForm({ ...form, isolate: v })} label="settingSources = []" />
              <Toggle checked={form.memory} onChange={(v) => setForm({ ...form, memory: v })} label="CLAUDE_CODE_DISABLE_AUTO_MEMORY = 1" />
              <Toggle checked={form.distinctEgress} onChange={(v) => setForm({ ...form, distinctEgress: v })} label="Distinct egress identity per tenant" />
              <Toggle checked={form.regulatory} onChange={(v) => setForm({ ...form, regulatory: v })} label="Regulated workspace (separate volume roots)" />
              <Button variant="primary" className="w-full justify-center" onClick={create}>Add tenant</Button>
            </div>
          </Card>

          {current && (
            <Card>
              <SectionTitle title={`Isolation config · ${current.name}`} subtitle="Drop-in per-tenant options for every query() call." />
              <Tabs
                tabs={[
                  { key: "ts", label: "TypeScript", content: <CodeBlock lang="typescript" code={isolationSnippet(current, "typescript")} /> },
                  { key: "py", label: "Python", content: <CodeBlock lang="python" code={isolationSnippet(current, "python")} /> },
                ]}
              />
              <div className="mt-3 rounded-lg border border-[#232a35] bg-[#11151c] p-3 text-[11.5px] text-zinc-500 leading-relaxed">
                <b className="text-zinc-300">Egress:</b> {current.egressPolicy}. In TypeScript <span className="mono">env</span> replaces the subprocess environment —
                spread <span className="mono">...process.env</span> first so PATH and ANTHROPIC_API_KEY survive. In Python, env merges on top.
              </div>
            </Card>
          )}
        </div>
      </div>
      <Toast message={toast} />
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-[#11151c] border border-[#1f2530] px-2.5 py-2">
      <div className="text-[10px] uppercase tracking-wider text-zinc-600">{label}</div>
      <div className="mono text-[13px] text-zinc-200 mt-0.5">{value}</div>
    </div>
  );
}

function Control({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span className={`badge ${ok ? "bg-emerald-500/10 text-emerald-300 border-emerald-500/25" : "bg-rose-500/10 text-rose-300 border-rose-500/25"}`}>
      {ok ? "✓" : "✕"} {label}
    </span>
  );
}
