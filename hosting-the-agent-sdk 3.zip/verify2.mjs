const base = "http://127.0.0.1:3000";
async function post(path, body) {
  const r = await fetch(`${base}${path}`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify(body) });
  return { status: r.status, body: await r.json().catch(()=>null) };
}
async function driveUntilSettled(id, maxIt=90){
  let s;
  for (let i=0;i<maxIt;i++){
    const d = await (await fetch(`${base}/api/sessions/${id}?drive=1`)).json();
    s = d.session;
    if (!["starting","running"].includes(s.status)) return s;
    await new Promise(r=>setTimeout(r,170));
  }
  return s;
}
// A: parked then stop
let l = await post("/api/sessions", { tenantId:"acme-corp", prompt:"Triage the support inbox and draft replies", pattern:"long-running", storeBackend:"redis" });
let s = await driveUntilSettled(l.body.id);
console.log("A parked:", s.status);
await post(`/api/sessions/${l.body.id}/actions`, { action:"stop" });
s = await driveUntilSettled(l.body.id, 10);
console.log("A after stop:", s.status, s.resultSubtype);

// B: stop while running mid-plan (immediate stop right after launch)
let l2 = await post("/api/sessions", { tenantId:"globex", prompt:"Compile a Q4 competitor pricing scan with a subagent", pattern:"multi-agent", storeBackend:"s3" });
await new Promise(r=>setTimeout(r,400));
await post(`/api/sessions/${l2.body.id}/actions`, { action:"stop" });
s = await driveUntilSettled(l2.body.id);
console.log("B mid-run stop:", s.status, s.resultSubtype);

// C: new tenant long ID renders (smoke)
const html = await (await fetch(`${base}/tenants`)).text();
console.log("tenants html has mobile bar:", html.includes("Open navigation"), "| has toggle label:", html.includes("CLAUDE_CODE_DISABLE_AUTO_MEMORY"));
