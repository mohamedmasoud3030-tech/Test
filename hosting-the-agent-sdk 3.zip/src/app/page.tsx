import { getStats } from "@/lib/queries";
import { seedDatabase } from "@/lib/seed";
import { OverviewClient } from "@/components/OverviewClient";

export const dynamic = "force-dynamic";

export default async function OverviewPage() {
  let stats = await getStats();
  if (stats.totalSessions === 0 && stats.hosts === 0) {
    try {
      await seedDatabase(true);
      stats = await getStats();
    } catch (err) {
      console.error("seed failed", err);
    }
  }
  return <OverviewClient initial={stats} />;
}
