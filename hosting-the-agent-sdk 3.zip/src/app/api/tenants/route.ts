import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { tenants } from "@/db/schema";
import { listTenants } from "@/lib/queries";
import { slugify } from "@/lib/util";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ tenants: await listTenants() });
}

export async function POST(req: NextRequest) {
  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Request body must be valid JSON." }, { status: 400 });
  }
  const b = (body ?? {}) as Record<string, unknown>;

  const name = typeof b.name === "string" ? b.name.trim() : "";
  if (!name) {
    return NextResponse.json({ error: "Tenant name is required." }, { status: 400 });
  }
  if (name.length > 120) {
    return NextResponse.json({ error: "Tenant name must be 120 characters or fewer." }, { status: 400 });
  }

  // Explicit id wins; otherwise derive a slug from the name.
  const rawId = typeof b.id === "string" && b.id.trim() ? b.id.trim() : name;
  const id = slugify(rawId);
  if (!id) {
    return NextResponse.json(
      { error: "Could not derive a tenant id from that name — use letters and numbers." },
      { status: 400 }
    );
  }

  const endUserLabel = typeof b.endUserLabel === "string" && b.endUserLabel.trim() ? b.endUserLabel.trim() : "enduser";
  const regulatory = !!b.regulatory;
  const distinctEgress = !!b.distinctEgress;
  const root = regulatory ? "/srv/regulated-work" : "/srv/work";
  const configRoot = regulatory ? "/srv/regulated-config" : "/srv/config";

  try {
    await db.insert(tenants).values({
      id,
      name,
      tier: b.tier === "team" ? "team" : "enterprise",
      endUserLabel,
      workdirRoot: root,
      configRoot,
      isolateSettings: b.isolateSettings !== false,
      disableAutoMemory: b.disableAutoMemory !== false,
      distinctEgress,
      egressPolicy: distinctEgress ? "per-tenant outbound identity" : "shared egress",
    });
  } catch (err) {
    // Postgres unique_violation on the primary key (tenant slug). Drizzle
    // wraps the driver error, so check both the error and its cause.
    const code =
      (typeof err === "object" && err !== null && "code" in err && (err as { code?: string }).code) ||
      (typeof err === "object" && err !== null && "cause" in err && (err as { cause?: { code?: string } }).cause?.code);
    if (code === "23505") {
      return NextResponse.json({ error: `Tenant id “${id}” already exists.` }, { status: 409 });
    }
    console.error("tenant creation failed", err);
    return NextResponse.json({ error: "Database error while creating the tenant." }, { status: 502 });
  }
  return NextResponse.json({ id }, { status: 201 });
}
