"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Card, Field, Toggle, Button, PatternBadge, Badge, Toast } from "@/components/ui";
import { PATTERNS } from "@/lib/content";

type Tenant = { id: string; name: string };
type Host = { id: string; name: string; provider: string; region: string; runtime: string; status: string };

const PRESETS = [
  { label: "⚡ Bug fix", prompt: "Fix the flaky auth rate limit test — the limiter seems to reset between attempts.", pattern: "ephemeral" },
  { label: "🧾 Extract", prompt: "Extract invoices and receipt totals from the receipts folder into structured JSON.", pattern: "ephemeral" },
  { label: "🌐 Translate", prompt: "Translate the marketing overview pages into Spanish and German while preserving Markdown.", pattern: "ephemeral" },
  { label: "🎬 Media", prompt: "Transcode the keynote video to 1080p and 720p H.264 ladders with thumbnails.", pattern: "ephemeral" },
  { label: "📨 Email agent", prompt: "Triage the support inbox and draft replies; do not send without approval.", pattern: "long-running" },
  { label: "🔬 Research", prompt: "Compile a Q4 competitor pricing and feature scan, with a subagent surveying pricing pages.", pattern: "hybrid" },
  { label: "🤝 Multi-agent", prompt: "Audit the payments retry change with two agents working in separate directories.", pattern: "multi-agent" },
];

const MODELS = [
  { id: "claude-sonnet-4-5", label: "Claude Sonnet 4.5 · $3 / $15 per MTok" },
  { id: "claude-opus-4-1", label: "Claude Opus 4.1 · $15 / $75 per MTok" },
  { id: "claude-haiku-4-5", label: "Claude Haiku 4.5 · $0.80 / $4 per MTok" },
  { id: "claude-sonnet-4-5-vertex", label: "Sonnet 4.5 · Google Vertex" },
  { id: "claude-opus-4-1-bedrock", label: "Opus 4.1 · Amazon Bedrock" },
];

export default function LaunchPage() {
  const router = useRouter();
  const [tenants, setTenants] = useState<Tenant[]>([]);
  const [hosts, setHosts] = useState<Host[]>([]);
  const [tenantId, setTenantId] = useState("");
  const [hostId, setHostId] = useState("auto");
  const [prompt, setPrompt] = useState(PRESETS[0].prompt);
  const [sdk, setSdk] = useState<"typescript" | "python">("typescript");
  const [pattern, setPattern] = useState("ephemeral");
  const [model, setModel] = useState("claude-sonnet-4-5");
  const [maxTurns, setMaxTurns] = useState(20);
  const [storeBackend, setStoreBackend] = useState("postgres");
  const [flaky, setFlaky] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    fetch("/api/tenants").then((r) => r.json()).then((d) => {
      setTenants(d.tenants);
      setTenantId((cur) => cur || d.tenants[0]?.id || "");
    });
    fetch("/api/hosts").then((r) => r.json()).then((d) => setHosts(d.hosts.filter((h: Host) => h.status === "active")));
  }, []);

  const chosenPattern = PATTERNS.find((p) => p.id === pattern)!;
  const storeRequired = chosenPattern.storeRequired;

  async function launch() {
    if (!tenantId || !prompt.trim()) return;
    setBusy(true);
    const r = await fetch("/api/sessions", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        tenantId,
        prompt,
        sdk,
        pattern,
        model,
        maxTurns: Number(maxTurns),
        storeBackend: storeRequired && storeBackend === "none" ? "postgres" : storeBackend,
        storeFlaky: flaky,
        hostId: hostId === "auto" ? undefined : hostId,
      }),
    });
    const body = await r.json();
    setBusy(false);
    if (!r.ok) {
      setToast(body.error ?? "Launch failed");
      return;
    }
    router.push(`/sessions/${body.id}`);
  }

  return (
    <div className="p-8 max-w-[1100px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-6">
        <div className="min-w-0">
        <h1 className="text-xl font-semibold text-zinc-100">Launch an agent</h1>
        <p className="text-[13px] text-zinc-500 mt-1">
          This spawns a simulated <span className="mono text-zinc-300">claude</span> CLI subprocess: it opens a message stream, writes a JSONL transcript, dual-mirrors
          batches to the selected SessionStore, and emits OpenTelemetry spans.
        </p>
        </div>
      </header>

      <div className="grid grid-cols-12 gap-4">
        <div className="col-span-12 lg:col-span-8 space-y-4">
          <Card>
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">Task</div>
            <div className="flex flex-wrap gap-1.5 mb-3">
              {PRESETS.map((p) => (
                <button
                  key={p.label}
                  className="badge bg-[#141a23] border-[#262d39] text-zinc-400 hover:text-zinc-100 hover:border-[#3a4455] cursor-pointer"
                  onClick={() => {
                    setPrompt(p.prompt);
                    setPattern(p.pattern);
                  }}
                >
                  {p.label}
                </button>
              ))}
            </div>
            <textarea className="input-dark min-h-[110px] resize-y" value={prompt} onChange={(e) => setPrompt(e.target.value)} />
          </Card>

          <Card>
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">Session pattern</div>
            <div className="grid grid-cols-2 gap-2.5">
              {PATTERNS.map((p) => (
                <button
                  key={p.id}
                  onClick={() => setPattern(p.id)}
                  className={`text-left rounded-xl border p-3.5 transition-colors ${
                    pattern === p.id ? "border-[#d97757]/60 bg-[#d97757]/[0.07]" : "border-[#232a35] bg-[#11151c] hover:border-[#3a4455]"
                  }`}
                >
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-[13px] font-semibold text-zinc-100">
                      {p.icon} {p.name}
                    </span>
                    {p.storeRequired && <Badge tone="violet">store required</Badge>}
                  </div>
                  <p className="text-[11.5px] text-zinc-500 leading-snug">{p.lifetime}</p>
                </button>
              ))}
            </div>
          </Card>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Card>
              <Field label="Tenant (multi-tenant isolation)">
                <select className="input-dark" value={tenantId} onChange={(e) => setTenantId(e.target.value)}>
                  {tenants.map((t) => (
                    <option key={t.id} value={t.id}>
                      {t.name} ({t.id})
                    </option>
                  ))}
                </select>
              </Field>
              <div className="h-3" />
              <Field label="SDK language">
                <div className="flex gap-2">
                  {(["typescript", "python"] as const).map((l) => (
                    <button key={l} onClick={() => setSdk(l)} className={`btn ${sdk === l ? "btn-primary" : "btn-ghost"}`}>
                      {l === "typescript" ? "TypeScript" : "Python"}
                    </button>
                  ))}
                </div>
              </Field>
              <div className="h-3" />
              <Field label="Target host" hint="Auto picks a host matching the SDK runtime; pin sessions with consistent hashing on sessionId.">
                <select className="input-dark" value={hostId} onChange={(e) => setHostId(e.target.value)}>
                  <option value="auto">Auto (scheduler decides)</option>
                  {hosts.map((h) => (
                    <option key={h.id} value={h.id}>
                      {h.name} · {h.provider} · {h.region} · {h.runtime}
                    </option>
                  ))}
                </select>
              </Field>
            </Card>

            <Card>
              <Field label="Model">
                <select className="input-dark" value={model} onChange={(e) => setModel(e.target.value)}>
                  {MODELS.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.label}
                    </option>
                  ))}
                </select>
              </Field>
              <div className="h-3" />
              <Field label={`maxTurns — ${maxTurns} tool round-trips`} hint="There is no top-level session timeout; this is the only turn bound.">
                <input type="range" min={1} max={30} value={maxTurns} onChange={(e) => setMaxTurns(Number(e.target.value))} className="w-full accent-[#d97757]" />
              </Field>
              <div className="h-3" />
              <Field label="SessionStore adapter">
                <select className="input-dark" value={storeBackend} disabled={storeRequired} onChange={(e) => setStoreBackend(e.target.value)}>
                  <option value="postgres">Postgres (this console)</option>
                  <option value="s3">S3</option>
                  <option value="redis">Redis</option>
                  <option value="none">No store (local disk only)</option>
                </select>
              </Field>
              <div className="h-3" />
              <Toggle checked={flaky} onChange={setFlaky} label="Simulate flaky store (mirror_error)" />
            </Card>
          </div>
        </div>

        <div className="col-span-12 lg:col-span-4">
          <Card className="sticky top-6">
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">What gets provisioned</div>
            <div className="space-y-2.5 text-[12.5px]">
              <div className="flex items-center gap-2">
                <PatternBadge pattern={pattern} />
                <span className="text-zinc-500">{chosenPattern.bestFor}</span>
              </div>
              <ul className="list-disc list-inside text-zinc-400 space-y-1.5 text-[12px] pl-1">
                {chosenPattern.points.map((pt, i) => (
                  <li key={i} className="leading-snug">{pt}</li>
                ))}
              </ul>
              <div className="border-t border-[#1e232c] pt-3 text-[12px] text-zinc-500 space-y-1">
                <div>Per-tenant <span className="mono text-zinc-400">cwd</span> + <span className="mono text-zinc-400">CLAUDE_CONFIG_DIR</span></div>
                <div>1 GiB RAM / 1 CPU / 5 GiB disk floor per subprocess</div>
                <div>Outbound HTTPS via the egress proxy only</div>
              </div>
            </div>
            <div className="mt-5">
              <Button variant="primary" className="w-full justify-center !py-2.5" onClick={launch} disabled={busy || !prompt.trim()}>
                {busy ? "Spawning…" : "❯ Spawn subprocess"}
              </Button>
            </div>
          </Card>
        </div>
      </div>

      <Toast message={toast} />
    </div>
  );
}
