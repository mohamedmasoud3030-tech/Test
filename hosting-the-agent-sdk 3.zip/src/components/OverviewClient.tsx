"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import type { FleetStats } from "@/lib/queries";
import { Card, SectionTitle, Stat, ProgressBar, Button, Badge, PatternBadge, StoreBadge, Toast } from "@/components/ui";
import { usd, compactNum, timeAgo } from "@/lib/util";
import { SUBPROCESS_FLOW } from "@/lib/content";

const POLL_MS = 2500;

export function OverviewClient({ initial }: { initial: FleetStats }) {
  const [stats, setStats] = useState<FleetStats>(initial);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    const t = setInterval(async () => {
      try {
        const r = await fetch("/api/stats", { cache: "no-store" });
        if (r.ok) setStats(await r.json());
      } catch {
        /* offline */
      }
    }, POLL_MS);
    return () => clearInterval(t);
  }, []);

  async function resetDemo() {
    await fetch("/api/seed", { method: "POST", body: JSON.stringify({ wipe: true }) });
    setToast("Demo fleet reseeded");
    setTimeout(() => location.reload(), 700);
  }

  const live = stats.byStatus.running ?? 0;
  const starting = stats.byStatus.starting ?? 0;

  return (
    <div className="p-8 max-w-[1280px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-7">
        <div className="min-w-0">
          <h1 className="text-xl font-semibold text-zinc-100">Fleet overview</h1>
          <p className="text-[13px] text-zinc-500 mt-1 max-w-2xl">
            Every running agent is a long-lived <span className="mono text-zinc-300">claude</span> CLI subprocess tied to a shell, a working directory and a JSONL
            transcript on local disk.
          </p>
        </div>
        <div className="flex gap-2">
          <Link href="/launch" className="btn btn-primary">
            ＋ Launch agent
          </Link>
          <Button variant="ghost" onClick={resetDemo}>
            ↻ Reseed demo
          </Button>
        </div>
      </header>

      <div className="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-7 gap-3 mb-6">
        <Stat label="Live subprocesses" value={stats.liveSubprocesses} accent sub={<span className="text-emerald-400">{live} running · {starting} starting</span>} />
        <Stat label="Sessions" value={stats.totalSessions} sub={`${stats.suspended} suspended · ${stats.failed} failed`} />
        <Stat label="Hosts" value={stats.hosts} sub={`${stats.tenants} tenants`} />
        <Stat label="Tokens (all time)" value={compactNum(stats.totalTokens)} sub="input + output" />
        <Stat label="Token spend" value={usd(stats.totalCostUsd)} accent sub="dominates infra ~10×" />
        <Stat label="Mirror errors" value={stats.storeErrors} sub={<span className={stats.storeErrors ? "text-rose-400" : undefined}>{stats.mirrorErrorSessions} sessions affected</span>} />
        <Stat label="Providers" value={stats.providerBreakdown.length} sub={stats.providerBreakdown.map((p) => p.provider).join(" · ")} />
      </div>

      <Card className="mb-6 grid-bg">
        <SectionTitle
          title="The subprocess model"
          subtitle="One agent session maps to one subprocess; N concurrent sessions means N process trees, each with its own transcript file."
        />
        <div className="flex flex-wrap items-stretch gap-2">
          {SUBPROCESS_FLOW.map((s, i) => (
            <div key={s.step} className="flex items-stretch gap-2">
              <div className="rounded-xl border border-[#232a35] bg-[#11151c] p-3 w-[158px]">
                <div className="flex items-center gap-2 mb-1">
                  <span className="w-5 h-5 rounded-full bg-[#d97757]/15 text-[#e8a089] text-[11px] grid place-items-center font-bold">{s.step}</span>
                  <span className="text-[12px] font-semibold text-zinc-200">{s.title}</span>
                </div>
                <p className="text-[11px] leading-snug text-zinc-500">{s.body}</p>
              </div>
              {i < SUBPROCESS_FLOW.length - 1 && <span className="self-center text-zinc-700 text-sm">→</span>}
            </div>
          ))}
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-6">
        <Card className="lg:col-span-2">
          <SectionTitle title="Host utilization" subtitle="Pinned sessions per host — long-running sessions are consistently hashed on sessionId so they keep hitting the same warm subprocess." right={<Link className="text-[12px] text-[#e8a089] hover:underline" href="/fleet">Capacity calculator →</Link>} />
          <div className="space-y-3.5">
            {stats.hostUtilization.map((h) => (
              <div key={h.id}>
                <div className="flex justify-between text-[12.5px] mb-1">
                  <Link href={`/fleet`} className="text-zinc-200 hover:text-white">
                    {h.name} <span className="text-zinc-600 mono">· {h.provider} · {h.region}</span>
                  </Link>
                  <span className="mono text-zinc-400">
                    {h.live}/{h.capacity} agents
                  </span>
                </div>
                <ProgressBar pct={h.pct} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <SectionTitle title="Session patterns" />
          <div className="space-y-2.5">
            {stats.patternBreakdown.map((p) => (
              <div key={p.pattern} className="flex items-center justify-between">
                <PatternBadge pattern={p.pattern} />
                <span className="mono text-zinc-300 text-[13px]">{p.count}</span>
              </div>
            ))}
          </div>
          <div className="border-t border-[#1e232c] mt-4 pt-4">
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-2.5">SessionStore backends</div>
            <div className="flex flex-wrap gap-2">
              {stats.storeBreakdown.map((s) => (
                <div key={s.backend} className="flex items-center gap-1.5">
                  <StoreBadge backend={s.backend} />
                  <span className="mono text-zinc-400 text-[12px]">×{s.count}</span>
                </div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <Card>
        <SectionTitle
          title="⚠ mirror_error stream"
          subtitle="Dropped SessionStore batches. The agent keeps running from its local transcript, but on a resumed run a dropped batch has no surviving copy after shutdown."
          right={<Link className="text-[12px] text-[#e8a089] hover:underline" href="/storage">Session storage runbook →</Link>}
        />
        {stats.recentErrors.length === 0 ? (
          <div className="text-[13px] text-zinc-600 py-3">No mirror errors — every transcript batch is mirrored durably. ✔</div>
        ) : (
          <div className="space-y-2">
            {stats.recentErrors.map((e) => (
              <Link
                key={e.id}
                href={`/sessions/${e.sessionId}`}
                className="flex items-start gap-3 rounded-lg border border-rose-900/40 bg-rose-950/20 px-3.5 py-2.5 hover:border-rose-700/60 transition-colors"
              >
                <Badge tone="red">mirror_error</Badge>
                <div className="min-w-0">
                  <div className="text-[12.5px] text-zinc-200 truncate">{e.title}</div>
                  <div className="text-[11.5px] text-zinc-500 truncate">{e.text}</div>
                </div>
                <span className="ml-auto text-[11px] text-zinc-600 shrink-0">{timeAgo(e.createdAt)}</span>
              </Link>
            ))}
          </div>
        )}
      </Card>

      <Toast message={toast} kind="ok" />
    </div>
  );
}
