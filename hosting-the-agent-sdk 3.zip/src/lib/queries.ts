import { db } from "@/db";
import { sessions, tenants, hosts, transcriptEntries, spanEvents } from "@/db/schema";
import { eq, sql, desc, asc } from "drizzle-orm";
import { capacity } from "./generators";

export const LIVE_STATES = ["starting", "running", "awaiting_input"];
export const ACTIVE_STATES = ["starting", "running"];

export async function listSessions() {
  return db
    .select({
      id: sessions.id,
      title: sessions.title,
      tenantId: sessions.tenantId,
      tenantName: tenants.name,
      hostName: hosts.name,
      provider: hosts.provider,
      region: hosts.region,
      sdk: sessions.sdk,
      pattern: sessions.pattern,
      model: sessions.model,
      status: sessions.status,
      resultSubtype: sessions.resultSubtype,
      pid: sessions.pid,
      turns: sessions.turns,
      maxTurns: sessions.maxTurns,
      totalCostUsd: sessions.totalCostUsd,
      inputTokens: sessions.inputTokens,
      outputTokens: sessions.outputTokens,
      storeBackend: sessions.storeBackend,
      storeErrors: sessions.storeErrors,
      storeResume: sessions.storeResume,
      resumedFrom: sessions.resumedFrom,
      forkDepth: sessions.forkDepth,
      cwd: sessions.cwd,
      endUserId: sessions.endUserId,
      startedAt: sessions.startedAt,
      lastActiveAt: sessions.lastActiveAt,
      endedAt: sessions.endedAt,
    })
    .from(sessions)
    .innerJoin(tenants, eq(sessions.tenantId, tenants.id))
    .leftJoin(hosts, eq(sessions.hostId, hosts.id))
    .orderBy(desc(sessions.lastActiveAt));
}

export async function listTenants() {
  const rows = await db
    .select({
      id: tenants.id,
      name: tenants.name,
      tier: tenants.tier,
      endUserLabel: tenants.endUserLabel,
      workdirRoot: tenants.workdirRoot,
      configRoot: tenants.configRoot,
      isolateSettings: tenants.isolateSettings,
      disableAutoMemory: tenants.disableAutoMemory,
      distinctEgress: tenants.distinctEgress,
      egressPolicy: tenants.egressPolicy,
      createdAt: tenants.createdAt,
      sessions: sql<number>`count(${sessions.id})`,
      live: sql<number>`sum(case when ${sessions.status} in ('starting','running','awaiting_input') then 1 else 0 end)`,
      cost: sql<number>`coalesce(sum(${sessions.totalCostUsd}),0)`,
    })
    .from(tenants)
    .leftJoin(sessions, eq(sessions.tenantId, tenants.id))
    .groupBy(tenants.id)
    .orderBy(asc(tenants.name));
  return rows;
}

export async function listHosts() {
  const rows = await db
    .select({
      id: hosts.id,
      name: hosts.name,
      provider: hosts.provider,
      region: hosts.region,
      runtime: hosts.runtime,
      ramMb: hosts.ramMb,
      cpus: hosts.cpus,
      overheadMb: hosts.overheadMb,
      perSessionRamMb: hosts.perSessionRamMb,
      status: hosts.status,
      note: hosts.note,
      startedAt: hosts.startedAt,
      pinned: sql<number>`sum(case when ${sessions.status} in ('starting','running','awaiting_input','suspended') then 1 else 0 end)`,
      live: sql<number>`sum(case when ${sessions.status} in ('starting','running','awaiting_input') then 1 else 0 end)`,
    })
    .from(hosts)
    .leftJoin(sessions, eq(sessions.hostId, hosts.id))
    .groupBy(hosts.id)
    .orderBy(asc(hosts.name));
  return rows.map((h) => ({
    ...h,
    capacity: capacity(h),
    pinned: Number(h.pinned ?? 0),
    live: Number(h.live ?? 0),
  }));
}

export type FleetStats = {
  totalSessions: number;
  byStatus: Record<string, number>;
  liveSubprocesses: number;
  suspended: number;
  tenants: number;
  hosts: number;
  totalCostUsd: number;
  totalTokens: number;
  storeErrors: number;
  mirrorErrorSessions: number;
  failed: number;
  providerBreakdown: Array<{ provider: string; count: number }>;
  hostUtilization: Array<{
    id: string;
    name: string;
    provider: string;
    region: string;
    live: number;
    capacity: number;
    pct: number;
  }>;
  patternBreakdown: Array<{ pattern: string; count: number }>;
  storeBreakdown: Array<{ backend: string; count: number }>;
  recentErrors: Array<{
    id: string;
    sessionId: string;
    title: string;
    tenantName: string;
    text: string | null;
    createdAt: Date;
  }>;
};

export async function getStats(): Promise<FleetStats> {
  const all = await listSessions();
  const hostsRows = await listHosts();
  const byStatus: Record<string, number> = {};
  const providerCount: Record<string, number> = {};
  const patternCount: Record<string, number> = {};
  const storeCount: Record<string, number> = {};
  let cost = 0;
  let tokens = 0;
  let storeErrors = 0;
  let mirrorErrorSessions = new Set<string>();

  for (const s of all) {
    byStatus[s.status] = (byStatus[s.status] ?? 0) + 1;
    if (s.provider) providerCount[s.provider] = (providerCount[s.provider] ?? 0) + 1;
    patternCount[s.pattern] = (patternCount[s.pattern] ?? 0) + 1;
    storeCount[s.storeBackend] = (storeCount[s.storeBackend] ?? 0) + 1;
    cost += Number(s.totalCostUsd);
    tokens += Number(s.inputTokens) + Number(s.outputTokens);
    storeErrors += s.storeErrors;
    if (s.storeErrors > 0) mirrorErrorSessions.add(s.id);
  }

  const errorEntries = await db
    .select({
      id: transcriptEntries.id,
      sessionId: transcriptEntries.sessionId,
      text: transcriptEntries.text,
      createdAt: transcriptEntries.createdAt,
      title: sessions.title,
      tenantName: tenants.name,
    })
    .from(transcriptEntries)
    .innerJoin(sessions, eq(transcriptEntries.sessionId, sessions.id))
    .innerJoin(tenants, eq(sessions.tenantId, tenants.id))
    .where(eq(transcriptEntries.subtype, "mirror_error"))
    .orderBy(desc(transcriptEntries.createdAt))
    .limit(8);

  return {
    totalSessions: all.length,
    byStatus,
    liveSubprocesses: all.filter((s) => LIVE_STATES.includes(s.status)).length,
    suspended: byStatus.suspended ?? 0,
    tenants: new Set(all.map((s) => s.tenantId)).size,
    hosts: hostsRows.length,
    totalCostUsd: Math.round(cost * 10000) / 10000,
    totalTokens: tokens,
    storeErrors,
    mirrorErrorSessions: mirrorErrorSessions.size,
    failed: byStatus.failed ?? 0,
    providerBreakdown: Object.entries(providerCount).map(([provider, count]) => ({ provider, count })),
    hostUtilization: hostsRows
      .filter((h) => h.status === "active")
      .map((h) => ({
        id: h.id,
        name: h.name,
        provider: h.provider,
        region: h.region,
        live: h.live,
        capacity: h.capacity,
        pct: h.capacity ? Math.round((h.live / h.capacity) * 100) : 0,
      })),
    patternBreakdown: Object.entries(patternCount).map(([pattern, count]) => ({ pattern, count })),
    storeBreakdown: Object.entries(storeCount).map(([backend, count]) => ({ backend, count })),
    recentErrors: errorEntries,
  };
}

export async function getTelemetry(limit = 60) {
  const spans = await db
    .select({
      id: spanEvents.id,
      spanId: spanEvents.spanId,
      sessionId: spanEvents.sessionId,
      tenantId: spanEvents.tenantId,
      parentSpanId: spanEvents.parentSpanId,
      kind: spanEvents.kind,
      name: spanEvents.name,
      status: spanEvents.status,
      durationMs: spanEvents.durationMs,
      attributes: spanEvents.attributes,
      startedAt: spanEvents.startedAt,
      title: sessions.title,
      sdk: sessions.sdk,
      pattern: sessions.pattern,
    })
    .from(spanEvents)
    .innerJoin(sessions, eq(spanEvents.sessionId, sessions.id))
    .orderBy(desc(spanEvents.startedAt))
    .limit(limit);

  const totals = await db
    .select({
      kind: spanEvents.kind,
      count: sql<string>`count(*)`,
      avgMs: sql<string>`avg(${spanEvents.durationMs})`,
      maxMs: sql<string>`max(${spanEvents.durationMs})`,
    })
    .from(spanEvents)
    .groupBy(spanEvents.kind);

  return {
    spans,
    totals: totals.map((t) => ({
      kind: t.kind,
      count: Number(t.count),
      avgMs: Math.round(Number(t.avgMs)),
      maxMs: Number(t.maxMs),
    })),
  };
}
