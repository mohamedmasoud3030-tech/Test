import type { PlannedEvent, SubagentEntry, TokenUsage } from "./engine-types";
import { hashSeed, rng } from "./util";

type Tool = {
  tool: string;
  input: Record<string, unknown>;
  output: string;
  durationMs?: number;
  isError?: boolean;
  subEntries?: SubagentEntry[];
};

type Step = { say: string; tools: Tool[]; then?: string };

function wordsToTokens(s: string): number {
  return Math.max(1, Math.round(s.split(/\s+/).length * 1.35));
}

function jsonTokens(v: unknown): number {
  return Math.max(1, Math.round(JSON.stringify(v).length / 4.2));
}

function dur(rnd: () => number, lo: number, hi: number): number {
  return Math.round(lo + rnd() * (hi - lo));
}

// ── Scripted scenarios, keyed to the example workloads in the hosting docs ──
function bugfixScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll reproduce the failure first, then trace the auth rate limiter the test exercises.",
      tools: [
        {
          tool: "Bash",
          input: { command: "npm test -- --grep 'auth rate limit'", description: "reproduce failing auth test" },
          output: "1) Auth › rejects the 6th login within 60s\n  expected 429, received 200\n11 passing, 1 failing (run took 4.2s)",
          durationMs: dur(r, 2800, 5200),
        },
        {
          tool: "Grep",
          input: { pattern: "rate.?limit|loginAttempts", path: "src/auth", output_mode: "files_with_matches" },
          output: "src/auth/rate-limit.ts\nsrc/auth/login.ts\nsrc/auth/rate-limit.test.ts",
        },
        {
          tool: "Read",
          input: { file_path: "src/auth/rate-limit.ts" },
          output:
            "export function checkRateLimit(key: string, now = Date.now()) {\n  const bucket = store.get(key) ?? { count: 0, resetAt: now };\n  // BUG: bucket.resetAt is overwritten on every call, so the window never closes\n  bucket.resetAt = now;\n  bucket.count += 1;\n  store.set(key, bucket);\n  return bucket.count <= 5;\n}",
        },
      ],
    },
    {
      say: "Found it: the window resets on every call. I'll key it to a fixed 60-second bucket and re-run the suite.",
      tools: [
        {
          tool: "Edit",
          input: {
            file_path: "src/auth/rate-limit.ts",
            old_string: "  bucket.resetAt = now;\n  bucket.count += 1;",
            new_string: "  if (bucket.resetAt <= now) { bucket.count = 0; bucket.resetAt = now + 60_000; }\n  bucket.count += 1;",
          },
          output: "The file src/auth/rate-limit.ts has been updated successfully.",
        },
        {
          tool: "Bash",
          input: { command: "npm test -- auth" },
          output: "42 passing, 0 failing (run took 9.8s)",
          durationMs: dur(r, 6000, 11000),
        },
      ],
      then: "Fixed. The limiter now uses a fixed 60s window instead of resetting on every attempt; all 42 auth tests pass.",
    },
  ];
}

function extractionScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll inventory the receipts folder, convert the PDFs to text, and extract structured line items to JSON.",
      tools: [
        { tool: "Glob", input: { pattern: "receipts/**/*.{pdf,jpg,png}" }, output: "receipts/acme-q2.pdf\nreceipts/cloudhost-apr.pdf\nreceipts/saas-tools.png\nreceipts/travel-lunch.jpg\n(14 files total)" },
        {
          tool: "Bash",
          input: { command: "for f in receipts/*.pdf; do pdftotext \"$f\" -; done | head -80" },
          output: "ACME CLOUD SERVICES\nInvoice A-2041  2026-03-04\nAmount due: $1,204.55\n...\nCLOUDHOST INC\nInvoice CH-88210\nTotal: $3,990.00",
          durationMs: dur(r, 1500, 3500),
        },
      ],
    },
    {
      say: "Extracting fields (vendor, invoice id, date, total) from each document and validating totals.",
      tools: [
        {
          tool: "Write",
          input: { file_path: "extracted/invoices.json" },
          output: '{"count":14,"invoices":[{"vendor":"ACME Cloud Services","id":"A-2041","date":"2026-03-04","total":1204.55}]}',
        },
        {
          tool: "Bash",
          input: { command: "node scripts/validate-invoices.js extracted/invoices.json" },
          output: "14 invoices OK · subtotal $48,205.12 · 2 missing PO numbers (flagged)",
          durationMs: dur(r, 800, 2000),
        },
      ],
      then: "Extracted 14 invoices totaling $48,205.12. Two entries (travel-lunch.jpg, saas-tools.png) are flagged for manual review because no PO number was found.",
    },
  ];
}

function translateScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll find the marketing docs that need Spanish and German versions, then translate while preserving Markdown structure.",
      tools: [
        { tool: "Glob", input: { pattern: "docs/marketing/*.md" }, output: "docs/marketing/overview.en.md\ndocs/marketing/pricing.en.md\ndocs/marketing/changelog.en.md" },
        { tool: "Read", input: { file_path: "docs/marketing/overview.en.md" }, output: "# Agent Ops\n\nRun thousands of secure Claude Code agents in production..." },
      ],
    },
    {
      say: "Translating now — keeping code fences, links, and frontmatter untouched.",
      tools: [
        { tool: "Write", input: { file_path: "docs/marketing/overview.es.md" }, output: "# Agent Ops\n\nEjecuta miles de agentes de Claude Code seguros en producción..." },
        { tool: "Write", input: { file_path: "docs/marketing/overview.de.md" }, output: "# Agent Ops\n\nBetreiben Sie Tausende sicherer Claude Code-Agenten in der Produktion..." },
        {
          tool: "Bash",
          input: { command: "scripts/check-placeholders.sh docs/marketing/*.{es,de}.md" },
          output: "All 31 placeholders, links and code fences match the English source.",
          durationMs: dur(r, 600, 1400),
        },
      ],
      then: "Translated the three marketing pages to Spanish and German with all placeholders and Markdown structure verified.",
    },
  ];
}

function mediaScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll inspect the source media, then batch-transcode to H.264 at 1080p and generate thumbnails.",
      tools: [
        { tool: "Bash", input: { command: "ffprobe -v error -show_format -show_streams source/keynote.mov" }, output: "duration=3842.1s video=hvc1 3840x2160 59.9Mbps audio=aac" },
        {
          tool: "Bash",
          input: { command: "ls -lh source/" },
          output: "keynote.mov  41G\nb-roll-a.mov 9.8G\nb-roll-b.mov 7.1G",
        },
      ],
    },
    {
      say: "Running the transcode pipeline with a 6-frame ladder and sprites.",
      tools: [
        {
          tool: "Bash",
          input: { command: "scripts/transcode.sh --src source --out dist --ladders 1080p,720p --thumbnails" },
          output: "keynote 1080p 4.2G · 720p 1.7G · 96 thumbnails · elapsed 11m04s",
          durationMs: dur(r, 8000, 16000),
        },
      ],
      then: "Transcoded 3 sources across two bitrate ladders with thumbnail sprites; output is in dist/ and totals 18.4 GiB.",
    },
  ];
}

function triageScenario(r: () => number): Step[] {
  return [
    {
      say: "Pulling the unread inbox and classifying each thread before drafting replies.",
      tools: [
        {
          tool: "Bash",
          input: { command: "imapctl ls --inbox --unread --json" },
          output: "22 unread · 8 urgent · 4 billing · 6 newsletters · 4 threads already answered by a colleague",
          durationMs: dur(r, 1200, 2600),
        },
        {
          tool: "Bash",
          input: { command: "imapctl show --thread 8821 --thread 8824" },
          output: "[8821] customer: webhook retries failing with 401 since 14:02 UTC\n[8824] procurement: request to renew annual seat contract",
        },
      ],
    },
    {
      say: "Drafting replies for the threads that need a human-style answer and queuing archive/label actions for the rest.",
      tools: [
        { tool: "Write", input: { file_path: "drafts/8821-webhook-401.md" }, output: "It looks like the signing key rotated at 14:00 UTC. I've attached the new key and a rollback procedure..." },
        { tool: "Write", input: { file_path: "drafts/8824-renewal.md" }, output: "Attached is the renewal order form with the 12% annual discount applied..." },
        {
          tool: "Bash",
          input: { command: "imapctl apply --plan triage-plan.json" },
          output: "2 drafts queued for review · 6 labeled billing · 6 archived · 4 skipped",
          durationMs: dur(r, 900, 2200),
        },
      ],
      then: "Triaged 22 messages: 2 replies drafted for your review, 6 billing threads labeled, 6 newsletters archived. Nothing was sent without approval.",
    },
  ];
}

function siteScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll scaffold the per-user site from the hosted template, wire their content, and publish through the deploy endpoint.",
      tools: [
        { tool: "Read", input: { file_path: "templates/site/index.html" }, output: "<!doctype html><html><head>…hosted site template…</head></html>" },
        { tool: "Write", input: { file_path: "sites/vera/index.html" }, output: "<!doctype html><html>… Vera's Bakery — hours, menu, order form …</html>" },
        { tool: "Write", input: { file_path: "sites/vera/styles.css" }, output: ":root{--brand:#c05621} …" },
      ],
    },
    {
      say: "Publishing to the container's port-bound site host and smoke-testing it.",
      tools: [
        {
          tool: "Bash",
          input: { command: "deployctl publish --site vera --port 8080" },
          output: "published → https://vera.sites.example.dev (200 OK, 412ms TTFB)",
          durationMs: dur(r, 2500, 5000),
        },
      ],
      then: "The site is live at https://vera.sites.example.dev with the menu, hours, and order form wired up.",
    },
  ];
}

function researchSubEntries(r: () => number): SubagentEntry[] {
  return [
    { role: "assistant", kind: "text", text: "Surveying competitor pricing pages and plan matrices..." },
    { role: "assistant", kind: "tool_use", toolName: "WebFetch", input: { url: "https://competitor-a.example/pricing" } },
    { role: "user", kind: "tool_result", toolName: "WebFetch", output: "Starter $19/seat · Pro $49/seat · Enterprise custom · SOC 2, SSO on Pro+", durationMs: dur(r, 1200, 3000) },
    { role: "assistant", kind: "tool_use", toolName: "WebFetch", input: { url: "https://competitor-b.example/plans" } },
    { role: "user", kind: "tool_result", toolName: "WebFetch", output: "Free tier 3 projects · Team $29/seat · annual billing only", durationMs: dur(r, 1200, 3000) },
    { role: "assistant", kind: "text", text: "Summary: five competitors cluster at $29-$49/seat for team plans; SSO and SOC 2 are the standard enterprise gate." },
  ];
}

function researchScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll pull the current pricing pages myself and dispatch a subagent to survey competitors in parallel.",
      tools: [
        {
          tool: "WebFetch",
          input: { url: "https://internal.example/wiki/positioning" },
          output: "# Positioning notes\nWe lead on security posture and per-tenant isolation...",
          durationMs: dur(r, 900, 2500),
        },
        {
          tool: "Task",
          input: { description: "Survey competitor pricing pages", prompt: "Compile competitor pricing tiers, per-seat cost, and enterprise gates (SSO, SOC2)." },
          output: "Subagent summary: five competitors cluster team plans at $29-$49/seat; SSO/SOC 2 are the standard enterprise gate.",
          durationMs: dur(r, 7000, 14000),
          subEntries: researchSubEntries(r),
        },
      ],
    },
    {
      say: "Compiling findings into the Q4 market scan report.",
      tools: [
        { tool: "Write", input: { file_path: "reports/q4-market-scan.md" }, output: "# Q4 Market Scan\n## Pricing benchmarks\n- Team plans: $29-$49/seat...\n## Recommendation..." },
        { tool: "Bash", input: { command: "git add reports && git commit -m 'Add Q4 market scan'" }, output: "[main 4f91a2c] Add Q4 market scan\n 1 file changed, 48 insertions(+)" },
      ],
      then: "Report saved to reports/q4-market-scan.md and committed. Headline: team plans cluster at $29-$49/seat; our isolation story supports a premium tier.",
    },
  ];
}

function genericScenario(r: () => number): Step[] {
  return [
    {
      say: "I'll map the repository structure and locate the code paths related to your request.",
      tools: [
        { tool: "Glob", input: { pattern: "src/**/*.{ts,tsx}" }, output: "src/app/page.tsx\nsrc/lib/config.ts\nsrc/lib/queue.ts\n(63 files)" },
        { tool: "Grep", input: { pattern: "TODO|FIXME|HACK", path: "src", output_mode: "count" }, output: "src/lib/queue.ts:3\nsrc/app/page.tsx:1\nsrc/lib/config.ts:2" },
        { tool: "Read", input: { file_path: "src/lib/queue.ts" }, output: "// Background job queue\nexport async function enqueue(job) { ... }\n// FIXME: no dead-letter handling after max retries" },
      ],
    },
    {
      say: "I found a retry loop with no dead-letter handling. Adding a DLQ and a regression test.",
      tools: [
        { tool: "Edit", input: { file_path: "src/lib/queue.ts", old_string: "// FIXME: no dead-letter handling after max retries", new_string: "if (attempts > MAX_RETRIES) { await dlq.put(job); return; }" }, output: "The file src/lib/queue.ts has been updated successfully." },
        {
          tool: "Bash",
          input: { command: "npm test -- queue" },
          output: "18 passing, 0 failing",
          durationMs: dur(r, 3000, 7000),
        },
      ],
      then: "Added dead-letter handling after MAX_RETRIES with tests covering the new path.",
    },
  ];
}

function followupScenario(prompt: string, r: () => number): Step[] {
  const p = prompt.toLowerCase();
  if (p.includes("test")) {
    return [
      {
        say: "Adding the extra test coverage you asked for.",
        tools: [
          { tool: "Write", input: { file_path: "test/edge-cases.test.ts" }, output: "describe('edge cases', () => { /* window rollover, clock skew, burst */ })" },
          { tool: "Bash", input: { command: "npm test" }, output: "57 passing, 0 failing", durationMs: dur(r, 4000, 9000) },
        ],
        then: "Added 8 edge-case tests around window rollover and burst behavior; full suite is green.",
      },
    ];
  }
  if (p.includes("deploy") || p.includes("ship") || p.includes("push")) {
    return [
      {
        say: "Preparing the release: changelog, tag, and deploy.",
        tools: [
          { tool: "Edit", input: { file_path: "CHANGELOG.md" }, output: "Updated CHANGELOG.md with the 1.4.2 notes." },
          { tool: "Bash", input: { command: "./scripts/release.sh 1.4.2" }, output: "tagged v1.4.2 · image pushed · canary healthy (3/3)", durationMs: dur(r, 5000, 10000) },
        ],
        then: "Released 1.4.2 to canary; all replicas healthy.",
      },
    ];
  }
  return [
    {
      say: "Continuing from the previous run — I'll verify the current state first.",
      tools: [
        { tool: "Bash", input: { command: "git status --short" }, output: "M src/lib/queue.ts\n?? test/edge-cases.test.ts" },
        { tool: "Read", input: { file_path: "src/lib/queue.ts" }, output: "const MAX_RETRIES = 5;\nexport async function enqueue(job) { ... }" },
      ],
    },
    {
      say: "Applying the next round of changes and verifying.",
      tools: [
        { tool: "Edit", input: { file_path: "src/lib/queue.ts" }, output: "The file src/lib/queue.ts has been updated." },
        { tool: "Bash", input: { command: "npm run check" }, output: "typecheck ✓  lint ✓  tests ✓", durationMs: dur(r, 3000, 8000) },
      ],
      then: "Continued the work and verified everything: typecheck, lint, and tests all pass.",
    },
  ];
}

function scoreScenario(prompt: string): { steps: (r: () => number) => Step[]; title: string; score: number }[] {
  const p = prompt.toLowerCase();
  const has = (...ks: string[]) => ks.some((k) => p.includes(k));
  return [
    { score: has("fix", "bug", "test fail", "regression", "broken") ? 4 : 0, steps: bugfixScenario, title: "Bug investigation & fix" },
    { score: has("invoice", "receipt", "extract", "ocr") ? 4 : 0, steps: extractionScenario, title: "Invoice & receipt extraction" },
    { score: has("translat", "localiz", "spanish", "german") ? 4 : 0, steps: translateScenario, title: "Document translation" },
    { score: has("video", "transcode", "ffmpeg", "media", "keynote") ? 4 : 0, steps: mediaScenario, title: "Media transformation" },
    { score: has("email", "inbox", "triage", "slack", "mail") ? 4 : 0, steps: triageScenario, title: "Inbox triage agent" },
    { score: has("site", "website", "landing", "homepage", "publish") ? 4 : 0, steps: siteScenario, title: "Per-user site builder" },
    { score: has("research", "report", "competitor", "scan", "market") ? 4 : 0, steps: researchScenario, title: "Deep research run" },
  ];
}

export type PlanInput = {
  prompt: string;
  pattern: string;
  model: string;
  maxTurns: number;
  continuation?: boolean;
};

export function planTitle(prompt: string): string {
  const scored = scoreScenario(prompt).filter((s) => s.score > 0).sort((a, b) => b.score - a.score);
  if (scored.length) return scored[0].title;
  return "Repository task";
}

export function buildPlan(input: PlanInput): { events: PlannedEvent[]; title: string } {
  const r = rng(hashSeed(input.prompt + input.pattern + (input.continuation ? ":c" : "")));
  const scored = scoreScenario(input.prompt).filter((s) => s.score > 0).sort((a, b) => b.score - a.score);
  const chosen = scored[0];
  let steps: Step[];
  let title: string;
  if (input.continuation) {
    steps = followupScenario(input.prompt, r);
    title = "Continued turn";
  } else if (chosen) {
    steps = chosen.steps(r);
    title = chosen.title;
  } else {
    steps = genericScenario(r);
    title = "Repository task";
  }

  // Long-running first query serves an initial chunk, then parks awaiting input.
  if (input.pattern === "long-running" && !input.continuation) {
    steps = steps.slice(0, Math.max(1, steps.length - 1));
  }
  // Multi-agent containers get an explicit parallel subagent dispatch.
  if (input.pattern === "multi-agent" && !steps.some((s) => s.tools.some((t) => t.tool === "Task"))) {
    steps.push({
      say: "Dispatching a second agent in its own working directory to audit the same change independently.",
      tools: [
        {
          tool: "Task",
          input: { description: "Independent change audit", prompt: "Review the working directory diff and report any regression risks.", cwd: "/srv/work/agent-b" },
          output: "Audit complete: no regressions; two non-blocking suggestions about retry backoff jitter.",
          durationMs: dur(r, 6000, 12000),
          subEntries: [
            { role: "assistant", kind: "text", text: "Auditing the diff from an isolated working directory..." },
            { role: "assistant", kind: "tool_use", toolName: "Bash", input: { command: "git diff --stat" } },
            { role: "user", kind: "tool_result", toolName: "Bash", output: "2 files changed, +38 -12", durationMs: dur(r, 400, 1200) },
            { role: "assistant", kind: "text", text: "No regressions found; two non-blocking suggestions on backoff jitter." },
          ],
        },
      ],
    });
  }

  // ── Walk steps into events while simulating context/token growth ──
  const events: PlannedEvent[] = [];
  let context = 5200; // system prompt + tool defs baseline
  let turn = 0;

  const usageFor = (text: string, toolInputs: unknown[], isNewTurn: boolean): TokenUsage => {
    const inputTokens = Math.round(context + toolInputs.reduce<number>((a, v) => a + jsonTokens(v), 0));
    const outputTokens = wordsToTokens(text) + toolInputs.reduce<number>((a, v) => a + Math.round(jsonTokens(v) * 0.4), 0);
    const usage: TokenUsage = isNewTurn
      ? { inputTokens, outputTokens, cacheReadTokens: 0, cacheCreationTokens: Math.round(inputTokens * 0.9) }
      : {
          inputTokens,
          outputTokens,
          cacheReadTokens: Math.round(inputTokens * 0.82),
          cacheCreationTokens: Math.round(inputTokens * 0.06),
        };
    return usage;
  };

  const compactBefore = steps.length >= 6 ? 4 : -1;

  for (let i = 0; i < steps.length; i++) {
    if (i === compactBefore) events.push({ kind: "compact" });
    const step = steps[i];
    events.push({ kind: "assistant", phase: "open", text: step.say, usage: usageFor(step.say, [], i === 0), turn });
    context += wordsToTokens(step.say);
    for (const t of step.tools) {
      events.push({ kind: "tool_use", tool: t.tool, input: t.input, ...(t.subEntries ? { subagentId: "pending" } : {}) });
      events.push({
        kind: "tool_result",
        tool: t.tool,
        output: t.output,
        isError: t.isError,
        durationMs: t.durationMs ?? dur(r, 200, 2000),
        ...(t.subEntries
          ? { subagentId: "pending", subEntries: t.subEntries }
          : {}),
      });
      context += Math.min(1400, Math.round(t.output.length / 4));
    }
    if (step.then) {
      events.push({ kind: "assistant", phase: "close", text: step.then, usage: usageFor(step.then, [], false), turn });
      context += wordsToTokens(step.then);
    }
    turn++;
  }

  // ── Enforce maxTurns (a turn = one agent round-trip, opened per step) ──
  let openCount = 0;
  let cutAt = -1;
  for (let i = 0; i < events.length; i++) {
    const e = events[i];
    if (e.kind === "assistant" && e.phase === "open") {
      openCount++;
      if (openCount > input.maxTurns) {
        cutAt = i;
        break;
      }
    }
  }
  if (cutAt >= 0) {
    events.splice(cutAt);
    events.push({
      kind: "result",
      subtype: "error_max_turns",
    });
  } else {
    const lastClose = [...events].reverse().find((e) => e.kind === "assistant" && e.phase === "close");
    events.push({
      kind: "result",
      subtype: "success",
      text: lastClose && lastClose.kind === "assistant" ? lastClose.text : "Task completed successfully.",
    });
  }

  return { events, title };
}
