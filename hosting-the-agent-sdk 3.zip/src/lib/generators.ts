// Snippet generators — every template is grounded in the Agent SDK hosting docs.

export type TenantLike = {
  id: string;
  workdirRoot: string;
  configRoot: string;
  isolateSettings: boolean;
  disableAutoMemory: boolean;
};

export function isolationSnippet(t: TenantLike, sdk: "typescript" | "python"): string {
  if (sdk === "typescript") {
    return `import { query } from "@anthropic-ai/claude-agent-sdk";

// Per-tenant paths: no other tenant can read them (mode 0700).
const tenantDir = "${t.workdirRoot}/${t.id}/\${sessionId}";
const configDir = "${t.configRoot}/${t.id}-\${sessionId}";

for await (const message of query({
  prompt,
  options: {
    cwd: tenantDir, // explicit per-tenant working directory${t.isolateSettings ? "\n    settingSources: [], // skip user/project/local settings" : ""}${
      t.disableAutoMemory
        ? `
    env: {
      ...process.env, // env REPLACES the subprocess environment in TS
      CLAUDE_CONFIG_DIR: configDir, // per-tenant ~/.claude.json
      CLAUDE_CODE_DISABLE_AUTO_MEMORY: "1", // memory/ otherwise loads unconditionally
    },`
        : `
    env: {
      ...process.env,
      CLAUDE_CONFIG_DIR: configDir,
    },`
    }
  },
})) {
  // Apply per-tenant egress rules at your proxy as well: distinct outbound
  // IPs, credentials, and domain allowlists per tenant.
  console.log(message);
}`;
  }
  return `import asyncio
from claude_agent_sdk import query, ClaudeAgentOptions

# Per-tenant paths: no other tenant can read them (mode 0700).
tenant_dir = "${t.workdirRoot}/${t.id}/{session_id}"
config_dir = "${t.configRoot}/${t.id}-{session_id}"


async def main():
    async for message in query(
        prompt=prompt,
        options=ClaudeAgentOptions(
            cwd=tenant_dir,${t.isolateSettings ? "\n            setting_sources=[],  # skip user/project/local settings" : ""}
            env={
                # Python merges env ON TOP of the inherited environment.
                "CLAUDE_CONFIG_DIR": config_dir,${t.disableAutoMemory ? '\n                "CLAUDE_CODE_DISABLE_AUTO_MEMORY": "1",' : ""}
            },
        ),
    ):
        # Distinct outbound IPs / credentials / domain allowlists per tenant
        # are enforced at the egress proxy.
        print(message)


asyncio.run(main)`;
}

export function ephemeralEntrypoint(sdk: "typescript" | "python"): string {
  if (sdk === "typescript")
    return `import { query } from "@anthropic-ai/claude-agent-sdk";

const prompt = process.env.TASK_PROMPT!;
try {
  for await (const message of query({
    prompt,
    options: { maxTurns: 20 },
  })) {
    console.log(message);
  }
} catch (err) {
  // error_max_turns is yielded, then thrown — exit cleanly either way.
  console.error("Agent run failed:", err);
  process.exit(0);
}`;
  return `import asyncio, os
from claude_agent_sdk import ClaudeAgentOptions, query


async def main():
    prompt = os.environ["TASK_PROMPT"]
    try:
        async for message in query(
            prompt=prompt,
            options=ClaudeAgentOptions(max_turns=20),
        ):
            print(message)
    except Exception as err:
        print(f"Agent run failed: {err}")


asyncio.run(main)`;
}

export function longRunningSnippet(sdk: "typescript" | "python"): string {
  if (sdk === "typescript")
    return `import { query, streamInput, startup } from "@anthropic-ai/claude-agent-sdk";

// Pre-warm subprocesses ahead of incoming traffic.
await startup({ count: 4 });

// One stream per active session; sessionId is used for consistent-hash pinning.
const stream = streamInput({
  options: { cwd: "/srv/work/acme/session-a", maxTurns: 50 },
});
(async () => {
  for await (const message of stream) {
    ws.send(JSON.stringify(message)); // forward over WebSocket
  }
})();

ws.on("message", (text) => stream.sendMessage(text.toString()));`;
  return `from claude_agent_sdk import ClaudeSDKClient

# ClaudeSDKClient keeps one subprocess open across many turns.
async with ClaudeSDKClient(
    cwd="/srv/work/acme/session-a",
    max_turns=50,
) as client:
    await client.connect()
    await client.query("Triage the inbox and draft replies")
    async for message in client.receive_response():
        await ws.send_json(message)
    # later, same subprocess:
    await client.query("Send the approved draft to thread 8821")`;
}

export function hybridSnippet(sdk: "typescript" | "python", store: string): string {
  if (sdk === "typescript")
    return `import { query, ${store === "redis" ? "RedisSessionStore" : store === "s3" ? "S3SessionStore" : "PostgresSessionStore"} } from "@anthropic-ai/claude-agent-sdk";

const sessionStore = new ${store === "redis" ? "RedisSessionStore" : store === "s3" ? "S3SessionStore" : "PostgresSessionStore"}(/* client config */);

// On container start: hydrate; during the run: mirror; on idle: spin down.
for await (const message of query({
  prompt: userInput,
  options: { resume: sessionId, sessionStore }, // sessionId from your DB
})) {
  if (message.type === "system" && message.subtype === "mirror_error") {
    await alertOncall("session store batch dropped");
  }
}`;
  return `from claude_agent_sdk import query, ClaudeAgentOptions, SessionStore

session_store: SessionStore = build_store("${store}")  # shared adapter

async def main():
    async for message in query(
        prompt=user_input,
        options=ClaudeAgentOptions(
            resume=session_id,  # looked up in your database by user
            session_store=session_store,
        ),
    ):
        if message.type == "system" and message.subtype == "mirror_error":
            await alert_oncall("session store batch dropped")`;
}

export function otelEnv(opts: {
  endpoint: string;
  traces: boolean;
  metrics: boolean;
  logs: boolean;
  shortIntervals: boolean;
  prompts: boolean;
  toolDetails: boolean;
  toolContent: boolean;
  rawBodies: boolean;
  serviceName: string;
  tenantId?: string;
  endUserId?: string;
  headers?: string;
}): string {
  const lines = [
    "# Generated for a container / orchestrator env block",
    "CLAUDE_CODE_ENABLE_TELEMETRY=1",
    ...(opts.traces ? ["# Traces are beta: this flag is required only for spans", "CLAUDE_CODE_ENHANCED_TELEMETRY_BETA=1"] : []),
    opts.traces ? "OTEL_TRACES_EXPORTER=otlp" : "# OTEL_TRACES_EXPORTER=otlp",
    opts.metrics ? "OTEL_METRICS_EXPORTER=otlp" : "# OTEL_METRICS_EXPORTER=otlp",
    opts.logs ? "OTEL_LOGS_EXPORTER=otlp" : "# OTEL_LOGS_EXPORTER=otlp",
    "OTEL_EXPORTER_OTLP_PROTOCOL=http/protobuf",
    `OTEL_EXPORTER_OTLP_ENDPOINT=${opts.endpoint}`,
    ...(opts.headers ? [`OTEL_EXPORTER_OTLP_HEADERS=${opts.headers}`] : []),
    `OTEL_SERVICE_NAME=${opts.serviceName}`,
  ];
  if (opts.tenantId || opts.endUserId) {
    const attrs: string[] = [];
    if (opts.tenantId) attrs.push(`tenant.id=${encodeURIComponent(opts.tenantId)}`);
    if (opts.endUserId) attrs.push(`enduser.id=${encodeURIComponent(opts.endUserId)}`);
    lines.push(`# percent-encode values (commas, spaces, = are reserved)`);
    lines.push(`OTEL_RESOURCE_ATTRIBUTES=${attrs.join(",")}`);
  }
  if (opts.shortIntervals) {
    lines.push("# Flush fast so short-lived ephemeral tasks don't drop buffered telemetry");
    lines.push("OTEL_METRIC_EXPORT_INTERVAL=1000", "OTEL_LOGS_EXPORT_INTERVAL=1000", "OTEL_TRACES_EXPORT_INTERVAL=1000");
  }
  const optins = [
    opts.prompts && "OTEL_LOG_USER_PROMPTS=1",
    opts.toolDetails && "OTEL_LOG_TOOL_DETAILS=1",
    opts.toolContent && "OTEL_LOG_TOOL_CONTENT=1",
    opts.rawBodies && "OTEL_LOG_RAW_API_BODIES=1",
  ].filter(Boolean) as string[];
  if (optins.length) {
    lines.push("# Sensitive-data opt-ins — leave unset unless your pipeline is approved");
    lines.push(...optins);
  }
  lines.push("# Surface exporter failures instead of failing silently:", "# CLAUDE_CODE_OTEL_DIAG_STDERR=1");
  lines.push("# Never use the 'console' exporter through the SDK — stdout is the message channel.");
  return lines.join("\n");
}

export type DockerOpts = {
  memoryGb: number;
  cpus: number;
  pids: number;
  readOnly: boolean;
  networkNone: boolean;
  capDrop: boolean;
  noNewPrivs: boolean;
  seccomp: boolean;
  nonRoot: boolean;
  tmpfs: boolean;
  sockProxy: boolean;
  readOnlyCode: boolean;
  image: string;
};

export const DEFAULT_DOCKER: DockerOpts = {
  memoryGb: 2,
  cpus: 2,
  pids: 100,
  readOnly: true,
  networkNone: true,
  capDrop: true,
  noNewPrivs: true,
  seccomp: true,
  nonRoot: true,
  tmpfs: true,
  sockProxy: true,
  readOnlyCode: true,
  image: "agent-image:latest",
};

export function dockerRun(o: DockerOpts): string {
  const parts = ["docker run"];
  if (o.capDrop) parts.push("  --cap-drop ALL");
  if (o.noNewPrivs) parts.push("  --security-opt no-new-privileges");
  if (o.seccomp) parts.push("  --security-opt seccomp=/etc/claude/seccomp-profile.json");
  if (o.readOnly) parts.push("  --read-only");
  if (o.tmpfs) parts.push("  --tmpfs /tmp:rw,noexec,nosuid,size=100m", "  --tmpfs /home/agent:rw,noexec,nosuid,size=500m");
  if (o.networkNone) parts.push("  --network none");
  parts.push(`  --memory ${o.memoryGb}g`);
  parts.push(`  --cpus ${o.cpus}`);
  parts.push(`  --pids-limit ${o.pids}`);
  if (o.nonRoot) parts.push("  --user 1000:1000");
  if (o.readOnlyCode) parts.push("  -v /srv/code/task-123:/workspace:ro");
  if (o.sockProxy) parts.push("  -v /var/run/egress-proxy.sock:/var/run/proxy.sock:ro");
  parts.push("  " + o.image);
  if (o.networkNone) {
    parts.push(
      "",
      "# With --network none the ONLY egress is the proxy Unix socket:",
      "# domain allowlist + credential injection + full request logging live on the host side."
    );
  }
  if (!o.readOnlyCode) {
    parts.push("", "# WARNING: never mount ~/.ssh, ~/.aws, ~/.config or .env files into the container.");
  }
  return parts.join(" \\\n");
}

export function capacity(host: { ramMb: number; overheadMb: number; perSessionRamMb: number }): number {
  return Math.max(0, Math.floor((host.ramMb - host.overheadMb) / host.perSessionRamMb));
}
