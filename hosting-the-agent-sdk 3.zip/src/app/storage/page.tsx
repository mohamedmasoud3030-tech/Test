"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, SectionTitle, Badge, CodeBlock, Tabs } from "@/components/ui";
import { STORE_METHODS, ADAPTERS, STORE_BEHAVIORS } from "@/lib/content";
import { timeAgo } from "@/lib/util";

type Err = { id: string; sessionId: string; title: string; tenantName: string; text: string | null; createdAt: string };
type Stats = { storeErrors: number; mirrorErrorSessions: number; recentErrors: Err[] };

const INTERFACE_TS = `type SessionKey = {
  projectKey: string;   // stable encoding of cwd
  sessionId: string;   // session UUID
  subpath?: string;    // e.g. "subagents/agent-<id>"
};

type SessionStore = {
  append(key, entries: SessionStoreEntry[]): Promise<void>;  // required
  load(key): Promise<SessionStoreEntry[] | null>;            // required
  listSessions?(projectKey): Promise<{ sessionId; mtime }[]>;
  listSessionSummaries?(projectKey): Promise<SessionSummaryEntry[]>;
  delete?(key): Promise<void>;        // must cascade to subkeys + summary
  listSubkeys?(key): Promise<string[]>;
};`;

const INTERFACE_PY = `class SessionKey(TypedDict):
    project_key: str
    session_id: str
    subpath: NotRequired[str]

class SessionStore(Protocol):
    async def append(self, key: SessionKey,
                     entries: list[SessionStoreEntry]) -> None: ...
    async def load(self, key: SessionKey
    ) -> list[SessionStoreEntry] | None: ...
    # optional: list_sessions, list_session_summaries,
    # delete, list_subkeys`;

export default function StoragePage() {
  const [stats, setStats] = useState<Stats | null>(null);
  useEffect(() => {
    const load = async () => setStats(await (await fetch("/api/stats", { cache: "no-store" })).json());
    load();
    const t = setInterval(load, 5000);
    return () => clearInterval(t);
  }, []);

  return (
    <div className="p-8 max-w-[1200px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-7">
        <div className="min-w-0">
        <h1 className="text-xl font-semibold text-zinc-100">Session storage</h1>
        <p className="text-[13px] text-zinc-500 mt-1 max-w-3xl">
          A <span className="mono text-zinc-300">SessionStore</span> mirrors the subprocess&apos;s JSONL transcripts to your backend, so a session created on one host can
          resume on another — as long as it runs from a matching working directory.
        </p>
        </div>
      </header>

      <div className="grid grid-cols-3 gap-3 mb-6">
        <Card className="text-center">
          <div className="text-2xl font-semibold text-[#e8a089] mono">{stats?.storeErrors ?? "—"}</div>
          <div className="text-[12px] text-zinc-500 mt-1">dropped batches (mirror_error)</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-semibold text-rose-300 mono">{stats?.mirrorErrorSessions ?? "—"}</div>
          <div className="text-[12px] text-zinc-500 mt-1">sessions affected</div>
        </Card>
        <Card className="text-center">
          <div className="text-2xl font-semibold text-emerald-300 mono">Postgres</div>
          <div className="text-[12px] text-zinc-500 mt-1">this console&apos;s live adapter</div>
        </Card>
      </div>

      <Card className="mb-6 grid-bg">
        <SectionTitle title="Dual-write architecture" subtitle="The store is a mirror of the local transcript — never a replacement. This console implements the same pattern against Postgres: every transcript entry carries on-disk / in-store flags you can inspect on any session." />
        <div className="flex flex-wrap items-stretch gap-3">
          <FlowBox title="claude CLI subprocess" tone="amber" lines={["writes every batch", "to local JSONL FIRST"]} />
          <Arrow label="① local write" />
          <FlowBox title="~/.claude/projects" subtitle="(or CLAUDE_CONFIG_DIR/projects)" tone="zinc" lines={["shell + cwd live here", "lost with the container"]} />
          <Arrow label="② SDK forwards batch" />
          <FlowBox title="SessionStore.append()" tone="blue" lines={["Postgres / S3 / Redis", "retries ×2 on failure"]} />
        </div>
        <div className="flex flex-wrap items-stretch gap-3 mt-3 justify-end">
          <FlowBox title="append() fails 3×" tone="red" lines={["emit system/mirror_error", "drop batch, keep running"]} small />
          <Arrow label="best-effort" />
          <FlowBox title="resume / continue" tone="teal" lines={["load() → temp config dir", "local copy deleted at run end"]} small />
        </div>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 mb-6">
        <Card>
          <SectionTitle title="The interface" subtitle="Two required methods, four optional." />
          <Tabs
            tabs={[
              { key: "ts", label: "TypeScript", content: <CodeBlock lang="typescript" compact code={INTERFACE_TS} /> },
              { key: "py", label: "Python", content: <CodeBlock lang="python" compact code={INTERFACE_PY} /> },
            ]}
          />
        </Card>
        <Card>
          <SectionTitle title="When each method fires" />
          <div className="space-y-1.5">
            {STORE_METHODS.map((m) => (
              <div key={m.method} className="flex items-start gap-2.5 rounded-lg border border-[#232a35] bg-[#11151c] px-3 py-2.5 min-w-0">
                <span className="mono text-[11px] mt-0.5 shrink-0">{m.required ? <Badge tone="green">required</Badge> : <Badge tone="zinc">optional</Badge>}</span>
                <div className="min-w-0">
                  <div className="mono text-[11.5px] text-sky-300 break-all">{m.method}</div>
                  <div className="text-[11.5px] text-zinc-500 mt-0.5 break-words">{m.when}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12 lg:col-span-5">
          <SectionTitle title="Reference adapters" />
          <div className="space-y-2">
            {ADAPTERS.map((a) => (
              <div key={a.name} className={`rounded-lg border px-3.5 py-3 ${a.recommended ? "border-sky-800/50 bg-sky-950/15" : "border-[#232a35] bg-[#11151c]"}`}>
                <div className="flex items-center gap-2">
                  <span className="text-[13px] font-semibold text-zinc-100">{a.name}</span>
                  <Badge tone="zinc">{a.tag}</Badge>
                  {a.recommended && <Badge tone="blue">live now</Badge>}
                </div>
                <p className="text-[11.5px] text-zinc-500 mt-1 leading-snug">{a.notes}</p>
              </div>
            ))}
          </div>
        </Card>
        <Card className="col-span-12 lg:col-span-7">
          <SectionTitle title="Behavior you must design for" />
          <div className="space-y-2.5">
            {STORE_BEHAVIORS.map((b) => (
              <div key={b.title} className="rounded-lg border border-[#232a35] bg-[#11151c] px-3.5 py-3">
                <div className="text-[12.5px] font-medium text-zinc-200">{b.title}</div>
                <p className="text-[11.5px] text-zinc-500 mt-1 leading-relaxed">{b.body}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <SectionTitle title="Live mirror_error feed" subtitle="From sessions running across the fleet right now." />
        {stats && stats.recentErrors.length === 0 ? (
          <div className="text-[13px] text-zinc-600 py-2">No dropped batches. ✔</div>
        ) : (
          <div className="space-y-2">
            {stats?.recentErrors.map((e) => (
              <Link key={e.id} href={`/sessions/${e.sessionId}`} className="block rounded-lg border border-rose-900/40 bg-rose-950/20 px-3.5 py-2.5 hover:border-rose-700/60">
                <div className="flex items-center gap-2">
                  <Badge tone="red">mirror_error</Badge>
                  <span className="text-[12.5px] text-zinc-200">{e.title}</span>
                  <span className="ml-auto text-[11px] text-zinc-600">{timeAgo(e.createdAt)}</span>
                </div>
                <p className="text-[11.5px] text-zinc-500 mt-1">{e.text}</p>
              </Link>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}

function FlowBox({ title, subtitle, lines, tone, small }: { title: string; subtitle?: string; lines: string[]; tone: "amber" | "zinc" | "blue" | "red" | "teal"; small?: boolean }) {
  const tones = {
    amber: "border-amber-800/40 bg-amber-950/10",
    zinc: "border-[#2a3140] bg-[#12161d]",
    blue: "border-sky-800/40 bg-sky-950/15",
    red: "border-rose-800/50 bg-rose-950/20",
    teal: "border-teal-800/40 bg-teal-950/15",
  };
  return (
    <div className={`rounded-xl border px-4 ${small ? "py-2.5" : "py-3.5"} ${tones[tone]} w-[220px]`}>
      <div className="text-[12.5px] font-semibold text-zinc-100 mono">{title}</div>
      {subtitle && <div className="text-[10.5px] text-zinc-600 mono">{subtitle}</div>}
      <div className="mt-1.5 space-y-0.5">
        {lines.map((l) => <div key={l} className="text-[11px] text-zinc-500">{l}</div>)}
      </div>
    </div>
  );
}

function Arrow({ label }: { label: string }) {
  return (
    <div className="self-center flex flex-col items-center px-1">
      <span className="text-[10px] text-zinc-600 mb-1">{label}</span>
      <span className="text-zinc-600 text-lg">→</span>
    </div>
  );
}
