const base = "http://127.0.0.1:3000";
const j = (r) => r.json();
async function launch(body) {
  const r = await fetch(`${base}/api/sessions`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  if (!r.ok) throw new Error("launch: " + (await r.text()));
  return j(r);
}
async function drive(id, max=120) {
  let d;
  for (let i=0;i<max;i++){
    d = await (await fetch(`${base}/api/sessions/${id}?drive=1`)).json();
    if (!["starting","running"].includes(d.session.status)) return d;
    await new Promise(res=>setTimeout(res,200));
  }
  return d;
}
async function act(id, action, extra={}) {
  const r = await fetch(`${base}/api/sessions/${id}/actions`, { method:"POST", headers:{"Content-Type":"application/json"}, body: JSON.stringify({action,...extra}) });
  return { status: r.status, body: await r.json() };
}
try {
let { id: e1 } = await launch({ tenantId:"acme-corp", prompt:"Fix the flaky auth rate limit test", sdk:"typescript", pattern:"ephemeral", storeBackend:"postgres" });
let d1 = await drive(e1);
console.log("1 ephemeral:", d1.session.status, d1.session.resultSubtype, "entries:", d1.entries.length, "cost:", d1.session.totalCostUsd, "spans:", d1.spans.length);

let { id: e2 } = await launch({ tenantId:"acme-corp", prompt:"Triage the support inbox and draft replies", pattern:"long-running", storeBackend:"redis" });
let d2 = await drive(e2);
console.log("2 long-running parked:", d2.session.status, "turns:", d2.session.turns);
await act(e2, "turn", { prompt:"Deploy and ship it now" });
d2 = await drive(e2);
console.log("2 after turn:", d2.session.status, d2.session.resultSubtype, "turns:", d2.session.turns);
await act(e2, "stop");
d2 = await drive(e2);
console.log("2 stopped:", d2.session.status, d2.session.resultSubtype);

let { id: e3 } = await launch({ tenantId:"umbrellaco", prompt:"Compile a Q4 competitor pricing scan", pattern:"hybrid", storeBackend:"postgres" });
let d3 = await drive(e3);
await act(e3, "suspend");
let res = await act(e3, "resume");
console.log("3 resume:", res.status, "new:", res.body.sessionId?.slice(0,8));
if (res.body.sessionId) {
  let d3b = await drive(res.body.sessionId);
  const hyd = d3b.entries.filter(e=>e.hydrated).length;
  const storeOnly = d3b.entries.filter(e=>!e.onDisk && e.inStore).length;
  console.log("3 resumed:", d3b.session.status, d3b.session.resultSubtype, "hydrated:", hyd, "store-only after end:", storeOnly, "host changed:", d3b.host.name !== d3.host.name);
}

let fk = await act(e1, "fork");
if (fk.body.sessionId) {
  let df = await drive(fk.body.sessionId);
  console.log("4 fork:", df.session.status, "rewritten:", df.entries.filter(e=>e.data?.forked_from).length);
}

let { id: e5 } = await launch({ tenantId:"globex", prompt:"Fix a bug in the billing worker", pattern:"ephemeral", maxTurns:1 });
let d5 = await drive(e5);
console.log("5 maxTurns:", d5.session.status, d5.session.resultSubtype);

let { id: e6 } = await launch({ tenantId:"initech", prompt:"Publish a website from the template", pattern:"long-running", storeBackend:"none" });
await drive(e6);
await act(e6, "suspend");
let bad = await act(e6, "resume");
console.log("6 no-store resume:", bad.status, bad.body.error?.slice(0,80));

const r7 = await fetch(`${base}/api/sessions`, {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({tenantId:"acme-corp",prompt:"x",pattern:"hybrid",storeBackend:"none"})});
console.log("7 hybrid no-store:", r7.status, (await r7.json()).error?.slice(0,80));
console.log("DONE");
} catch(e) { console.error("FATAL", e); }
