"use client";

import { useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Card, Badge, StatusPill, PatternBadge, StoreBadge, Button } from "@/components/ui";
import { usd, compactNum, timeAgo, classNames } from "@/lib/util";

type Row = {
  id: string;
  title: string;
  tenantId: string;
  tenantName: string;
  hostName: string | null;
  provider: string | null;
  region: string | null;
  sdk: string;
  pattern: string;
  model: string;
  status: string;
  resultSubtype: string | null;
  pid: number | null;
  turns: number;
  maxTurns: number;
  totalCostUsd: number;
  inputTokens: number;
  outputTokens: number;
  storeBackend: string;
  storeErrors: number;
  storeResume: boolean;
  resumedFrom: string | null;
  forkDepth: number;
  cwd: string;
  endUserId: string;
  lastActiveAt: string;
};

const STATUS_ORDER = ["running", "starting", "awaiting_input", "suspended", "failed", "completed"];

export default function SessionsPage() {
  const [rows, setRows] = useState<Row[]>([]);
  const [status, setStatus] = useState("all");
  const [pattern, setPattern] = useState("all");
  const [q, setQ] = useState("");

  useEffect(() => {
    let stop = false;
    const load = async () => {
      const r = await fetch("/api/sessions", { cache: "no-store" });
      if (r.ok && !stop) setRows((await r.json()).sessions);
    };
    load();
    const t = setInterval(load, 2500);
    return () => {
      stop = true;
      clearInterval(t);
    };
  }, []);

  const filtered = useMemo(() => {
    return rows
      .filter((r) => (status === "all" ? true : r.status === status))
      .filter((r) => (pattern === "all" ? true : r.pattern === pattern))
      .filter((r) => (q ? (r.title + r.tenantName + r.id + r.endUserId).toLowerCase().includes(q.toLowerCase()) : true))
      .sort((a, b) => STATUS_ORDER.indexOf(a.status) - STATUS_ORDER.indexOf(b.status) || +new Date(b.lastActiveAt) - +new Date(a.lastActiveAt));
  }, [rows, status, pattern, q]);

  return (
    <div className="p-8 max-w-[1280px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-6">
        <div>
          <h1 className="text-xl font-semibold text-zinc-100">Sessions</h1>
          <p className="text-[13px] text-zinc-500 mt-1">
            Each row is one <span className="mono text-zinc-300">claude</span> CLI subprocess. Open one to watch the message stream, dual-write mirroring, and its
            OpenTelemetry trace.
          </p>
        </div>
        <Link href="/launch" className="btn btn-primary">
          ＋ Launch agent
        </Link>
      </header>

      <Card className="p-3 mb-4">
        <div className="flex flex-wrap gap-2 items-center">
          <input className="input-dark max-w-[260px]" placeholder="Search title, tenant, user…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="input-dark max-w-[170px]" value={status} onChange={(e) => setStatus(e.target.value)}>
            <option value="all">All statuses</option>
            {STATUS_ORDER.map((s) => (
              <option key={s} value={s}>
                {s.replace("_", " ")}
              </option>
            ))}
          </select>
          <select className="input-dark max-w-[170px]" value={pattern} onChange={(e) => setPattern(e.target.value)}>
            <option value="all">All patterns</option>
            <option value="ephemeral">Ephemeral</option>
            <option value="long-running">Long-running</option>
            <option value="hybrid">Hybrid</option>
            <option value="multi-agent">Multi-agent</option>
          </select>
          <span className="text-[12px] text-zinc-600 ml-auto mono">{filtered.length} sessions</span>
        </div>
      </Card>

      <Card className="p-0 overflow-x-auto">
        <table className="w-full min-w-[940px] text-[12.5px]">
          <thead>
            <tr className="text-left text-[10.5px] uppercase tracking-wider text-zinc-600 border-b border-[#1e232c]">
              <th className="font-semibold px-4 py-3">Session</th>
              <th className="font-semibold px-3 py-3">Tenant</th>
              <th className="font-semibold px-3 py-3">Pattern</th>
              <th className="font-semibold px-3 py-3">Status</th>
              <th className="font-semibold px-3 py-3">Store</th>
              <th className="font-semibold px-3 py-3">Host</th>
              <th className="font-semibold px-3 py-3 text-right">Turns</th>
              <th className="font-semibold px-3 py-3 text-right">Tokens</th>
              <th className="font-semibold px-3 py-3 text-right">Cost</th>
              <th className="font-semibold px-4 py-3 text-right">Active</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <tr key={r.id} className="border-b border-[#181d25] last:border-0 hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <Link href={`/sessions/${r.id}`} className="block">
                    <span className="text-zinc-100 font-medium hover:text-[#e8a089]">{r.title}</span>
                    <span className="flex items-center gap-1.5 mt-1">
                      <span className="mono text-[10.5px] text-zinc-600">{r.id.slice(0, 8)}</span>
                      {r.resumedFrom && <Badge tone="violet">resumed {r.resumedFrom.slice(0, 6)}</Badge>}
                      {r.forkDepth > 0 && <Badge tone="teal">fork ×{r.forkDepth}</Badge>}
                      {r.resultSubtype && r.resultSubtype !== "success" && <Badge tone="red">{r.resultSubtype.replace("error_", "")}</Badge>}
                    </span>
                  </Link>
                </td>
                <td className="px-3 py-3">
                  <div className="text-zinc-300">{r.tenantName}</div>
                  <div className="text-[10.5px] text-zinc-600 mono">{r.endUserId}</div>
                </td>
                <td className="px-3 py-3">
                  <PatternBadge pattern={r.pattern} />
                </td>
                <td className="px-3 py-3">
                  <StatusPill status={r.status} />
                  {r.pid && <div className="mono text-[10.5px] text-zinc-600 mt-1">pid {r.pid}</div>}
                </td>
                <td className="px-3 py-3">
                  <div className="flex items-center gap-1.5">
                    <StoreBadge backend={r.storeBackend} />
                    {r.storeErrors > 0 && <Badge tone="red">×{r.storeErrors}</Badge>}
                  </div>
                  <div className="text-[10.5px] text-zinc-600 mt-1">{r.sdk}</div>
                </td>
                <td className="px-3 py-3">
                  <div className="text-zinc-400">{r.hostName ?? "—"}</div>
                  <div className="text-[10.5px] text-zinc-600 mono">{r.provider} · {r.region}</div>
                </td>
                <td className="px-3 py-3 text-right mono text-zinc-400">
                  {r.turns}
                  <span className="text-zinc-700">/{r.maxTurns}</span>
                </td>
                <td className="px-3 py-3 text-right mono text-zinc-400">{compactNum(r.inputTokens + r.outputTokens)}</td>
                <td className={classNames("px-3 py-3 text-right mono", r.totalCostUsd > 0.01 ? "text-[#e8a089]" : "text-zinc-500")}>{usd(r.totalCostUsd)}</td>
                <td className="px-4 py-3 text-right text-[11px] text-zinc-500">{timeAgo(r.lastActiveAt)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length === 0 && <div className="p-10 text-center text-zinc-600 text-sm">No sessions match.</div>}
      </Card>
    </div>
  );
}
