"use client";

import { useState } from "react";
import { Card, CodeBlock, SectionTitle, Badge, Toggle, Tabs } from "@/components/ui";
import { ISOLATION_TECH, DOCKER_FLAGS, SECRET_FILES, AUTH_METHODS } from "@/lib/content";
import { dockerRun, DEFAULT_DOCKER, type DockerOpts } from "@/lib/generators";

const DOCKERFILE = `# Bundled native binary is pinned to the SDK package version.
FROM node:22-slim AS runtime
RUN apt-get update && apt-get install -y --no-install-recommends ca-certificates \\
    && rm -rf /var/lib/apt/lists/*
WORKDIR /app
# Reinstall the SDK IN the image so the optional-dependency native
# binary matches the container architecture and libc.
COPY package*.json ./
RUN npm ci --include=optional
COPY . .
USER 1000:1000
# The subprocess never listens on the network; only your app does.
ENTRYPOINT ["node", "dist/server.js"]`;

export default function SecurityPage() {
  const [o, setO] = useState<DockerOpts>(DEFAULT_DOCKER);
  const set = (k: keyof DockerOpts, v: unknown) => setO((cur) => ({ ...cur, [k]: v }));

  return (
    <div className="p-8 max-w-[1240px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-7">
        <div className="min-w-0">
        <h1 className="text-xl font-semibold text-zinc-100">Security &amp; isolation</h1>
        <p className="text-[13px] text-zinc-500 mt-1 max-w-3xl">
          The agent runs <i>inside</i> the isolation boundary; controls restrict what it can reach from within. The strongest default pairs a locked-down container with a
          host-side egress proxy that allowlists domains, injects credentials, and logs every request.
        </p>
        </div>
      </header>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12 lg:col-span-4">
          <SectionTitle title="Hardened docker run" subtitle="Toggle controls; the command regenerates live." />
          <div className="space-y-2.5">
            <Toggle checked={o.capDrop} onChange={(v) => set("capDrop", v)} label="--cap-drop ALL" />
            <Toggle checked={o.noNewPrivs} onChange={(v) => set("noNewPrivs", v)} label="no-new-privileges" />
            <Toggle checked={o.seccomp} onChange={(v) => set("seccomp", v)} label="custom seccomp profile" />
            <Toggle checked={o.readOnly} onChange={(v) => set("readOnly", v)} label="--read-only root fs" />
            <Toggle checked={o.tmpfs} onChange={(v) => set("tmpfs", v)} label="noexec tmpfs scratch" />
            <Toggle checked={o.networkNone} onChange={(v) => set("networkNone", v)} label="--network none + proxy socket" />
            <Toggle checked={o.nonRoot} onChange={(v) => set("nonRoot", v)} label="non-root user 1000:1000" />
            <Toggle checked={o.readOnlyCode} onChange={(v) => set("readOnlyCode", v)} label="read-only code mount" />
            <Toggle checked={o.sockProxy} onChange={(v) => set("sockProxy", v)} label="mount egress proxy socket" />
            <div className="grid grid-cols-3 gap-2 pt-2">
              <Num label="RAM GB" value={o.memoryGb} onChange={(v) => set("memoryGb", v)} min={1} max={16} />
              <Num label="CPUs" value={o.cpus} onChange={(v) => set("cpus", v)} min={1} max={16} />
              <Num label="pids" value={o.pids} onChange={(v) => set("pids", v)} min={10} max={1000} step={10} />
            </div>
          </div>
        </Card>
        <div className="col-span-12 lg:col-span-8 space-y-4">
          <CodeBlock title="hardened-run.sh" lang="bash" code={dockerRun(o)} />
          <Tabs
            tabs={[
              { key: "dockerfile", label: "Dockerfile pitfalls", content: <CodeBlock lang="dockerfile" code={DOCKERFILE} /> },
              {
                key: "flags",
                label: "What each flag does",
                content: (
                  <div className="space-y-1.5">
                    {DOCKER_FLAGS.map((f) => (
                      <div key={f.flag} className="grid grid-cols-1 sm:grid-cols-12 gap-1 sm:gap-3 rounded-lg border border-[#232a35] bg-[#11151c] px-3 py-2">
                        <span className="sm:col-span-4 min-w-0 break-all mono text-[10.5px] text-[#e8a089]">{f.flag}</span>
                        <span className="sm:col-span-8 min-w-0 break-words text-[11.5px] text-zinc-400">{f.purpose}</span>
                      </div>
                    ))}
                  </div>
                ),
              },
            ]}
          />
        </div>
      </div>

      <Card className="mb-6">
        <SectionTitle title="Isolation technologies" subtitle="Trade isolation strength against performance and operational complexity." />
        <div className="overflow-x-auto">
          <table className="w-full text-[12px]">
            <thead>
              <tr className="text-left text-[10.5px] uppercase tracking-wider text-zinc-600 border-b border-[#1e232c]">
                <th className="font-semibold px-3 py-2.5">Technology</th>
                <th className="font-semibold px-3 py-2.5">Strength</th>
                <th className="font-semibold px-3 py-2.5">Overhead</th>
                <th className="font-semibold px-3 py-2.5">Complexity</th>
                <th className="font-semibold px-3 py-2.5">Notes</th>
              </tr>
            </thead>
            <tbody>
              {ISOLATION_TECH.map((t) => (
                <tr key={t.tech} className="border-b border-[#181d25] last:border-0 align-top">
                  <td className="px-3 py-2.5 font-medium text-zinc-200">{t.tech}</td>
                  <td className="px-3 py-2.5"><Badge tone={t.strength.startsWith("Excellent") ? "green" : "blue"}>{t.strength}</Badge></td>
                  <td className="px-3 py-2.5 text-zinc-400">{t.overhead}</td>
                  <td className="px-3 py-2.5 text-zinc-400">{t.complexity}</td>
                  <td className="px-3 py-2.5 text-zinc-500">{t.note}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12 lg:col-span-6">
          <SectionTitle title="The credential proxy pattern" subtitle="The agent never sees the real credential; the proxy adds it outside the boundary." />
          <div className="flex flex-wrap items-stretch gap-2 mb-4">
            <Box tone="amber" title="Agent container" lines={["no credentials in env", "--network none"]} />
            <Arr />
            <Box tone="zinc" title="Unix socket / proxy" lines={["domain allowlist", "injects auth header", "logs every request"]} />
            <Arr />
            <Box tone="teal" title="Upstream" lines={["api.anthropic.com", "MCP servers / tools"]} />
          </div>
          <CodeBlock
            title="proxy routing"
            lang="bash"
            compact
            code={`# Option 1 — sampling only; plaintext proxy can inject the key:
ANTHROPIC_BASE_URL=http://egress-proxy:8080

# Option 2 — system-wide; CONNECT tunnel (proxy can't read contents):
HTTP_PROXY=http://egress-proxy:8080
HTTPS_PROXY=http://egress-proxy:8080

# For arbitrary HTTPS services use a TLS-terminating proxy with its
# CA in the agent trust store. Node fetch ignores these vars unless
# NODE_USE_ENV_PROXY=1 (Node 24+).`}
          />
          <p className="text-[11.5px] text-zinc-500 mt-3">
            Reference proxies: Envoy (credential_injector), mitmproxy (TLS termination), Squid (ACLs), LiteLLM (LLM gateway with rate limits).
          </p>
        </Card>

        <div className="col-span-12 lg:col-span-6 space-y-4">
          <Card>
            <SectionTitle title="Anthropic auth surfaces" />
            <div className="space-y-2">
              {AUTH_METHODS.map((a) => (
                <div key={a.env} className="rounded-lg border border-[#232a35] bg-[#11151c] px-3 py-2.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="mono text-[11px] text-sky-300">{a.env}</span>
                    <Badge tone="zinc">{a.provider}</Badge>
                  </div>
                  <p className="text-[11.5px] text-zinc-500 mt-1">{a.note}</p>
                </div>
              ))}
            </div>
            <p className="text-[11.5px] text-zinc-600 mt-3">
              Inbound: authenticate users at your gateway. The agent container receives pre-authenticated requests — it must never be the component validating user tokens.
            </p>
          </Card>
          <Card>
            <SectionTitle title="Never mount these into a container" subtitle="Even read-only mounts expose credentials." />
            <div className="flex flex-wrap gap-1.5">
              {SECRET_FILES.map((s) => (
                <span key={s} className="badge bg-rose-500/10 text-rose-300 border-rose-500/25 mono text-[10.5px]">{s}</span>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Num({ label, value, onChange, min, max, step = 1 }: { label: string; value: number; onChange: (n: number) => void; min: number; max: number; step?: number }) {
  return (
    <label className="block">
      <span className="block text-[10px] uppercase tracking-wider text-zinc-600 mb-1">{label}</span>
      <input type="number" min={min} max={max} step={step} className="input-dark" value={value} onChange={(e) => onChange(Number(e.target.value))} />
    </label>
  );
}

function Box({ title, lines, tone }: { title: string; lines: string[]; tone: "amber" | "zinc" | "teal" }) {
  const tones = { amber: "border-amber-800/40 bg-amber-950/10", zinc: "border-[#2a3140] bg-[#12161d]", teal: "border-teal-800/40 bg-teal-950/15" };
  return (
    <div className={`rounded-xl border px-3.5 py-3 flex-1 min-w-[160px] ${tones[tone]}`}>
      <div className="text-[12px] font-semibold text-zinc-100">{title}</div>
      {lines.map((l) => <div key={l} className="text-[10.5px] text-zinc-500 mt-0.5">{l}</div>)}
    </div>
  );
}
function Arr() {
  return <div className="self-center text-zinc-600 text-lg">→</div>;
}
