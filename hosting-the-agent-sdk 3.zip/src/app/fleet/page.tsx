"use client";

import { useEffect, useState } from "react";
import { Card, Field, Button, StatusPill, ProgressBar, Toast, CodeBlock, SectionTitle, Badge } from "@/components/ui";
import { PROVIDER_QUESTIONS, RUNTIME_DEPS, NETWORK_NOTES, LIMITATIONS } from "@/lib/content";
import { capacity } from "@/lib/generators";
import { classNames } from "@/lib/util";

type Host = {
  id: string;
  name: string;
  provider: string;
  region: string;
  runtime: string;
  ramMb: number;
  cpus: number;
  overheadMb: number;
  perSessionRamMb: number;
  status: string;
  note: string | null;
  pinned: number;
  live: number;
  capacity: number;
};

const PROVIDERS = ["docker", "kubernetes", "modal", "gvisor", "firecracker", "bare-metal"];

export default function FleetPage() {
  const [hosts, setHosts] = useState<Host[]>([]);
  const [form, setForm] = useState({ name: "", provider: "docker", region: "us-east-1", runtime: "node", ramMb: 4096, cpus: 2, overheadMb: 512, perSessionRamMb: 1024, note: "" });
  const [toast, setToast] = useState<string | null>(null);

  // calculator
  const [ramGb, setRamGb] = useState(8);
  const [overhead, setOverhead] = useState(1024);
  const [perSession, setPerSession] = useState(1024);
  const [target, setTarget] = useState(100);

  const load = async () => setHosts((await (await fetch("/api/hosts", { cache: "no-store" })).json()).hosts);
  useEffect(() => {
    // Initial fetch is deferred so no setState runs synchronously in the effect.
    const kick = setTimeout(load, 0);
    const t = setInterval(load, 4000);
    return () => {
      clearTimeout(kick);
      clearInterval(t);
    };
  }, []);

  const cap = capacity({ ramMb: ramGb * 1024, overheadMb: overhead, perSessionRamMb: perSession });
  const hostsNeeded = Math.max(1, Math.ceil(target / Math.max(1, cap)));

  async function addHost() {
    if (!form.name) return;
    const r = await fetch("/api/hosts", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    if (!r.ok) return setToast("Could not add host");
    setForm({ ...form, name: "" });
    load();
  }

  return (
    <div className="p-8 max-w-[1280px] mx-auto">
      <header className="flex flex-wrap items-start justify-between gap-3 mb-6">
        <div>
        <h1 className="text-xl font-semibold text-zinc-100">Fleet &amp; capacity</h1>
        <p className="text-[13px] text-zinc-500 mt-1">
          Each session is a subprocess, so concurrency on a host is bounded by RAM. Long-running sessions pin to one container by consistent hashing on
          <span className="mono text-zinc-300"> sessionId</span>.
        </p>
        </div>
      </header>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <div className="col-span-12 lg:col-span-8">
          <SectionTitle title="Hosts" subtitle="Live subprocess counts vs. RAM-derived capacity." />
          <div className="space-y-3">
            {hosts.map((h) => {
              const pct = h.capacity ? Math.round((h.live / h.capacity) * 100) : 0;
              return (
                <Card key={h.id} className="p-4">
                  <div className="flex items-center gap-3 flex-wrap">
                    <span className="text-[13.5px] font-semibold text-zinc-100">{h.name}</span>
                    <Badge tone="zinc">{h.provider}</Badge>
                    <span className="mono text-[11px] text-zinc-500">{h.region} · {h.runtime} · {h.cpus} vCPU · {(h.ramMb / 1024).toFixed(h.ramMb % 1024 ? 1 : 0)} GiB</span>
                    <span className="ml-auto"><StatusPill status={h.status} /></span>
                  </div>
                  <div className="flex items-center gap-3 mt-3">
                    <div className="flex-1"><ProgressBar pct={pct} /></div>
                    <span className="mono text-[12px] text-zinc-300 w-40 text-right">{h.live} live / {h.pinned} pinned · cap {h.capacity}</span>
                  </div>
                  {h.note && <p className="text-[11.5px] text-zinc-600 mt-2">{h.note}</p>}
                </Card>
              );
            })}
          </div>
        </div>

        <div className="col-span-12 lg:col-span-4 space-y-4">
          <Card>
            <SectionTitle title="Add host" />
            <div className="space-y-2.5">
              <input className="input-dark" placeholder="host name, e.g. docker-runner-02" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
              <div className="grid grid-cols-2 gap-2">
                <select className="input-dark" value={form.provider} onChange={(e) => setForm({ ...form, provider: e.target.value })}>
                  {PROVIDERS.map((p) => <option key={p}>{p}</option>)}
                </select>
                <input className="input-dark" placeholder="region" value={form.region} onChange={(e) => setForm({ ...form, region: e.target.value })} />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <input type="number" className="input-dark" placeholder="RAM MiB" value={form.ramMb} onChange={(e) => setForm({ ...form, ramMb: +e.target.value })} />
                <input type="number" className="input-dark" placeholder="overhead" value={form.overheadMb} onChange={(e) => setForm({ ...form, overheadMb: +e.target.value })} />
                <input type="number" className="input-dark" placeholder="MiB/agent" value={form.perSessionRamMb} onChange={(e) => setForm({ ...form, perSessionRamMb: +e.target.value })} />
              </div>
              <Button variant="primary" className="w-full justify-center" onClick={addHost}>Provision host</Button>
            </div>
          </Card>

          <Card>
            <SectionTitle title="Capacity formula" />
            <CodeBlock
              compact
              title="agents per host"
              code={`agents per host = (host RAM − overhead) / per-session RAM ceiling
             = (${ramGb} GiB − ${(overhead / 1024).toFixed(1)} GiB) / ${(perSession / 1024).toFixed(2)} GiB
             = ${cap} agents`}
            />
            <div className="space-y-2 mt-3 text-[12px]">
              <Range label="Host RAM" unit="GiB" min={1} max={64} value={ramGb} onChange={setRamGb} />
              <Range label="OS / runtime overhead" unit="MiB" min={128} max={4096} step={128} value={overhead} onChange={setOverhead} />
              <Range label="Per-session RAM ceiling (measured peak RSS)" unit="MiB" min={384} max={4096} step={64} value={perSession} onChange={setPerSession} />
              <Range label="Target concurrent sessions" unit="" min={1} max={1000} value={target} onChange={setTarget} />
              <div className="rounded-lg bg-[#141a23] border border-[#232a35] px-3 py-2.5 flex items-center justify-between">
                <span className="text-zinc-400">Hosts required</span>
                <span className="mono text-lg text-[#e8a089] font-semibold">{hostsNeeded}</span>
              </div>
              <p className="text-[11px] text-zinc-600 leading-relaxed">
                The 1 GiB starting point is a floor. Run a representative session to your target length under real tool load and record peak RSS — memory grows with
                session length and tool activity.
              </p>
            </div>
          </Card>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12 lg:col-span-4">
          <SectionTitle title="Choose a sandbox provider" />
          <ul className="space-y-2.5">
            {PROVIDER_QUESTIONS.map((x) => (
              <li key={x.q} className="text-[12px]">
                <div className="font-medium text-zinc-300">{x.q}</div>
                <div className="text-zinc-500 leading-snug mt-0.5">{x.a}</div>
              </li>
            ))}
          </ul>
        </Card>
        <Card className="col-span-12 lg:col-span-4">
          <SectionTitle title="Runtime dependencies" />
          <ul className="space-y-2 text-[12px] text-zinc-400">
            {RUNTIME_DEPS.map((d) => <li key={d} className="flex gap-2"><span className="text-[#d97757]">•</span><span className="leading-snug">{d}</span></li>)}
          </ul>
        </Card>
        <Card className="col-span-12 lg:col-span-4">
          <SectionTitle title="Network" />
          <ul className="space-y-2 text-[12px] text-zinc-400">
            {NETWORK_NOTES.map((d) => <li key={d} className="flex gap-2"><span className="text-[#d97757]">•</span><span className="leading-snug">{d}</span></li>)}
          </ul>
          <p className="text-[11.5px] text-zinc-600 mt-3">
            Token cost typically dominates container cost by ~10×: a minimal container is roughly $0.05/hr while one long agent session can spend dollars in tokens.
          </p>
        </Card>
      </div>

      <Card>
        <SectionTitle title="Plan around the known limitations" />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {LIMITATIONS.map((l) => (
            <div key={l.limitation} className="rounded-lg border border-[#232a35] bg-[#11151c] p-3.5">
              <div className="text-[12.5px] font-medium text-amber-300">{l.limitation}</div>
              <div className="text-[12px] text-zinc-500 mt-1 leading-snug">{l.fix}</div>
            </div>
          ))}
        </div>
      </Card>

      <Toast message={toast} />
    </div>
  );
}

function Range({ label, unit, min, max, step = 1, value, onChange }: { label: string; unit: string; min: number; max: number; step?: number; value: number; onChange: (n: number) => void }) {
  return (
    <label className="block">
      <div className="flex justify-between text-[11px] text-zinc-500 mb-0.5">
        <span>{label}</span>
        <span className="mono text-zinc-300">{value} {unit}</span>
      </div>
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(+e.target.value)} className="w-full accent-[#d97757]" />
    </label>
  );
}
