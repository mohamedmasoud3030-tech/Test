"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Badge, Button, Card, CodeBlock, Field, PatternBadge, StatusPill, StoreBadge, Toast, ProgressBar } from "@/components/ui";
import { usd, compactNum, classNames, timeAgo, modelLabel } from "@/lib/util";

type Entry = {
  id: string;
  seq: number;
  role: string;
  kind: string;
  subtype: string | null;
  toolName: string | null;
  text: string | null;
  data: any;
  subpath: string | null;
  onDisk: boolean;
  inStore: boolean;
  hydrated: boolean;
  createdAt: string;
};
type Span = {
  id: string;
  spanId: string;
  parentSpanId: string | null;
  kind: string;
  name: string;
  status: string;
  durationMs: number;
  attributes: any;
  startedAt: string;
};
type Detail = {
  session: any;
  tenant: any;
  host: any;
  entries: Entry[];
  spans: Span[];
};

export function SessionConsole({ id }: { id: string }) {
  const [d, setD] = useState<Detail | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [prompt, setPrompt] = useState("");
  const [toast, setToast] = useState<string | null>(null);
  const streamRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  const load = useCallback(async () => {
    const r = await fetch(`/api/sessions/${id}?drive=1`, { cache: "no-store" });
    if (r.status === 404) {
      setError("Session not found");
      return;
    }
    const data = await r.json();
    setD((prev) => {
      const grew = (data?.entries?.length ?? 0) > (prev?.entries?.length ?? 0);
      if (grew && streamRef.current) {
        const el = streamRef.current;
        const nearBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 220;
        if (nearBottom) setTimeout(() => (el.scrollTop = el.scrollHeight), 60);
      }
      return data;
    });
  }, [id]);

  useEffect(() => {
    // Deferred initial tick: setState runs in a timer callback, not in the effect body.
    const kick = setTimeout(load, 0);
    const t = setInterval(load, 1400);
    return () => {
      clearTimeout(kick);
      clearInterval(t);
    };
  }, [load]);

  const act = async (action: string, extra?: Record<string, unknown>) => {
    const r = await fetch(`/api/sessions/${id}/actions`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, ...extra }),
    });
    const body = await r.json().catch(() => ({}));
    if (!r.ok) {
      setToast(body.error ?? "Action failed");
      return;
    }
    if (body.sessionId) router.push(`/sessions/${body.sessionId}`);
    else load();
  };

  if (error) return <div className="p-10 text-rose-300">{error}</div>;
  if (!d) return <div className="p-10 text-zinc-500">Loading subprocess…</div>;

  const s = d.session;
  const live = ["starting", "running"].includes(s.status);
  const main = d.entries.filter((e) => !e.subpath);
  const subGroups = new Map<string, Entry[]>();
  for (const e of d.entries) {
    if (e.subpath) subGroups.set(e.subpath, [...(subGroups.get(e.subpath) ?? []), e]);
  }
  const onDisk = d.entries.filter((e) => e.onDisk).length;
  const inStore = d.entries.filter((e) => e.inStore).length;
  const dropped = d.entries.filter((e) => !e.onDisk && !e.inStore).length;
  const hydrated = d.entries.filter((e) => e.hydrated).length;
  const noDurable = s.status === "suspended" && inStore === 0;

  return (
    <div className="p-8 max-w-[1380px] mx-auto">
      <Link href="/sessions" className="text-[12px] text-zinc-500 hover:text-zinc-300">
        ← all sessions
      </Link>

      <header className="flex flex-wrap items-start justify-between gap-4 mt-2 mb-6">
        <div className="min-w-0">
          <div className="flex items-center gap-2.5 flex-wrap">
            <h1 className="text-lg font-semibold text-zinc-100">{s.title}</h1>
            <StatusPill status={s.status} />
            <PatternBadge pattern={s.pattern} />
            <StoreBadge backend={s.storeBackend} />
            {s.storeErrors > 0 && <Badge tone="red">{s.storeErrors} mirror errors</Badge>}
            {s.storeResume && <Badge tone="violet">resumed from store</Badge>}
            {s.forkDepth > 0 && <Badge tone="teal">fork depth {s.forkDepth}</Badge>}
          </div>
          <p className="text-[12.5px] text-zinc-500 mt-1.5 max-w-3xl">
            <span className="mono text-zinc-400">{s.id}</span> · {modelLabel(s.model)} · {s.sdk} SDK ·{" "}
            {d.host ? (
              <>
                {d.host.name} <span className="mono text-zinc-600">({d.host.provider} · {d.host.region})</span>
              </>
            ) : (
              "no host"
            )}{" "}
            · tenant {d.tenant?.name}
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {live && <Button variant="danger" onClick={() => act("stop")}>■ Stop (maxTurns)</Button>}
          {s.status === "awaiting_input" && <Button variant="ghost" onClick={() => act("suspend")}>⏻ Spin down</Button>}
          {(s.status === "suspended") && (
            <Button variant="primary" disabled={noDurable} title={noDurable ? "No durable transcript" : "Hydrate from store on a fresh host"} onClick={() => act("resume")}>
              ⏵ Resume on another host
            </Button>
          )}
          {["awaiting_input", "completed", "failed", "suspended"].includes(s.status) && (
            <Button variant="ghost" onClick={() => act("fork")}>⑂ Fork</Button>
          )}
        </div>
      </header>

      {noDurable && (
        <div className="rounded-xl border border-rose-800/50 bg-rose-950/30 px-4 py-3 mb-5 text-[12.5px] text-rose-200">
          <b>Transcript lost.</b> This container had <span className="mono">storeBackend = &quot;none&quot;</span>. The local JSONL died with the container, so there is
          nothing to hydrate — the hybrid pattern requires a SessionStore.
        </div>
      )}
      {hydrated > 0 && (
        <div className="rounded-xl border border-violet-800/40 bg-violet-950/20 px-4 py-3 mb-5 text-[12.5px] text-violet-200">
          Hydrated <b>{hydrated}</b> entries from the {s.storeBackend} store into a temporary <span className="mono">CLAUDE_CONFIG_DIR</span> before spawning. The local
          copy is deleted when this run ends — the store holds the only durable transcript.
        </div>
      )}

      <div className="grid grid-cols-12 gap-4">
        {/* ── Transcript ── */}
        <div className="col-span-12 xl:col-span-8">
          <Card className="p-0 overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 px-4 py-2.5 border-b border-[#1e232c]">
              <div className="text-[12px] text-zinc-400">
                stdio message stream <span className="text-zinc-600 mono">· {s.pid ? `pid ${s.pid}` : "no process"}</span>
              </div>
              <div className="flex flex-wrap items-center gap-2 text-[11px]">
                <span className="text-zinc-500">{main.length} main entries</span>
                {subGroups.size > 0 && <span className="text-teal-400">· {subGroups.size} subagent transcript{subGroups.size > 1 ? "s" : ""}</span>}
              </div>
            </div>
            <div ref={streamRef} className="max-h-[70vh] overflow-y-auto p-4 space-y-2.5">
              <EntryList entries={main} subGroups={subGroups} />
              {live && (
                <div className="flex items-center gap-2 text-[12px] text-zinc-500 pl-1 pt-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 live-dot" />
                  subprocess running · waiting on next SDK message…
                </div>
              )}
            </div>

            {(s.status === "awaiting_input" || live) && (
              <div className="border-t border-[#1e232c] p-3 flex gap-2">
                <input
                  className="input-dark"
                  placeholder={s.status === "awaiting_input" ? "Send another turn over streamInput / ClaudeSDKClient…" : "Subprocess busy…"}
                  disabled={live}
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  onKeyDown={(e) => {
                    if (e.key === "Enter" && prompt.trim()) {
                      act("turn", { prompt: prompt.trim() });
                      setPrompt("");
                    }
                  }}
                />
                <Button variant="primary" disabled={live || !prompt.trim()} onClick={() => { act("turn", { prompt: prompt.trim() }); setPrompt(""); }}>
                  Send
                </Button>
              </div>
            )}
          </Card>
        </div>

        {/* ── Right rail ── */}
        <div className="col-span-12 xl:col-span-4 space-y-4">
          <Card>
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">Subprocess & local state</div>
            <dl className="text-[12px] space-y-2">
              <Meta k="cwd" v={<span className="mono text-[11px]">{s.cwd}</span>} />
              <Meta k="config dir" v={<span className="mono text-[11px]">{s.configDir}</span>} />
              <Meta k="transcript" v={<span className="mono text-[11px] break-all">{s.configDir}/projects/…/{s.id.slice(0, 8)}.jsonl</span>} />
              <Meta k="resumed from" v={s.resumedFrom ? <Link className="text-[#e8a089] hover:underline mono text-[11px]" href={`/sessions/${s.resumedFrom}`}>{s.resumedFrom.slice(0, 8)}</Link> : <span className="text-zinc-600">fresh session</span>} />
              <Meta k="settingSources" v={s.isolateSettings ? <Badge tone="green">[] isolated</Badge> : <Badge tone="amber">user/project/local</Badge>} />
              <Meta k="auto memory" v={s.disableAutoMemory ? <Badge tone="green">disabled</Badge> : <Badge tone="amber">enabled — leaks risk</Badge>} />
            </dl>
          </Card>

          <Card>
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">Turns & cost</div>
            <div className="flex justify-between text-[12px] mb-1.5">
              <span className="text-zinc-400">agent turns</span>
              <span className="mono">{s.turns} / {s.maxTurns}</span>
            </div>
            <ProgressBar pct={(s.turns / s.maxTurns) * 100} />
            <div className="grid grid-cols-2 gap-2 mt-4 text-[12px]">
              <Mini label="input" value={compactNum(s.inputTokens)} />
              <Mini label="output" value={compactNum(s.outputTokens)} />
              <Mini label="cache read" value={compactNum(s.cacheReadTokens)} />
              <Mini label="cache write" value={compactNum(s.cacheCreationTokens)} />
            </div>
            <div className="mt-3 flex items-end justify-between">
              <span className="text-[11px] text-zinc-600">total_cost_usd (result)</span>
              <span className="text-lg font-semibold text-[#e8a089] mono">{usd(Number(s.totalCostUsd))}</span>
            </div>
          </Card>

          <Card>
            <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">Dual-write transcript</div>
            <div className="space-y-1.5 text-[12px]">
              <DurabilityRow n={onDisk} total={d.entries.length} label="on local disk" tone="zinc" />
              <DurabilityRow n={inStore} total={d.entries.length} label={`mirrored to ${s.storeBackend === "none" ? "—" : s.storeBackend}`} tone="blue" />
              <DurabilityRow n={hydrated} total={d.entries.length} label="hydrated from store" tone="teal" />
              <DurabilityRow n={dropped} total={d.entries.length} label="dropped / lost" tone="red" />
            </div>
            <p className="text-[11px] text-zinc-600 mt-3 leading-relaxed">
              The subprocess writes local JSONL first; the SDK then forwards each batch to <span className="mono">SessionStore.append()</span>. Failed batches emit
              mirror_error and continue.
            </p>
          </Card>

          <TraceTrace spans={d.spans} />
        </div>
      </div>

      <Toast message={toast} />
    </div>
  );
}

// ── Transcript entries ─────────────────────────────────────────────────────
function EntryList({ entries, subGroups }: { entries: Entry[]; subGroups: Map<string, Entry[]> }) {
  const out: React.ReactNode[] = [];
  for (let i = 0; i < entries.length; i++) {
    const e = entries[i];
    if (e.kind === "tool_use") {
      const result = entries[i + 1]?.kind === "tool_result" ? entries[i + 1] : null;
      const subEntries = result?.data?.subpath ? subGroups.get(result.data.subpath) ?? [] : [];
      out.push(<ToolCard key={e.id} use={e} result={result} subEntries={subEntries} />);
      if (result) i++;
      continue;
    }
    out.push(<EntryRow key={e.id} e={e} />);
  }
  return <>{out}</>;
}

function Chips({ e }: { e: Entry }) {
  return (
    <span className="flex gap-1 shrink-0">
      {e.hydrated && <span className="badge bg-teal-500/10 text-teal-300/90 border-teal-500/20">hydrated</span>}
      {e.onDisk ? (
        <span className="badge bg-zinc-500/10 text-zinc-400 border-zinc-500/20" title="Written to local JSONL">💾 local</span>
      ) : e.inStore ? (
        <span className="badge bg-sky-500/10 text-sky-300/80 border-sky-500/20" title="Only in the shared store">☁ store-only</span>
      ) : (
        <span className="badge bg-rose-500/10 text-rose-300 border-rose-500/25" title="No durable copy">✕ lost</span>
      )}
      {e.inStore && <span className="badge bg-sky-500/10 text-sky-300 border-sky-500/20" title="Mirrored to the SessionStore">☁ store</span>}
    </span>
  );
}

function EntryRow({ e }: { e: Entry }) {
  if (e.kind === "result") return <ResultCard e={e} />;
  if (e.kind === "meta") {
    const tone =
      e.subtype === "mirror_error" ? "border-rose-800/50 bg-rose-950/25" : e.subtype === "compact_boundary" ? "border-amber-800/40 bg-amber-950/15" : "border-sky-900/40 bg-sky-950/15";
    const icon = e.subtype === "mirror_error" ? "⚠" : e.subtype === "compact_boundary" ? "🗜" : "⚙";
    return (
      <div className={classNames("rounded-lg border px-3.5 py-2.5 text-[12.5px]", tone)}>
        <div className="flex items-center gap-2 mb-1">
          <span>{icon}</span>
          <span className="font-semibold text-zinc-200 mono text-[11px]">{e.subtype ?? "system"}</span>
          <span className="ml-auto"><Chips e={e} /></span>
        </div>
        <p className="text-zinc-400 leading-relaxed">{e.text}</p>
        {e.subtype === "init" && e.data && (
          <div className="mono text-[10.5px] text-zinc-500 mt-2 grid grid-cols-2 gap-x-4 gap-y-0.5">
            <span>pid {e.data.pid}</span>
            <span>store: {e.data.store}</span>
            <span className="col-span-2 break-all">{e.data.transcript_path}</span>
          </div>
        )}
      </div>
    );
  }
  return (
    <div className={classNames("rounded-lg border px-3.5 py-2.5", e.role === "assistant" ? "border-[#252c38] bg-[#12161d]" : "border-[#1f2530] bg-[#0f1319]")}>
      <div className="flex items-center gap-2 mb-1">
        <span className="text-[10.5px] mono uppercase tracking-wider text-zinc-500">{e.role}</span>
        {e.data?.turn && <span className="text-[10.5px] mono text-zinc-600">turn {e.data.turn}</span>}
        <span className="ml-auto"><Chips e={e} /></span>
      </div>
      <p className="text-[12.5px] text-zinc-300 leading-relaxed">{e.text}</p>
    </div>
  );
}

function ToolCard({ use, result, subEntries }: { use: Entry; result: Entry | null; subEntries: Entry[] }) {
  const [open, setOpen] = useState(false);
  const failed = result?.data?.is_error;
  return (
    <div className="rounded-lg border border-[#222936] bg-[#0e1218] overflow-hidden">
      <button type="button" className="w-full min-w-0 flex items-center gap-2.5 px-3.5 py-2.5 text-left hover:bg-white/[0.02]" onClick={() => setOpen((v) => !v)}>
        <span className={classNames("w-6 h-6 shrink-0 rounded-md grid place-items-center text-[11px] font-bold", failed ? "bg-rose-950 text-rose-300 border border-rose-900" : "bg-[#1c2330] text-[#e8a089] border border-[#2b3342]")}>
          {toolIcon(use.toolName)}
        </span>
        <span className="min-w-0 flex-1 truncate mono text-[11.5px] text-zinc-300">{use.text}</span>
        <span className="ml-auto shrink-0 flex items-center gap-2">
          {result && <span className="mono text-[10.5px] text-zinc-600">{result.data?.duration_ms ?? "—"}ms</span>}
          {failed && <Badge tone="red">error</Badge>}
          <Chips e={use} />
          <span className="text-zinc-600 text-[10px]">{open ? "▾" : "▸"}</span>
        </span>
      </button>
      {open && (
        <div className="border-t border-[#1c222c] px-3.5 py-2.5 space-y-2">
          <div>
            <div className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1">input</div>
            <pre className="mono text-[11px] text-zinc-400 whitespace-pre-wrap break-all">{JSON.stringify(use.data?.input, null, 2)}</pre>
          </div>
          {result && (
            <div>
              <div className="text-[10px] uppercase tracking-wider text-zinc-600 mb-1">tool result</div>
              <pre className="mono text-[11px] text-zinc-400 whitespace-pre-wrap break-all max-h-64 overflow-y-auto">{result.text}</pre>
              <div className="mt-1"><Chips e={result} /></div>
            </div>
          )}
          {subEntries.length > 0 && (
            <div className="rounded-lg border border-teal-900/40 bg-teal-950/10 p-2.5">
              <div className="text-[10.5px] uppercase tracking-wider text-teal-400/80 font-semibold mb-2">
                subagent transcript · {result?.data?.subpath}
              </div>
              <div className="space-y-1.5">
                {subEntries.map((se) => (
                  <div key={se.id} className="text-[11.5px]">
                    <span className="mono text-teal-500/70 mr-2">{se.role === "user" ? "← result" : se.toolName ? "→ tool" : "agent"}</span>
                    <span className="text-zinc-400">{se.text}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ResultCard({ e }: { e: Entry }) {
  const ok = e.subtype === "success";
  return (
    <div className={classNames("rounded-xl border px-4 py-3.5", ok ? "border-emerald-800/50 bg-emerald-950/20" : "border-rose-800/50 bg-rose-950/20")}>
      <div className="flex items-center gap-2 mb-1.5">
        <span className="mono text-[11px] font-semibold uppercase tracking-wider">{ok ? "✓ result · success" : `✕ result · ${e.subtype}`}</span>
        <span className="ml-auto"><Chips e={e} /></span>
      </div>
      <p className="text-[12.5px] text-zinc-300 leading-relaxed">{e.text}</p>
      {e.data && (
        <div className="mt-2.5 grid grid-cols-3 gap-2 text-[11px] mono text-zinc-500">
          <span>turns: {e.data.num_turns}</span>
          <span>cost: {usd(Number(e.data.total_cost_usd ?? 0))}</span>
          <span>session: {String(e.data.session_id ?? "").slice(0, 8)}</span>
        </div>
      )}
    </div>
  );
}

function toolIcon(name: string | null): string {
  const map: Record<string, string> = { Bash: "▶", Read: "R", Edit: "E", Write: "W", Glob: "G", Grep: "g", Task: "T", WebFetch: "↓" };
  return (name && map[name]) || "?";
}

function Meta({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="text-zinc-500 shrink-0">{k}</dt>
      <dd className="text-zinc-300 text-right min-w-0">{v}</dd>
    </div>
  );
}

function Mini({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-[#11151c] border border-[#1f2530] px-2.5 py-2">
      <div className="text-[10px] uppercase tracking-wider text-zinc-600">{label}</div>
      <div className="mono text-[13px] text-zinc-200 mt-0.5">{value}</div>
    </div>
  );
}

function DurabilityRow({ n, total, label, tone }: { n: number; total: number; label: string; tone: "zinc" | "blue" | "teal" | "red" }) {
  const colors = { zinc: "bg-zinc-400", blue: "bg-sky-400", teal: "bg-teal-400", red: "bg-rose-400" };
  return (
    <div className="flex items-center gap-2">
      <span className="mono w-8 text-zinc-300">{n}</span>
      <div className="flex-1 h-1.5 rounded-full bg-zinc-800 overflow-hidden">
        <div className={classNames("h-full rounded-full", colors[tone])} style={{ width: `${total ? (n / total) * 100 : 0}%` }} />
      </div>
      <span className="text-zinc-500 w-32 text-right text-[11px]">{label}</span>
    </div>
  );
}

function TraceTrace({ spans }: { spans: Span[] }) {
  const tree = useMemo(() => {
    const byId = new Map(spans.map((s) => [s.spanId, { span: s, children: [] as any[] }]));
    const roots: any[] = [];
    for (const node of byId.values()) {
      if (node.span.parentSpanId && byId.has(node.span.parentSpanId)) byId.get(node.span.parentSpanId)!.children.push(node);
      else if (!node.span.parentSpanId) roots.push(node);
    }
    return roots.sort((a, b) => +new Date(a.span.startedAt) - +new Date(b.span.startedAt));
  }, [spans]);
  const maxDur = Math.max(1000, ...spans.filter((s) => s.kind === "interaction").map((s) => s.durationMs));

  const color: Record<string, string> = {
    interaction: "bg-[#d97757]",
    llm_request: "bg-sky-500",
    tool: "bg-teal-500",
    hook: "bg-violet-500",
  };

  const renderNode = (node: any, depth: number): React.ReactNode => {
    const sp: Span = node.span;
    const width = sp.kind === "interaction" ? Math.max(4, (sp.durationMs / maxDur) * 100) : 100;
    const label = sp.name.replace("claude_code.", "").replace(" · subagent", " ⑂");
    return (
      <div key={sp.id} style={{ marginLeft: depth * 12 }}>
        <div className="flex items-center gap-2 py-[3px]">
          <span className={classNames("h-2 rounded-sm shrink-0", sp.status === "error" ? "bg-rose-500" : color[sp.kind] ?? "bg-zinc-500")} style={{ width: `${Math.min(100, depth === 0 ? width : 60 - depth * 10)}%`, minWidth: 8 }} />
          <span className="mono text-[10.5px] text-zinc-400 truncate">{label}</span>
          <span className="mono text-[10px] text-zinc-600 ml-auto shrink-0">
            {sp.durationMs < 1000 ? `${sp.durationMs}ms` : `${(sp.durationMs / 1000).toFixed(1)}s`}
          </span>
        </div>
        {node.children
          .sort((a: any, b: any) => a.span.durationMs - b.span.durationMs)
          .map((c: any) => renderNode(c, depth + 1))}
      </div>
    );
  };

  return (
    <Card>
      <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-3">OpenTelemetry trace</div>
      {spans.length === 0 ? <div className="text-[12px] text-zinc-600">No spans yet.</div> : <div>{tree.slice(0, 30).map((n) => renderNode(n, 0))}</div>}
      <Link href="/observability" className="block mt-3 text-[11.5px] text-[#e8a089] hover:underline">
        OTEL configuration →
      </Link>
    </Card>
  );
}
