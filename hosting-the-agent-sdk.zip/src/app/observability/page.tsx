"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Card, CodeBlock, Field, Toggle, SectionTitle, Badge, Tabs } from "@/components/ui";
import { otelEnv } from "@/lib/generators";
import { OTEL_SIGNALS, OTEL_SPANS, OTEL_SENSITIVE } from "@/lib/content";

type Span = {
  id: string;
  sessionId: string;
  tenantId: string;
  parentSpanId: string | null;
  kind: string;
  name: string;
  status: string;
  durationMs: number;
  attributes: any;
  startedAt: string;
  title: string;
};
type Telemetry = { spans: Span[]; totals: { kind: string; count: number; avgMs: number; maxMs: number }[] };

export default function ObservabilityPage() {
  const [tel, setTel] = useState<Telemetry | null>(null);
  const [cfg, setCfg] = useState({
    endpoint: "http://collector.example.com:4318",
    serviceName: "agent-host",
    traces: true,
    metrics: true,
    logs: true,
    shortIntervals: false,
    prompts: false,
    toolDetails: false,
    toolContent: false,
    rawBodies: false,
    tenantId: "",
    endUserId: "",
  });
  const set = (k: keyof typeof cfg, v: unknown) => setCfg((c) => ({ ...c, [k]: v }));

  useEffect(() => {
    const load = async () => setTel(await (await fetch("/api/telemetry", { cache: "no-store" })).json());
    load();
    const t = setInterval(load, 3000);
    return () => clearInterval(t);
  }, []);

  const env = otelEnv(cfg);

  const k8sYaml = `# Set at the orchestrator level — every query() call inherits these.
apiVersion: v1
kind: Deployment
metadata:
  name: agent-host
spec:
  template:
    spec:
      containers:
        - name: agent-host
          envFrom:
            - secretRef:
                name: otel-collector-config   # endpoint + auth header
          env:
            - name: CLAUDE_CODE_ENABLE_TELEMETRY
              value: "1"
            - name: OTEL_METRICS_EXPORTER
              value: "otlp"
            - name: OTEL_LOGS_EXPORTER
              value: "otlp"
            - name: OTEL_TRACES_EXPORTER
              value: "otlp"
            - name: CLAUDE_CODE_ENHANCED_TELEMETRY_BETA
              value: "1"
            # Per-request, inject identity (percent-encoded):
            # OTEL_RESOURCE_ATTRIBUTES=enduser.id=<user>,tenant.id=<tenant>`;

  return (
    <div className="p-8 max-w-[1260px] mx-auto">
      <header className="mb-7">
        <h1 className="text-xl font-semibold text-zinc-100">Observability</h1>
        <p className="text-[13px] text-zinc-500 mt-1 max-w-3xl">
          The CLI has OpenTelemetry instrumentation built in. The SDK produces no telemetry itself — it passes env config through to the subprocess, which exports traces,
          metrics and log events directly to your collector.
        </p>
      </header>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12 lg:col-span-5">
          <SectionTitle title="OTEL environment generator" subtitle="Configure the three independent signals; export at the container/orchestrator level in production." />
          <div className="space-y-3">
            <Field label="OTLP endpoint">
              <input className="input-dark mono" value={cfg.endpoint} onChange={(e) => set("endpoint", e.target.value)} />
            </Field>
            <Field label="OTEL_SERVICE_NAME">
              <input className="input-dark mono" value={cfg.serviceName} onChange={(e) => set("serviceName", e.target.value)} />
            </Field>
            <div className="grid grid-cols-3 gap-2">
              <Signals label="Traces (beta)" on={cfg.traces} onClick={() => set("traces", !cfg.traces)} />
              <Signals label="Metrics" on={cfg.metrics} onClick={() => set("metrics", !cfg.metrics)} />
              <Signals label="Log events" on={cfg.logs} onClick={() => set("logs", !cfg.logs)} />
            </div>
            <Toggle checked={cfg.shortIntervals} onChange={(v) => set("shortIntervals", v)} label="1s export intervals (short-lived ephemeral tasks)" />
            <div className="border-t border-[#1e232c] pt-3">
              <div className="text-[11px] uppercase tracking-wider text-zinc-600 font-semibold mb-2">Per-request attribution</div>
              <div className="grid grid-cols-2 gap-2">
                <input className="input-dark mono" placeholder="tenant.id" value={cfg.tenantId} onChange={(e) => set("tenantId", e.target.value)} />
                <input className="input-dark mono" placeholder="enduser.id" value={cfg.endUserId} onChange={(e) => set("endUserId", e.target.value)} />
              </div>
            </div>
            <div className="border-t border-[#1e232c] pt-3">
              <div className="text-[11px] uppercase tracking-wider text-rose-400/80 font-semibold mb-2">Sensitive-data opt-ins</div>
              <div className="space-y-2">
                <Toggle checked={cfg.prompts} onChange={(v) => set("prompts", v)} label="OTEL_LOG_USER_PROMPTS — prompt text" />
                <Toggle checked={cfg.toolDetails} onChange={(v) => set("toolDetails", v)} label="OTEL_LOG_TOOL_DETAILS — tool arguments" />
                <Toggle checked={cfg.toolContent} onChange={(v) => set("toolContent", v)} label="OTEL_LOG_TOOL_CONTENT — full I/O bodies (needs traces)" />
                <Toggle checked={cfg.rawBodies} onChange={(v) => set("rawBodies", v)} label="OTEL_LOG_RAW_API_BODIES — full API JSON (implies all)" />
              </div>
            </div>
          </div>
        </Card>

        <div className="col-span-12 lg:col-span-7 space-y-4">
          <CodeBlock title=".env" lang="bash" code={env} />
          <Tabs
            tabs={[
              { key: "k8s", label: "Kubernetes manifest", content: <CodeBlock lang="yaml" code={k8sYaml} /> },
              {
                key: "diag",
                label: "Verification",
                content: (
                  <Card className="m-0">
                    <ul className="text-[12.5px] text-zinc-400 space-y-2 list-disc list-inside">
                      <li>Check your collector&apos;s logs for incoming spans/metrics after a task completes.</li>
                      <li>Export fails silently by default — set <span className="mono text-zinc-300">CLAUDE_CODE_OTEL_DIAG_STDERR=1</span> and read the SDK stderr callback.</li>
                      <li>Never use the <span className="mono text-zinc-300">console</span> exporter through the SDK: stdout is the message channel.</li>
                      <li>Filter traces by <span className="mono text-zinc-300">session.id</span> to see multiple query() calls as one timeline.</li>
                    </ul>
                  </Card>
                ),
              },
            ]}
          />
        </div>
      </div>

      <div className="grid grid-cols-12 gap-4 mb-6">
        <Card className="col-span-12">
          <SectionTitle title="Live signal feed" subtitle="Spans emitted by the simulated fleet (same shapes the real CLI exports)." />
          <div className="grid grid-cols-4 gap-3 mb-4">
            {(tel?.totals ?? []).map((t) => (
              <div key={t.kind} className="rounded-xl border border-[#232a35] bg-[#11151c] p-3.5">
                <div className="text-[11px] uppercase tracking-wider text-zinc-600 mono">{t.kind.replace("_", " ")}</div>
                <div className="text-2xl font-semibold text-zinc-100 mono mt-1">{t.count}</div>
                <div className="text-[11px] text-zinc-500 mt-0.5">avg {t.avgMs}ms · max {Math.round(t.maxMs / 100) / 10}s</div>
              </div>
            ))}
          </div>
          <div className="space-y-1 max-h-[380px] overflow-y-auto">
            {(tel?.spans ?? []).map((s) => (
              <Link key={s.id} href={`/sessions/${s.sessionId}`} className="flex items-center gap-3 rounded-lg px-3 py-1.5 hover:bg-white/[0.03]">
                <span className={`badge ${s.kind === "tool" ? "bg-teal-500/10 text-teal-300 border-teal-500/25" : s.kind === "llm_request" ? "bg-sky-500/10 text-sky-300 border-sky-500/25" : "bg-[#d97757]/15 text-[#e8a089] border-[#d97757]/30"}`}>
                  {s.kind.replace("_", " ")}
                </span>
                <span className="mono text-[11.5px] text-zinc-300 truncate w-64">{s.name.replace("claude_code.", "")}</span>
                <span className="text-[11px] text-zinc-600 truncate flex-1">{s.title}</span>
                {s.attributes?.["cost.usd"] ? <span className="mono text-[11px] text-[#e8a089]">${Number(s.attributes["cost.usd"]).toFixed(4)}</span> : null}
                <span className="mono text-[11px] text-zinc-500 w-16 text-right">{s.durationMs < 1000 ? `${s.durationMs}ms` : `${(s.durationMs / 1000).toFixed(1)}s`}</span>
                {s.status === "error" && <Badge tone="red">error</Badge>}
              </Link>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-12 gap-4">
        <Card className="col-span-12 lg:col-span-7">
          <SectionTitle title="Signals & span catalog" />
          <div className="space-y-2 mb-5">
            {OTEL_SIGNALS.map((s) => (
              <div key={s.signal} className="rounded-lg border border-[#232a35] bg-[#11151c] px-3.5 py-3">
                <div className="flex items-center justify-between gap-3">
                  <span className="text-[12.5px] font-medium text-zinc-200">{s.signal}</span>
                  <span className="mono text-[10.5px] text-zinc-500 text-right">{s.enable} · {s.interval}</span>
                </div>
                <p className="text-[11.5px] text-zinc-500 mt-1">{s.contains}</p>
              </div>
            ))}
          </div>
          <div className="space-y-1.5">
            {OTEL_SPANS.map((s) => (
              <div key={s.span} className="flex gap-3 text-[12px]">
                <span className="mono text-[11px] text-[#e8a089] w-64 shrink-0">{s.span}</span>
                <span className="text-zinc-500">{s.describes}</span>
              </div>
            ))}
          </div>
        </Card>
        <Card className="col-span-12 lg:col-span-5">
          <SectionTitle title="Sensitive data" subtitle="Structural telemetry only by default: durations, model names, tool names, token counts. These opt in to content." />
          <div className="space-y-2">
            {OTEL_SENSITIVE.map((v) => (
              <div key={v.variable} className="rounded-lg border border-rose-900/30 bg-rose-950/10 px-3 py-2.5">
                <div className="mono text-[11px] text-rose-300">{v.variable}</div>
                <div className="text-[11.5px] text-zinc-500 mt-0.5">{v.adds}</div>
              </div>
            ))}
          </div>
          <p className="text-[11.5px] text-zinc-600 mt-3">Leave unset unless your observability pipeline is approved to store the data agents handle.</p>
        </Card>
      </div>
    </div>
  );
}

function Signals({ label, on, onClick }: { label: string; on: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`rounded-lg border px-3 py-2.5 text-[12px] font-medium transition-colors ${on ? "border-emerald-700/50 bg-emerald-950/30 text-emerald-300" : "border-[#232a35] bg-[#11151c] text-zinc-600"}`}>
      {on ? "●" : "○"} {label}
    </button>
  );
}
