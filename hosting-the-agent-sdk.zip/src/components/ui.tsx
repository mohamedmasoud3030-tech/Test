"use client";

import { useState, type ReactNode } from "react";
import { classNames } from "@/lib/util";

// ── Cards / layout ───────────────────────────────────────────────────────────
export function Card({
  children,
  className,
  hover,
}: {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}) {
  return <div className={classNames("card p-5", hover && "card-hover", className)}>{children}</div>;
}

export function SectionTitle({ title, subtitle, right }: { title: string; subtitle?: string; right?: ReactNode }) {
  return (
    <div className="flex items-end justify-between gap-4 mb-4">
      <div>
        <h2 className="text-[15px] font-semibold text-zinc-100">{title}</h2>
        {subtitle && <p className="text-[13px] text-zinc-500 mt-0.5 max-w-2xl">{subtitle}</p>}
      </div>
      {right}
    </div>
  );
}

// ── Buttons ──────────────────────────────────────────────────────────────────
export function Button({
  children,
  onClick,
  variant = "ghost",
  type = "button",
  disabled,
  className,
  title,
  small,
}: {
  children: ReactNode;
  onClick?: () => void | Promise<void>;
  variant?: "primary" | "ghost" | "danger";
  type?: "button" | "submit";
  disabled?: boolean;
  className?: string;
  title?: string;
  small?: boolean;
}) {
  const [busy, setBusy] = useState(false);
  return (
    <button
      type={type}
      title={title}
      disabled={disabled || busy}
      onClick={
        onClick
          ? async () => {
              setBusy(true);
              try {
                await onClick();
              } finally {
                setBusy(false);
              }
            }
          : undefined
      }
      className={classNames("btn", small && "!py-1.5 !px-2.5 !text-xs", variant === "primary" && "btn-primary", variant === "ghost" && "btn-ghost", variant === "danger" && "btn-danger", className)}
    >
      {children}
    </button>
  );
}

// ── Badges ─────────────────────────────────────────────────────────────────
type Tone = "green" | "amber" | "red" | "blue" | "violet" | "zinc" | "teal";
const toneCls: Record<Tone, string> = {
  green: "bg-emerald-500/10 text-emerald-300 border-emerald-500/25",
  amber: "bg-amber-500/10 text-amber-300 border-amber-500/25",
  red: "bg-rose-500/10 text-rose-300 border-rose-500/25",
  blue: "bg-sky-500/10 text-sky-300 border-sky-500/25",
  violet: "bg-violet-500/10 text-violet-300 border-violet-500/25",
  teal: "bg-teal-500/10 text-teal-300 border-teal-500/25",
  zinc: "bg-zinc-500/10 text-zinc-400 border-zinc-500/25",
};

export function Badge({ children, tone = "zinc" }: { children: ReactNode; tone?: Tone }) {
  return <span className={classNames("badge", toneCls[tone])}>{children}</span>;
}

// ── Status pills ───────────────────────────────────────────────────────────
export const STATUS_META: Record<string, { label: string; tone: Tone; pulse?: boolean }> = {
  starting: { label: "starting", tone: "blue", pulse: true },
  running: { label: "running", tone: "green", pulse: true },
  awaiting_input: { label: "awaiting input", tone: "teal" },
  suspended: { label: "suspended", tone: "amber" },
  completed: { label: "completed", tone: "zinc" },
  failed: { label: "failed", tone: "red" },
  evicted: { label: "evicted", tone: "red" },
  active: { label: "active", tone: "green", pulse: true },
  draining: { label: "draining", tone: "amber" },
  stopped: { label: "stopped", tone: "zinc" },
};

export function StatusPill({ status }: { status: string }) {
  const meta = STATUS_META[status] ?? { label: status, tone: "zinc" as Tone };
  return (
    <Badge tone={meta.tone}>
      {meta.pulse && <span className={classNames("w-1.5 h-1.5 rounded-full bg-current live-dot")} />}
      {meta.label}
    </Badge>
  );
}

export function PatternBadge({ pattern }: { pattern: string }) {
  const map: Record<string, Tone> = {
    ephemeral: "amber",
    "long-running": "blue",
    hybrid: "violet",
    "multi-agent": "teal",
  };
  const icon: Record<string, string> = { ephemeral: "⚡", "long-running": "🛰️", hybrid: "🌗", "multi-agent": "🤝" };
  return (
    <Badge tone={map[pattern] ?? "zinc"}>
      <span>{icon[pattern] ?? "•"}</span>
      {pattern.replace("-", " ")}
    </Badge>
  );
}

export function StoreBadge({ backend }: { backend: string }) {
  const tone: Record<string, Tone> = { postgres: "blue", s3: "teal", redis: "red", none: "zinc" };
  return <Badge tone={tone[backend] ?? "zinc"}>{backend === "none" ? "no store" : backend}</Badge>;
}

// ── Stats ────────────────────────────────────────────────────────────────────
export function Stat({ label, value, sub, accent }: { label: string; value: ReactNode; sub?: ReactNode; accent?: boolean }) {
  return (
    <Card className="p-4">
      <div className="text-[11px] uppercase tracking-wider text-zinc-500 font-semibold">{label}</div>
      <div className={classNames("text-2xl font-semibold mt-1 tabular-nums", accent && "text-[#e8a089]")}>{value}</div>
      {sub && <div className="text-xs text-zinc-500 mt-1">{sub}</div>}
    </Card>
  );
}

export function ProgressBar({ pct, tone = "bg-[#d97757]" }: { pct: number; tone?: string }) {
  return (
    <div className="h-1.5 rounded-full bg-zinc-800 overflow-hidden">
      <div className={classNames("h-full rounded-full transition-all", pct > 90 ? "bg-rose-400" : pct > 70 ? "bg-amber-400" : tone)} style={{ width: `${Math.min(100, pct)}%` }} />
    </div>
  );
}

// ── Code block ───────────────────────────────────────────────────────────────
export function CodeBlock({ code, title, lang, compact }: { code: string; title?: string; lang?: string; compact?: boolean }) {
  const [copied, setCopied] = useState(false);
  return (
    <div className="codeblock overflow-hidden">
      <div className="flex items-center justify-between px-3.5 py-2 border-b border-[#1e232c] bg-[#101319]">
        <div className="flex items-center gap-2 text-[11.5px] text-zinc-400">
          <span className="flex gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ff5f57]/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#febc2e]/70" />
            <span className="w-2.5 h-2.5 rounded-full bg-[#28c840]/70" />
          </span>
          {title && <span className="mono ml-1">{title}</span>}
          {lang && <span className="text-zinc-600">· {lang}</span>}
        </div>
        <button
          className="text-[11px] text-zinc-500 hover:text-zinc-200 transition-colors"
          onClick={async () => {
            await navigator.clipboard.writeText(code);
            setCopied(true);
            setTimeout(() => setCopied(false), 1400);
          }}
        >
          {copied ? "✓ copied" : "copy"}
        </button>
      </div>
      <pre className={classNames("mono text-[12px] leading-[1.65] text-zinc-300 overflow-x-auto", compact ? "p-3" : "p-4")}>{code}</pre>
    </div>
  );
}

// ── Tabs ─────────────────────────────────────────────────────────────────────
export function Tabs({ tabs, initial }: { tabs: { key: string; label: ReactNode; content: ReactNode }[]; initial?: string }) {
  const [active, setActive] = useState(initial ?? tabs[0]?.key);
  const current = tabs.find((t) => t.key === active) ?? tabs[0];
  return (
    <div>
      <div className="flex gap-1 p-1 rounded-xl bg-[#11141a] border border-[#20262f] w-fit mb-4 flex-wrap">
        {tabs.map((t) => (
          <button
            key={t.key}
            onClick={() => setActive(t.key)}
            className={classNames(
              "px-3.5 py-1.5 rounded-lg text-[12.5px] font-medium transition-colors",
              active === t.key ? "bg-[#232936] text-zinc-100" : "text-zinc-500 hover:text-zinc-300"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>
      <div className="fade-up" key={active}>
        {current.content}
      </div>
    </div>
  );
}

// ── Form primitives ──────────────────────────────────────────────────────────
export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return (
    <label className="block">
      <span className="block text-[12px] font-medium text-zinc-400 mb-1.5">{label}</span>
      {children}
      {hint && <span className="block text-[11.5px] text-zinc-600 mt-1.5">{hint}</span>}
    </label>
  );
}

export function Toggle({ checked, onChange, label }: { checked: boolean; onChange: (v: boolean) => void; label: string }) {
  return (
    <button type="button" onClick={() => onChange(!checked)} className="flex items-center gap-2.5 text-left group">
      <span className={classNames("w-9 h-5 rounded-full transition-colors relative shrink-0", checked ? "bg-[#d97757]" : "bg-zinc-700")}>
        <span className={classNames("absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all", checked ? "left-[18px]" : "left-0.5")} />
      </span>
      <span className="text-[13px] text-zinc-300 group-hover:text-zinc-100">{label}</span>
    </button>
  );
}

export function Toast({ message, kind = "error" }: { message: string | null; kind?: "error" | "ok" }) {
  if (!message) return null;
  return (
    <div
      className={classNames(
        "fixed bottom-5 right-5 z-50 px-4 py-3 rounded-xl text-[13px] font-medium shadow-2xl border fade-up max-w-sm",
        kind === "error" ? "bg-rose-950/90 border-rose-700/50 text-rose-200" : "bg-emerald-950/90 border-emerald-700/50 text-emerald-200"
      )}
    >
      {message}
    </div>
  );
}
