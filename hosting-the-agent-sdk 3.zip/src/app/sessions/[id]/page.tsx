import { SessionConsole } from "@/components/SessionConsole";

export const dynamic = "force-dynamic";

export default async function SessionPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  return <SessionConsole id={id} />;
}
