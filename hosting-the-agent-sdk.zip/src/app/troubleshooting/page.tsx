"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { Card, Badge, SectionTitle } from "@/components/ui";
import { TROUBLESHOOTING } from "@/lib/content";

const RESULT_SUBTYPES = [
  { subtype: "success", meaning: "The task finished normally; result text is available.", tone: "green" as const },
  { subtype: "error_max_turns", meaning: "Hit maxTurns before finishing; transcript preserved, resume with a higher ceiling.", tone: "amber" as const },
  { subtype: "error_max_budget_usd", meaning: "Hit maxBudgetUsd; partial work and usage remain on the result.", tone: "amber" as const },
  { subtype: "error_during_execution", meaning: "API failure, cancellation, or CLI crash; cost fields may be zeroed, stop_reason null.", tone: "red" as const },
  { subtype: "error_max_structured_output_retries", meaning: "No structured output passed validation within the retry limit.", tone: "red" as const },
];

export default function TroubleshootingPage() {
  const [q, setQ] = useState("");
  const [cat, setCat] = useState("all");
  const categories = useMemo(() => Array.from(new Set(TROUBLESHOOTING.map((t) => t.category))), []);

  const filtered = TROUBLESHOOTING.filter((t) => (cat === "all" || t.category === cat)).filter((t) => {
    if (!q) return true;
    const hay = `${t.title} ${t.symptom} ${t.cause} ${t.fixes.join(" ")} ${t.sdk}`.toLowerCase();
    return hay.includes(q.toLowerCase());
  });

  return (
    <div className="p-8 max-w-[1100px] mx-auto">
      <header className="mb-6">
        <h1 className="text-xl font-semibold text-zinc-100">Troubleshooting deployment failures</h1>
        <p className="text-[13px] text-zinc-500 mt-1">
          Use this when an agent that works on your machine fails in a deployed service. Match the <i>exact</i> error message, then apply the fix.
        </p>
      </header>

      <Card className="p-3 mb-6">
        <div className="flex flex-wrap gap-2">
          <input className="input-dark max-w-[320px]" placeholder="Search error text, e.g. exit code, mirror, batch…" value={q} onChange={(e) => setQ(e.target.value)} />
          <select className="input-dark max-w-[200px]" value={cat} onChange={(e) => setCat(e.target.value)}>
            <option value="all">All stages</option>
            {categories.map((c) => <option key={c}>{c}</option>)}
          </select>
          <span className="ml-auto self-center text-[12px] text-zinc-600 mono">{filtered.length} entries</span>
        </div>
      </Card>

      <div className="space-y-3 mb-8">
        {filtered.map((t) => (
          <Card key={t.id}>
            <div className="flex items-start gap-3 flex-wrap">
              <h2 className="text-[14px] font-semibold text-zinc-100">{t.title}</h2>
              <div className="flex gap-1.5 ml-auto">
                <Badge tone="zinc">{t.category}</Badge>
                <Badge tone={t.sdk.includes("TypeScript") && t.sdk.includes("Python") ? "blue" : "violet"}>{t.sdk}</Badge>
              </div>
            </div>
            <div className="mt-3 rounded-lg border border-rose-900/30 bg-rose-950/15 px-3 py-2">
              <div className="text-[10px] uppercase tracking-wider text-rose-400/80 font-semibold mb-1">Symptom</div>
              <p className="mono text-[11.5px] text-rose-200/90 break-all">{t.symptom}</p>
            </div>
            <div className="mt-2.5">
              <div className="text-[10px] uppercase tracking-wider text-zinc-600 font-semibold mb-1">Cause</div>
              <p className="text-[12.5px] text-zinc-400 leading-relaxed">{t.cause}</p>
            </div>
            <div className="mt-2.5">
              <div className="text-[10px] uppercase tracking-wider text-zinc-600 font-semibold mb-1">Fix</div>
              <ul className="space-y-1">
                {t.fixes.map((f, i) => (
                  <li key={i} className="text-[12.5px] text-zinc-300 flex gap-2">
                    <span className="text-emerald-400">✓</span>
                    <span dangerouslySetInnerHTML={{ __html: f.replace(/`([^`]+)`/g, '<span class="mono text-[11px] text-sky-300">$1</span>') }} />
                  </li>
                ))}
              </ul>
            </div>
          </Card>
        ))}
        {filtered.length === 0 && <div className="text-center text-zinc-600 py-10 text-sm">No failures match that search.</div>}
      </div>

      <Card className="mb-6">
        <SectionTitle title="Result message subtypes" subtitle="Always branch on result.subtype before reading result text — only success carries it. Every subtype still reports cost, usage, num_turns and session_id." />
        <div className="space-y-2">
          {RESULT_SUBTYPES.map((r) => (
            <div key={r.subtype} className="flex items-center gap-3 rounded-lg border border-[#232a35] bg-[#11151c] px-3.5 py-2.5">
              <Badge tone={r.tone}>{r.subtype}</Badge>
              <span className="text-[12px] text-zinc-400">{r.meaning}</span>
            </div>
          ))}
        </div>
      </Card>

      <Card>
        <SectionTitle title="Deployment triage path" />
        <ol className="space-y-2.5 text-[12.5px] text-zinc-400 list-none">
          <li><Badge tone="zinc">1 · start</Badge> CLI not found → image skipped optional dependencies, or the service PATH differs from your shell.</li>
          <li><Badge tone="zinc">2 · launch</Badge> Binary present but won&apos;t launch → architecture/libc mismatch or missing execute bit.</li>
          <li><Badge tone="zinc">3 · run</Badge> Exits mid-run → capture the stderr callback; distinguish ResultError from a bare process exit.</li>
          <li><Badge tone="zinc">4 · storage</Badge> Resume fails → check <span className="mono text-rose-300">mirror_error</span> batches and the SessionStore backend.</li>
          <li><Badge tone="zinc">5 · capacity</Badge> Exit 137 / OOM → size hosts from measured peak RSS, not the 1 GiB floor — <Link className="text-[#e8a089] hover:underline" href="/fleet">open the capacity calculator</Link>.</li>
        </ol>
      </Card>
    </div>
  );
}
