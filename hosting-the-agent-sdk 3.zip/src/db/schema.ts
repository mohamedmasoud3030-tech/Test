import {
  pgTable,
  uuid,
  text,
  integer,
  boolean,
  doublePrecision,
  jsonb,
  timestamp,
  index,
  uniqueIndex,
} from "drizzle-orm/pg-core";
import type { PlannedEvent, EngineRuntime } from "@/lib/engine-types";

// ─────────────────────────────────────────────────────────────────────────────
// Tenants — one row per customer isolated on shared infrastructure.
// ─────────────────────────────────────────────────────────────────────────────
export const tenants = pgTable("tenants", {
  id: text("id").primaryKey(), // slug, e.g. "acme-corp"
  name: text("name").notNull(),
  tier: text("tier").notNull().default("enterprise"), // team | enterprise
  endUserLabel: text("end_user_label").notNull().default("enduser"),
  workdirRoot: text("workdir_root").notNull().default("/srv/work"),
  configRoot: text("config_root").notNull().default("/srv/config"),
  isolateSettings: boolean("isolate_settings").notNull().default(true),
  disableAutoMemory: boolean("disable_auto_memory").notNull().default(true),
  distinctEgress: boolean("distinct_egress").notNull().default(true),
  egressPolicy: text("egress_policy").notNull().default("domain-allowlist"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─────────────────────────────────────────────────────────────────────────────
// Hosts — containers / nodes that pin and run agent subprocesses.
// ─────────────────────────────────────────────────────────────────────────────
export const hosts = pgTable("hosts", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  provider: text("provider").notNull(), // docker | kubernetes | modal | gvisor | firecracker | bare-metal
  region: text("region").notNull().default("us-east-1"),
  runtime: text("runtime").notNull().default("node"), // node | python
  ramMb: integer("ram_mb").notNull().default(4096),
  cpus: integer("cpus").notNull().default(2),
  overheadMb: integer("overhead_mb").notNull().default(512),
  perSessionRamMb: integer("per_session_ram_mb").notNull().default(1024),
  status: text("status").notNull().default("active"), // active | draining | stopped
  note: text("note"),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
});

// ─────────────────────────────────────────────────────────────────────────────
// Sessions — one row maps to one spawned `claude` CLI subprocess.
// ─────────────────────────────────────────────────────────────────────────────
export const sessions = pgTable(
  "sessions",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    tenantId: text("tenant_id")
      .notNull()
      .references(() => tenants.id, { onDelete: "cascade" }),
    hostId: uuid("host_id").references(() => hosts.id, { onDelete: "set null" }),
    title: text("title").notNull(),
    prompt: text("prompt").notNull(),
    endUserId: text("end_user_id").notNull().default("enduser-001"),
    sdk: text("sdk").notNull().default("typescript"), // typescript | python
    pattern: text("pattern").notNull().default("ephemeral"), // ephemeral | long-running | hybrid | multi-agent
    model: text("model").notNull().default("claude-sonnet-4-5"),
    cwd: text("cwd").notNull(),
    configDir: text("config_dir").notNull(),
    status: text("status").notNull().default("starting"),
    // starting | running | awaiting_input | suspended | completed | failed | evicted
    resultSubtype: text("result_subtype"),
    pid: integer("pid"),

    turns: integer("turns").notNull().default(0),
    maxTurns: integer("max_turns").notNull().default(20),

    inputTokens: integer("input_tokens").notNull().default(0),
    outputTokens: integer("output_tokens").notNull().default(0),
    cacheReadTokens: integer("cache_read_tokens").notNull().default(0),
    cacheCreationTokens: integer("cache_creation_tokens").notNull().default(0),
    totalCostUsd: doublePrecision("total_cost_usd").notNull().default(0),

    storeBackend: text("store_backend").notNull().default("postgres"), // postgres | s3 | redis | none
    storeFlaky: boolean("store_flaky").notNull().default(false),
    storeErrors: integer("store_errors").notNull().default(0),

    resumedFrom: uuid("resumed_from"), // sessions.id; plain column to avoid self-reference in inference
    storeResume: boolean("store_resume").notNull().default(false),
    isolateSettings: boolean("isolate_settings").notNull().default(true),
    disableAutoMemory: boolean("disable_auto_memory").notNull().default(true),

    forkDepth: integer("fork_depth").notNull().default(0),
    plan: jsonb("plan").$type<{ events: PlannedEvent[] }>().notNull().default({ events: [] }),
    cursor: integer("cursor").notNull().default(0),
    runtime: jsonb("runtime").$type<EngineRuntime>().notNull().default({}),

    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
    lastActiveAt: timestamp("last_active_at", { withTimezone: true }).notNull().defaultNow(),
    endedAt: timestamp("ended_at", { withTimezone: true }),
  },
  (t) => [
    index("sessions_tenant_idx").on(t.tenantId),
    index("sessions_status_idx").on(t.status),
    index("sessions_host_idx").on(t.hostId),
  ]
);

// ─────────────────────────────────────────────────────────────────────────────
// Transcript entries — mirrors the local JSONL transcript line-by-line.
// onDisk / inStore model the dual-write architecture of SessionStore.
// ─────────────────────────────────────────────────────────────────────────────
export const transcriptEntries = pgTable(
  "transcript_entries",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    sessionId: uuid("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    seq: integer("seq").notNull(),
    entryUuid: text("entry_uuid").notNull(),
    role: text("role").notNull(), // system | assistant | user
    kind: text("kind").notNull(), // meta | text | tool_use | tool_result | result
    subtype: text("subtype"),
    toolName: text("tool_name"),
    text: text("text"),
    data: jsonb("data"),
    subpath: text("subpath"), // e.g. "subagents/agent-abc" for subagent transcripts
    onDisk: boolean("on_disk").notNull().default(true),
    inStore: boolean("in_store").notNull().default(false),
    hydrated: boolean("hydrated").notNull().default(false),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    uniqueIndex("transcript_session_seq_idx").on(t.sessionId, t.seq),
    index("transcript_session_id_idx").on(t.sessionId),
  ]
);

// ─────────────────────────────────────────────────────────────────────────────
// Span events — OpenTelemetry-style spans emitted by the CLI subprocess.
// ─────────────────────────────────────────────────────────────────────────────
export const spanEvents = pgTable(
  "span_events",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    spanId: text("span_id").notNull(),
    sessionId: uuid("session_id")
      .notNull()
      .references(() => sessions.id, { onDelete: "cascade" }),
    tenantId: text("tenant_id").notNull(),
    parentSpanId: text("parent_span_id"),
    kind: text("kind").notNull(), // interaction | llm_request | tool | hook
    name: text("name").notNull(),
    status: text("status").notNull().default("ok"), // ok | error
    durationMs: integer("duration_ms").notNull().default(0),
    attributes: jsonb("attributes").$type<Record<string, unknown>>(),
    startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("spans_session_idx").on(t.sessionId),
    index("spans_started_idx").on(t.startedAt),
  ]
);
