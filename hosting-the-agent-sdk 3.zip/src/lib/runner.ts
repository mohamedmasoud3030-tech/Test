import { randomUUID } from "node:crypto";
import { db } from "@/db";
import { sessions, tenants, hosts, transcriptEntries, spanEvents } from "@/db/schema";
import { eq, inArray, asc, ne, and, sql } from "drizzle-orm";
import { buildPlan } from "./planner";
import { costOfUsage, hashSeed, rng, modelLabel } from "./util";
import type { PlannedEvent, TokenUsage } from "./engine-types";

type SessionRow = typeof sessions.$inferSelect;
type EntryRow = typeof transcriptEntries.$inferSelect;
type NewEntry = typeof transcriptEntries.$inferInsert;

export const TERMINAL_STATES = ["completed", "failed", "evicted"];

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────
function encodeProjectKey(cwd: string): string {
  return cwd.replace(/[^a-zA-Z0-9]/g, "-").replace(/-+/g, "-").slice(-48);
}

function transcriptPath(session: SessionRow): string {
  return `${session.configDir}/projects/${encodeProjectKey(session.cwd)}/${session.id}.jsonl`;
}

async function loadSession(id: string): Promise<SessionRow | null> {
  const rows = await db.select().from(sessions).where(eq(sessions.id, id)).limit(1);
  return rows[0] ?? null;
}

async function listEntries(sessionId: string): Promise<EntryRow[]> {
  return db
    .select()
    .from(transcriptEntries)
    .where(eq(transcriptEntries.sessionId, sessionId))
    .orderBy(asc(transcriptEntries.seq));
}

async function nextSeq(sessionId: string): Promise<number> {
  const rows = await db
    .select({ max: sql<number>`coalesce(max(${transcriptEntries.seq}), -1)` })
    .from(transcriptEntries)
    .where(eq(transcriptEntries.sessionId, sessionId));
  return Number(rows[0]?.max ?? -1) + 1;
}

async function insertEntries(rows: NewEntry[]): Promise<EntryRow[]> {
  if (!rows.length) return [];
  return db.insert(transcriptEntries).values(rows).returning();
}

function newUuid(): string {
  return randomUUID();
}

async function addSpan(
  session: SessionRow,
  span: {
    kind: "interaction" | "llm_request" | "tool" | "hook";
    name: string;
    parentSpanId?: string | null;
    durationMs: number;
    status?: "ok" | "error";
    attributes?: Record<string, unknown>;
    startedAt?: Date;
  }
): Promise<string> {
  const spanId = newUuid();
  const startedAt = span.startedAt ?? new Date(Date.now() - span.durationMs);
  await db.insert(spanEvents).values({
    spanId,
    sessionId: session.id,
    tenantId: session.tenantId,
    parentSpanId: span.parentSpanId ?? null,
    kind: span.kind,
    name: span.name,
    status: span.status ?? "ok",
    durationMs: span.durationMs,
    attributes: { "session.id": session.id, "tenant.id": session.tenantId, "enduser.id": session.endUserId, ...span.attributes },
    startedAt,
  });
  return spanId;
}

async function chooseHost(sdk: string, excludeId?: string): Promise<string | null> {
  const active = await db
    .select({ id: hosts.id, runtime: hosts.runtime })
    .from(hosts)
    .where(and(eq(hosts.status, "active"), excludeId ? ne(hosts.id, excludeId) : undefined));
  const wantRuntime = sdk === "python" ? "python" : "node";
  const match = active.find((h) => h.runtime === wantRuntime) ?? active[0];
  return match?.id ?? active[0]?.id ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// SessionStore dual-write simulation
// The transcript_entries table models BOTH the local JSONL and the mirrored
// store: onDisk / inStore flags say where each durable copy lives.
// ─────────────────────────────────────────────────────────────────────────────
async function mirrorBatch(session: SessionRow, entries: EntryRow[]): Promise<EntryRow | null> {
  if (!entries.length) return null;
  if (session.storeBackend === "none") {
    return null; // No adapter attached: local disk is the only copy.
  }
  const attempts = (session.runtime?.mirrorAttempts ?? 0) + 1;
  const r = rng(hashSeed(session.id + "::mirror"));
  for (let i = 0; i < attempts; i++) r(); // advance to the deterministic draw for this attempt
  const failChance = session.storeFlaky ? 0.28 : 0.04;
  const failed = r() < failChance;

  if (!failed) {
    await db
      .update(transcriptEntries)
      .set({ inStore: true })
      .where(
        inArray(
          transcriptEntries.id,
          entries.map((e) => e.id)
        )
      );
    await db
      .update(sessions)
      .set({ runtime: { ...session.runtime, mirrorAttempts: attempts } })
      .where(eq(sessions.id, session.id));
    session.runtime = { ...session.runtime, mirrorAttempts: attempts };
    return null;
  }

  // append() rejected after 3 attempts: the SDK drops the batch and emits
  // { type: "system", subtype: "mirror_error" }, then keeps running.
  const failedRuntime = {
    ...session.runtime,
    mirrorAttempts: attempts,
    mirrorFailures: (session.runtime?.mirrorFailures ?? 0) + 1,
  };
  await db
    .update(sessions)
    .set({
      storeErrors: session.storeErrors + 1,
      runtime: failedRuntime,
    })
    .where(eq(sessions.id, session.id));
  session.storeErrors += 1;
  session.runtime = failedRuntime;
  const seq = await nextSeq(session.id);
  const inserted = await insertEntries([
    {
      sessionId: session.id,
      seq,
      entryUuid: newUuid(),
      role: "system",
      kind: "meta",
      subtype: "mirror_error",
      text:
        "SessionStore.append() failed after 3 attempts (2 retries with backoff). Batch dropped; the agent continues from the local transcript.",
      data: {
        backend: session.storeBackend,
        droppedUuids: entries.filter((e) => !e.subpath).map((e) => e.entryUuid),
      },
      onDisk: true,
      inStore: false,
    },
  ]);
  return inserted[0] ?? null;
}

// ─────────────────────────────────────────────────────────────────────────────
// Create a session — spawns the simulated subprocess
// ─────────────────────────────────────────────────────────────────────────────
export type CreateInput = {
  tenantId: string;
  prompt: string;
  sdk?: "typescript" | "python";
  pattern?: "ephemeral" | "long-running" | "hybrid" | "multi-agent";
  model?: string;
  maxTurns?: number;
  storeBackend?: "postgres" | "s3" | "redis" | "none";
  storeFlaky?: boolean;
  endUserId?: string;
  hostId?: string;
};

export async function createSession(input: CreateInput): Promise<SessionRow> {
  const tenantRows = await db.select().from(tenants).where(eq(tenants.id, input.tenantId)).limit(1);
  const tenant = tenantRows[0];
  if (!tenant) throw new Error(`Unknown tenant: ${input.tenantId}`);

  const sdk = input.sdk ?? "typescript";
  const pattern = input.pattern ?? "ephemeral";
  const model = input.model ?? "claude-sonnet-4-5";
  const maxTurns = input.maxTurns ?? 20;
  const storeBackend = input.storeBackend ?? (pattern === "hybrid" ? "postgres" : "postgres");
  if (pattern === "hybrid" && storeBackend === "none") {
    throw new Error("Hybrid sessions require a SessionStore — shutting down without one loses the transcript.");
  }

  const hostId = input.hostId ?? (await chooseHost(sdk));
  if (!hostId) throw new Error("No active hosts available to schedule the subprocess.");

  const id = newUuid();
  const short = id.slice(0, 8);
  const agentSuffix = pattern === "multi-agent" ? "/agent-a" : "";
  const cwd = `${tenant.workdirRoot}/${tenant.id}/${short}${agentSuffix}`;
  const configDir = `${tenant.configRoot}/${tenant.id}-${short}`;

  const { events, title } = buildPlan({ prompt: input.prompt, pattern, model, maxTurns });
  const pid = 20000 + Math.floor(Math.random() * 40000);

  const rows = await db
    .insert(sessions)
    .values({
      id,
      tenantId: tenant.id,
      hostId,
      title,
      prompt: input.prompt,
      endUserId: input.endUserId ?? "enduser-001",
      sdk,
      pattern,
      model,
      cwd,
      configDir,
      status: "starting",
      pid,
      maxTurns,
      storeBackend,
      storeFlaky: input.storeFlaky ?? false,
      isolateSettings: tenant.isolateSettings,
      disableAutoMemory: tenant.disableAutoMemory,
      plan: { events },
      cursor: 0,
      runtime: { pid, currentTurn: 0, pendingTools: {} },
    })
    .returning();
  const session = rows[0];
  await tickSession(id, { force: true }); // emit system/init and flip to running
  return (await loadSession(id))!;
}

// ─────────────────────────────────────────────────────────────────────────────
// The agent-loop tick: process exactly one planned event
// ─────────────────────────────────────────────────────────────────────────────
let fleetLock = 0;

export async function tickSession(id: string, opts: { force?: boolean } = {}): Promise<{ advanced: boolean; state?: string }> {
  let session = await loadSession(id);
  if (!session) return { advanced: false };
  if (session.status !== "starting" && session.status !== "running") return { advanced: false, state: session.status };

  const now = Date.now();
  const last = new Date(session.lastActiveAt).getTime();
  if (!opts.force && !session.runtime?.fast && now - last < 850) {
    return { advanced: false, state: "throttled" };
  }

  const cursor = session.cursor;
  const events = session.plan?.events ?? [];

  // First tick always emits system/init (session metadata from the subprocess).
  if (cursor === 0 && !(session.runtime?.initEmitted) && events[0]?.kind !== "init") {
    let seq = await nextSeq(id);
    const initRows = await insertEntries([
      {
        sessionId: id,
        seq,
        entryUuid: newUuid(),
        role: "system",
        kind: "meta",
        subtype: "init",
        text: `claude CLI subprocess spawned (pid ${session.pid})`,
        data: {
          session_id: id,
          pid: session.pid,
          cwd: session.cwd,
          sdk: session.sdk,
          model: modelLabel(session.model),
          transcript_path: transcriptPath(session),
          setting_sources: session.isolateSettings ? [] : ["user", "project", "local"],
          auto_memory: !session.disableAutoMemory,
          resumed_from: session.resumedFrom ?? null,
          store: session.storeBackend,
        },
        onDisk: true,
        inStore: false,
      },
    ]);
    await mirrorBatch(session, initRows);
    const reloaded = await loadSession(id);
    await db
      .update(sessions)
      .set({
        status: "running",
        lastActiveAt: new Date(),
        runtime: { ...(reloaded?.runtime ?? session.runtime ?? {}), initEmitted: true },
      })
      .where(eq(sessions.id, id));
    return { advanced: true, state: "running" };
  }

  const event: PlannedEvent | undefined = events[cursor];
  if (!event) {
    return { advanced: false, state: session.status };
  }

  const rt = session.runtime ?? {};
  const created: EntryRow[] = [];
  let seq = await nextSeq(id);
  let statusPatch: Partial<SessionRow> = {};
  let ended = false;
  let resultSubtype: string | null = null;

  const addEntry = async (row: Omit<NewEntry, "sessionId" | "seq" | "entryUuid">): Promise<EntryRow> => {
    const rows = await insertEntries([{ ...row, sessionId: id, seq: seq++, entryUuid: newUuid() }]);
    const row0 = rows[0];
    created.push(row0);
    return row0;
  };

  const durR = rng(hashSeed(id + ":" + cursor));
  const llmDuration = () => Math.round(420 + durR() * 1900);

  if (event.kind === "assistant") {
    const turnNo = event.phase === "open" ? (rt.currentTurn ?? 0) + 1 : rt.currentTurn ?? 0;
    if (event.phase === "open") {
      rt.currentTurn = turnNo;
      // Open an interaction span (one agent turn); the completed row is
      // inserted when the turn closes, so child spans reference its ID early.
      const interactionId = newUuid();
      rt.openInteractionSpanId = interactionId;
      rt.interactionStart = Date.now() - llmDuration();
      const usage = event.usage;
      await addSpan(session, {
        kind: "llm_request",
        name: "claude_code.llm_request",
        parentSpanId: interactionId,
        durationMs: llmDuration(),
        attributes: spanUsage(session, usage),
      });
      await addEntry({
        role: "assistant",
        kind: "text",
        text: event.text,
        data: { turn: turnNo, usage: event.usage, phase: "open" },
        onDisk: true,
        inStore: false,
      });
      statusPatch = { turns: turnNo };
    } else {
      const usage = event.usage;
      await addSpan(session, {
        kind: "llm_request",
        name: "claude_code.llm_request",
        parentSpanId: rt.openInteractionSpanId,
        durationMs: llmDuration(),
        attributes: spanUsage(session, usage),
      });
      await addEntry({
        role: "assistant",
        kind: "text",
        text: event.text,
        data: { turn: rt.currentTurn, usage: event.usage, phase: "close" },
        onDisk: true,
        inStore: false,
      });
      // Close the enclosing interaction span.
      if (rt.openInteractionSpanId && rt.interactionStart) {
        await addSpan(session, {
          kind: "interaction",
          name: "claude_code.interaction",
          parentSpanId: null,
          durationMs: Date.now() - rt.interactionStart,
          attributes: { "turn.number": rt.currentTurn, closed: true },
        });
        rt.openInteractionSpanId = null;
        rt.interactionStart = null;
      }
    }
    await accumulateUsage(session, event.usage);
  } else if (event.kind === "tool_use") {
    // The completed tool span is inserted at tool_result with its duration.
    const toolStart = Date.now();
    const toolSpanId = newUuid();
    rt.pendingTools = rt.pendingTools ?? {};
    rt.pendingTools[event.tool] = { spanId: toolSpanId, start: toolStart };
    await addEntry({
      role: "assistant",
      kind: "tool_use",
      toolName: event.tool,
      text: describeToolInput(event.tool, event.input),
      data: { input: event.input },
      onDisk: true,
      inStore: false,
    });
  } else if (event.kind === "tool_result") {
    const pending = rt.pendingTools?.[event.tool];
    const durationMs = event.durationMs;
    const toolSpanId = pending?.spanId ?? null;

    // Subagent: mirror its transcript under subpath subagents/agent-<id>
    let subpath: string | null = null;
    if (event.subEntries?.length) {
      subpath = `subagents/agent-${newUuid().slice(0, 8)}`;
      let subTurn = 0;
      for (const sub of event.subEntries) {
        const isToolRes = sub.kind === "tool_result";
        if (sub.kind === "text") {
          subTurn++;
          await addSpan(session, {
            kind: "llm_request",
            name: "claude_code.llm_request · subagent",
            parentSpanId: toolSpanId,
            durationMs: llmDuration(),
            attributes: { "agent.subpath": subpath, model: modelLabel(session.model) },
          });
        }
        await addEntry({
          role: sub.role,
          kind: sub.kind === "text" ? "text" : sub.kind,
          toolName: sub.toolName,
          text: sub.kind === "text" ? sub.text : isToolRes ? sub.output : describeToolInput(sub.toolName ?? "Tool", sub.input),
          data: {
            input: sub.input,
            output: sub.output,
            durationMs: sub.durationMs,
            subagent: true,
          },
          subpath,
          onDisk: true,
          inStore: false,
        });
        if (isToolRes) {
          await addSpan(session, {
            kind: "tool",
            name: `claude_code.tool · subagent ${sub.toolName}`,
            parentSpanId: toolSpanId,
            durationMs: sub.durationMs ?? 800,
            status: sub.isError ? "error" : "ok",
            attributes: { "tool.name": sub.toolName, "agent.subpath": subpath },
          });
        }
      }
      await addSpan(session, {
        kind: "tool",
        name: "claude_code.tool · Task (subagent fan-out)",
        parentSpanId: rt.openInteractionSpanId,
        durationMs,
        attributes: { "tool.name": "Task", "agent.subpath": subpath, "agent.subagent_count": 1 },
      });
    } else {
      await addSpan(session, {
        kind: "tool",
        name: `claude_code.tool · ${event.tool}`,
        parentSpanId: rt.openInteractionSpanId,
        durationMs,
        status: event.isError ? "error" : "ok",
        attributes: { "tool.name": event.tool },
      });
    }
    delete rt.pendingTools?.[event.tool];

    await addEntry({
      role: "user",
      kind: "tool_result",
      toolName: event.tool,
      text: event.output,
      data: {
        output: event.output,
        is_error: !!event.isError,
        duration_ms: durationMs,
        ...(subpath ? { subpath } : {}),
      },
      onDisk: true,
      inStore: false,
    });
  } else if (event.kind === "compact") {
    await addEntry({
      role: "system",
      kind: "meta",
      subtype: "compact_boundary",
      text: "Context window approaching its limit — earlier history was compacted into a summary.",
      onDisk: true,
      inStore: false,
    });
  } else if (event.kind === "result") {
    const fresh = await loadSession(id);
    if (fresh) session = fresh;
    // close any open interaction
    if (rt.openInteractionSpanId) {
      await addSpan(session, {
        kind: "interaction",
        name: "claude_code.interaction",
        parentSpanId: null,
        durationMs: rt.interactionStart ? Date.now() - rt.interactionStart : 1200,
        attributes: { "turn.number": rt.currentTurn, closed: true, terminated: true },
      });
      rt.openInteractionSpanId = null;
      rt.interactionStart = null;
    }
    resultSubtype = event.subtype;
    const success = event.subtype === "success";
    await addEntry({
      role: "system",
      kind: "result",
      subtype: event.subtype,
      text: success ? event.text ?? "Task completed successfully." : resultFailureText(event.subtype),
      data: {
        session_id: id,
        subtype: event.subtype,
        num_turns: session.turns,
        total_cost_usd: session.totalCostUsd,
        usage: {
          input: session.inputTokens,
          output: session.outputTokens,
          cacheRead: session.cacheReadTokens,
          cacheCreation: session.cacheCreationTokens,
        },
        is_error: !success,
      },
      onDisk: true,
      inStore: false,
    });
    ended = true;
  }

  // Mirror this tick's batch to the SessionStore
  if (created.length) {
    await mirrorBatch(session, created);
    Object.assign(rt, session.runtime ?? {});
  }

  const nextCursor = cursor + 1;
  const patch: Partial<SessionRow> & Record<string, unknown> = {
    cursor: nextCursor,
    runtime: rt,
    lastActiveAt: new Date(),
    ...statusPatch,
  };

  if (ended) {
    patch.resultSubtype = resultSubtype;
    if (resultSubtype === "success") {
      if (session.pattern === "ephemeral") {
        patch.status = "completed"; // one-shot container destroyed
        patch.endedAt = new Date();
        patch.pid = null;
      } else {
        patch.status = "awaiting_input"; // subprocess stays warm
      }
    } else {
      patch.status = "failed";
      patch.endedAt = new Date();
      patch.pid = null;
    }
  }
  await patchSession(id, patch);

  // A run resumed from the store deletes its temp config dir at run end,
  // so the store holds the only durable copy.
  if (ended && session.storeResume) {
    await db.update(transcriptEntries).set({ onDisk: false }).where(eq(transcriptEntries.sessionId, id));
  }

  session = (await loadSession(id))!;
  return { advanced: true, state: session.status };
}

function spanUsage(session: SessionRow, u: TokenUsage): Record<string, unknown> {
  return {
    model: session.model,
    "gen_ai.usage.input_tokens": u.inputTokens,
    "gen_ai.usage.output_tokens": u.outputTokens,
    "gen_ai.usage.cache_read_tokens": u.cacheReadTokens,
    "gen_ai.usage.cache_creation_tokens": u.cacheCreationTokens,
    "cost.usd": costOfUsage(session.model, u),
  };
}

async function accumulateUsage(session: SessionRow, u: TokenUsage): Promise<void> {
  const cost = costOfUsage(session.model, u);
  await db
    .update(sessions)
    .set({
      inputTokens: sql`${sessions.inputTokens} + ${u.inputTokens}`,
      outputTokens: sql`${sessions.outputTokens} + ${u.outputTokens}`,
      cacheReadTokens: sql`${sessions.cacheReadTokens} + ${u.cacheReadTokens}`,
      cacheCreationTokens: sql`${sessions.cacheCreationTokens} + ${u.cacheCreationTokens}`,
      totalCostUsd: sql`${sessions.totalCostUsd} + ${cost}`,
    })
    .where(eq(sessions.id, session.id));
}

async function patchSession(id: string, patch: Partial<SessionRow> & Record<string, unknown>): Promise<SessionRow> {
  const rows = await db.update(sessions).set(patch).where(eq(sessions.id, id)).returning();
  return rows[0];
}

function describeToolInput(tool: string, input: unknown): string {
  if (!input || typeof input !== "object") return `${tool}`;
  const i = input as Record<string, unknown>;
  if (tool === "Bash") return `$ ${i.command ?? ""}`;
  if (tool === "Read") return `read ${i.file_path ?? ""}`;
  if (tool === "Edit") return `edit ${i.file_path ?? ""}`;
  if (tool === "Write") return `write ${i.file_path ?? ""}`;
  if (tool === "Grep") return `grep "${i.pattern ?? ""}" ${i.path ?? ""}`;
  if (tool === "Glob") return `glob ${i.pattern ?? ""}`;
  if (tool === "WebFetch") return `fetch ${i.url ?? ""}`;
  if (tool === "Task") return `Task: ${i.description ?? i.prompt ?? ""}`;
  return `${tool}(${JSON.stringify(input).slice(0, 120)})`;
}

function resultFailureText(subtype: string): string {
  switch (subtype) {
    case "error_max_turns":
      return "Stopped: hit the maxTurns limit before the task finished. The transcript is preserved; resume with a higher limit to continue.";
    case "error_max_budget_usd":
      return "Stopped: hit the maxBudgetUsd limit.";
    case "error_during_execution":
      return "The CLI process exited mid-run with an error (error_during_execution). Usage fields may be zeroed; see stderr and the troubleshooting runbook.";
    default:
      return "The agent loop ended with an error.";
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Session actions
// ─────────────────────────────────────────────────────────────────────────────
export async function sendTurn(id: string, prompt: string): Promise<void> {
  const session = await loadSession(id);
  if (!session) throw new Error("Session not found");
  if (session.status !== "awaiting_input") {
    throw new Error(`Session is ${session.status}; only sessions awaiting input accept a new turn.`);
  }
  const { events } = buildPlan({ prompt, pattern: session.pattern, model: session.model, maxTurns: session.maxTurns, continuation: true });
  const planEvents = [...session.plan.events];
  if (planEvents[planEvents.length - 1]?.kind === "result") planEvents.pop();
  planEvents.push(...events);
  await db
    .update(sessions)
    .set({
      plan: { events: planEvents },
      status: "running",
      prompt: session.prompt + "\n\n[turn] " + prompt,
      lastActiveAt: new Date(),
      runtime: { ...session.runtime, pendingTools: {} },
    })
    .where(eq(sessions.id, id));
  await tickSession(id, { force: true });
}

export async function stopSession(id: string): Promise<void> {
  const session = await loadSession(id);
  if (!session) throw new Error("Session not found");
  if (!["starting", "running", "awaiting_input"].includes(session.status)) return;
  // Keep everything processed so far, stripping any prior result (a parked
  // session already contains a success result), then end with error_max_turns.
  const kept = session.plan.events.slice(0, session.cursor);
  while (kept.length && kept[kept.length - 1].kind === "result") kept.pop();
  // The terminal event must sit at the cursor — a parked session has already
  // consumed its whole plan, so replacing the last index alone is a no-op.
  const nextCursorValue = kept.length;
  kept.push({ kind: "result", subtype: "error_max_turns" });
  await db
    .update(sessions)
    .set({
      plan: { events: kept },
      cursor: nextCursorValue,
      maxTurns: Math.min(session.maxTurns, session.turns + 1),
      status: "running",
      lastActiveAt: new Date(),
    })
    .where(eq(sessions.id, id));
  await tickSession(id, { force: true });
}

export async function suspendSession(id: string): Promise<SessionRow> {
  const session = await loadSession(id);
  if (!session) throw new Error("Session not found");
  if (session.status !== "awaiting_input") throw new Error("Only idle sessions can be spun down.");
  // Container dies: local disk is lost. Store-mirrored entries survive.
  await db.update(transcriptEntries).set({ onDisk: false }).where(eq(transcriptEntries.sessionId, id));
  const rows = await db
    .update(sessions)
    .set({ status: "suspended", pid: null, lastActiveAt: new Date() })
    .where(eq(sessions.id, id))
    .returning();
  return rows[0];
}

async function hydrateFromStore(parent: SessionRow, opts: { storeResume: boolean; newId: string }): Promise<NewEntry[]> {
  const durable = (await listEntries(parent.id)).filter((e) => e.inStore);
  if (!durable.length) {
    throw new Error("No durable transcript in the SessionStore: nothing to hydrate.");
  }
  return durable.map((e, idx) => ({
    sessionId: opts.newId,
    seq: idx,
    entryUuid: opts.storeResume ? e.entryUuid : newUuid(), // fork rewrites UUIDs
    role: e.role,
    kind: e.kind,
    subtype: e.subtype,
    toolName: e.toolName,
    text: e.text,
    data: { ...(e.data as object), ...(opts.storeResume ? {} : { forked_from: e.entryUuid }) },
    subpath: e.subpath,
    onDisk: true, // materialized into the temp CLAUDE_CONFIG_DIR while the run is live
    inStore: true,
    hydrated: opts.storeResume,
  }));
}

export async function resumeSession(id: string, targetHostId?: string): Promise<SessionRow> {
  const parent = await loadSession(id);
  if (!parent) throw new Error("Session not found");
  const durableCount = (await listEntries(id)).filter((e) => e.inStore).length;
  if (durableCount === 0) {
    throw new Error(
      parent.storeBackend === "none"
        ? "Cannot resume: no SessionStore is attached and the container's local disk is gone. Attach postgres/s3/redis to use the hybrid pattern."
        : "Cannot resume: the store holds no entries for this session (every mirror batch failed). Check mirror_error events."
    );
  }
  const hostId = targetHostId ?? (await chooseHost(parent.sdk, parent.hostId ?? undefined));
  if (!hostId) throw new Error("No active host available for resume.");

  const newId = newUuid();
  const short = newId.slice(0, 8);
  const hydrated = await hydrateFromStore(parent, { storeResume: true, newId });
  const { events } = buildPlan({
    prompt: "Continue the previous work and verify the final state.",
    pattern: "hybrid",
    model: parent.model,
    maxTurns: parent.maxTurns,
    continuation: true,
  });
  const pid = 20000 + Math.floor(Math.random() * 40000);

  await db.insert(sessions).values({
    id: newId,
    tenantId: parent.tenantId,
    hostId,
    title: `${parent.title} — resumed`,
    prompt: `${parent.prompt}\n\n[resumed on ${hostId.slice(0, 8)}] Continue the previous work and verify the final state.`,
    endUserId: parent.endUserId,
    sdk: parent.sdk,
    pattern: "hybrid",
    model: parent.model,
    cwd: parent.cwd, // resume requires a matching working directory
    configDir: parent.configDir.replace(/-.{8}$/, `-${short}`),
    status: "starting",
    pid,
    maxTurns: parent.maxTurns,
    storeBackend: parent.storeBackend,
    storeFlaky: false,
    resumedFrom: parent.id,
    storeResume: true,
    isolateSettings: parent.isolateSettings,
    disableAutoMemory: parent.disableAutoMemory,
    forkDepth: parent.forkDepth,
    plan: { events },
    cursor: 0,
    runtime: { pid, currentTurn: 0, pendingTools: {} },
  });
  // Rewrite seq continuation after hydration (init + hydrated then plan events)
  await insertEntries(hydrated);
  // Mark hydration gap visually by stamping init on first tick.
  await tickSession(newId, { force: true });
  return (await loadSession(newId))!;
}

export async function forkSession(id: string): Promise<SessionRow> {
  const parent = await loadSession(id);
  if (!parent) throw new Error("Session not found");
  const all = await listEntries(id);
  const source = all.filter((e) => e.inStore || e.onDisk);
  if (!source.length) throw new Error("No transcript available to fork.");

  const newId = newUuid();
  const short = newId.slice(0, 8);
  const hostId = (await chooseHost(parent.sdk, parent.hostId ?? undefined)) ?? parent.hostId;
  // forkSession rewrites every sessionId/UUID; local-only entries are copied too.
  const rebuilt: NewEntry[] = source.map((e, idx) => ({
    sessionId: newId,
    seq: idx,
    entryUuid: newUuid(), // forkSession rewrites every UUID and sessionId
    role: e.role,
    kind: e.kind,
    subtype: e.subtype,
    toolName: e.toolName,
    text: e.text,
    data: { ...(e.data as object), forked_from: e.entryUuid },
    subpath: e.subpath,
    onDisk: true,
    inStore: true, // the transformed entries are appended under the new key
    hydrated: false,
  }));

  const { events } = buildPlan({
    prompt: `Explore an alternative approach for: ${parent.title}`,
    pattern: "ephemeral",
    model: parent.model,
    maxTurns: parent.maxTurns,
    continuation: true,
  });
  const pid = 20000 + Math.floor(Math.random() * 40000);
  const tenant = (await db.select().from(tenants).where(eq(tenants.id, parent.tenantId)).limit(1))[0];

  await db.insert(sessions).values({
    id: newId,
    tenantId: parent.tenantId,
    hostId,
    title: `${parent.title} — fork`,
    prompt: `[fork of ${parent.id.slice(0, 8)}] Explore an alternative approach for: ${parent.title}`,
    endUserId: parent.endUserId,
    sdk: parent.sdk,
    pattern: "ephemeral",
    model: parent.model,
    cwd: `${tenant.workdirRoot}/${tenant.id}/${short}`,
    configDir: `${tenant.configRoot}/${tenant.id}-${short}`,
    status: "starting",
    pid,
    maxTurns: parent.maxTurns,
    storeBackend: parent.storeBackend === "none" ? "postgres" : parent.storeBackend,
    resumedFrom: parent.id,
    storeResume: false,
    isolateSettings: parent.isolateSettings,
    disableAutoMemory: parent.disableAutoMemory,
    forkDepth: parent.forkDepth + 1,
    plan: { events },
    cursor: 0,
    runtime: { pid, currentTurn: 0, pendingTools: {} },
  });
  await insertEntries(rebuilt);
  // Forked history keeps original seqs; init tick appends after them
  await tickSession(newId, { force: true });
  return (await loadSession(newId))!;
}

export async function crashSession(id: string): Promise<void> {
  const session = await loadSession(id);
  if (!session) return;
  const seq = await nextSeq(id);
  await insertEntries([
    {
      sessionId: id,
      seq,
      entryUuid: newUuid(),
      role: "system",
      kind: "result",
      subtype: "error_during_execution",
      text: "CLI process exited unexpectedly (SIGKILL, OOM). ProcessError: Command failed with exit code 137.",
      data: { exit_code: 137, stderr: "Killed", recoverable: true },
      onDisk: true,
      inStore: session.storeBackend !== "none",
    },
  ]);
  await db
    .update(sessions)
    .set({ status: "failed", resultSubtype: "error_during_execution", endedAt: new Date(), pid: null, lastActiveAt: new Date() })
    .where(eq(sessions.id, id));
}

// Drive every live subprocess in the fleet, globally throttled.
export async function driveFleet(): Promise<number> {
  const now = Date.now();
  if (now - fleetLock < 1000) return 0;
  fleetLock = now;
  const live = await db
    .select({ id: sessions.id, lastActiveAt: sessions.lastActiveAt })
    .from(sessions)
    .where(inArray(sessions.status, ["starting", "running"]));
  let n = 0;
  for (const s of live) {
    const age = now - new Date(s.lastActiveAt).getTime();
    if (age > 800) {
      const r = await tickSession(s.id);
      if (r.advanced) n++;
    }
  }
  return n;
}

// ─────────────────────────────────────────────────────────────────────────────
// Reads
// ─────────────────────────────────────────────────────────────────────────────
export async function getSessionDetail(id: string) {
  const session = await loadSession(id);
  if (!session) return null;
  const [tenantRows, hostRows, entries, spans] = await Promise.all([
    db.select().from(tenants).where(eq(tenants.id, session.tenantId)).limit(1),
    session.hostId ? db.select().from(hosts).where(eq(hosts.id, session.hostId)).limit(1) : Promise.resolve([]),
    listEntries(id),
    db
      .select()
      .from(spanEvents)
      .where(eq(spanEvents.sessionId, id))
      .orderBy(asc(spanEvents.startedAt), asc(spanEvents.durationMs)),
  ]);
  return { session, tenant: tenantRows[0], host: hostRows[0] ?? null, entries, spans };
}
