import type { TokenUsage } from "./engine-types";

// ── Deterministic RNG (mulberry32) so simulated runs are stable per prompt ──
export function hashSeed(str: string): number {
  let h = 1779033703 ^ str.length;
  for (let i = 0; i < str.length; i++) {
    h = Math.imul(h ^ str.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}

export function rng(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function pick<T>(rnd: () => number, arr: T[]): T {
  return arr[Math.floor(rnd() * arr.length)];
}

// ── Model pricing, USD per million tokens ────────────────────────────────────
// [input, output, cacheWriteMultiplier, cacheReadPerM]
const PRICING: Record<string, [number, number, number, number]> = {
  "claude-opus-4-1": [15, 75, 1.25, 1.5],
  "claude-opus-4-1-bedrock": [15, 75, 1.25, 1.5],
  "claude-sonnet-4-5": [3, 15, 1.25, 0.3],
  "claude-sonnet-4-5-vertex": [3, 15, 1.25, 0.3],
  "claude-haiku-4-5": [0.8, 4, 1.25, 0.08],
};

export function modelLabel(model: string): string {
  if (model.includes("bedrock")) return "Claude Opus 4.1 · Bedrock";
  if (model.includes("vertex")) return "Claude Sonnet 4.5 · Vertex";
  if (model.includes("opus")) return "Claude Opus 4.1";
  if (model.includes("haiku")) return "Claude Haiku 4.5";
  return "Claude Sonnet 4.5";
}

export function costOfUsage(model: string, u: TokenUsage): number {
  const [inp, out, cacheWriteMult, cacheRead] = PRICING[model] ?? PRICING["claude-sonnet-4-5"];
  const billableInput = Math.max(0, u.inputTokens - u.cacheReadTokens - u.cacheCreationTokens);
  const cost =
    (billableInput * inp) / 1_000_000 +
    (u.outputTokens * out) / 1_000_000 +
    (u.cacheCreationTokens * inp * cacheWriteMult) / 1_000_000 +
    (u.cacheReadTokens * cacheRead) / 1_000_000;
  return Math.round(cost * 1_000_000) / 1_000_000;
}

export function addUsage(a: TokenUsage, b: TokenUsage): TokenUsage {
  return {
    inputTokens: a.inputTokens + b.inputTokens,
    outputTokens: a.outputTokens + b.outputTokens,
    cacheReadTokens: a.cacheReadTokens + b.cacheReadTokens,
    cacheCreationTokens: a.cacheCreationTokens + b.cacheCreationTokens,
  };
}

export function emptyUsage(): TokenUsage {
  return { inputTokens: 0, outputTokens: 0, cacheReadTokens: 0, cacheCreationTokens: 0 };
}

export function totalTokens(u: TokenUsage): number {
  return u.inputTokens + u.outputTokens;
}

// ── Formatting helpers ───────────────────────────────────────────────────────
export function usd(n: number, digits = 4): string {
  if (n < 0.01) return `$${n.toFixed(digits)}`;
  return `$${n.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

export function compactNum(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1)}k`;
  return `${n}`;
}

export function slugify(s: string): string {
  return s
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

export function shortId(id: string): string {
  return id.slice(0, 8);
}

export function classNames(...xs: Array<string | false | null | undefined>): string {
  return xs.filter(Boolean).join(" ");
}

export function timeAgo(iso: string | Date | null): string {
  if (!iso) return "—";
  const d = typeof iso === "string" ? new Date(iso) : iso;
  const s = Math.floor((Date.now() - d.getTime()) / 1000);
  if (s < 10) return "just now";
  if (s < 60) return `${s}s ago`;
  const m = Math.floor(s / 60);
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}
